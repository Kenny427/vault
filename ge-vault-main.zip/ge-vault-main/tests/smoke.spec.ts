import { test, expect } from '@playwright/test';

test.describe('Smoke Tests', () => {
  test('homepage loads and displays core elements', async ({ page }) => {
    await page.goto('/');

    // Check the main H1 brand title is visible
    const brandTitle = page.locator('h1', { hasText: 'GE Vault' });
    await expect(brandTitle).toBeVisible();

    // Check the Sign In button is visible
    const signInButton = page.locator('a', { hasText: 'Sign In' });
    await expect(signInButton).toBeVisible();

    // Check the main headline is visible
    const headline = page.locator('h2', { hasText: 'Track Your OSRS Investments' });
    await expect(headline).toBeVisible();
  });
});
