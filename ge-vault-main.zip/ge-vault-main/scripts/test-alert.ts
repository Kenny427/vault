#!/usr/bin/env tsx
/**
 * Test Alert Script
 *
 * Creates a test alert and provides instructions for testing the alert system end-to-end.
 *
 * Usage:
 *   npm run test:alert <user_email>
 *
 * Example:
 *   npm run test:alert user@example.com
 */

import { createClient } from '@supabase/supabase-js'
import * as readline from 'readline'

const SUPABASE_URL = process.env.VITE_SUPABASE_URL || process.env.SUPABASE_URL
const SUPABASE_SERVICE_KEY = process.env.SUPABASE_SERVICE_KEY

if (!SUPABASE_URL || !SUPABASE_SERVICE_KEY) {
  console.error('❌ Error: SUPABASE_URL and SUPABASE_SERVICE_KEY environment variables are required')
  process.exit(1)
}

const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_KEY)

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
})

function prompt(question: string): Promise<string> {
  return new Promise((resolve) => {
    rl.question(question, (answer) => {
      resolve(answer)
    })
  })
}

async function main() {
  console.log('🧪 ========== ALERT TESTING SCRIPT ==========\n')

  // Get user email from command line or prompt
  let userEmail = process.argv[2]
  if (!userEmail) {
    userEmail = await prompt('Enter user email: ')
  }

  // Find user by email
  console.log(`\n🔍 Looking up user: ${userEmail}...`)
  const { data: { users }, error: usersError } = await supabase.auth.admin.listUsers()

  if (usersError) {
    console.error('❌ Error fetching users:', usersError.message)
    process.exit(1)
  }

  const user = users?.find(u => u.email === userEmail)
  if (!user) {
    console.error(`❌ User not found: ${userEmail}`)
    console.log('\nAvailable users:')
    users?.forEach(u => console.log(`  - ${u.email}`))
    process.exit(1)
  }

  console.log(`✅ Found user: ${user.email} (${user.id})`)

  // Check premium status
  const { data: subscription } = await supabase
    .from('user_subscriptions')
    .select('status')
    .eq('user_id', user.id)
    .eq('status', 'active')
    .single()

  if (!subscription) {
    console.error('❌ User does not have an active premium subscription')
    console.log('💡 Tip: Grant premium access in Supabase or run the subscription seeding script')
    process.exit(1)
  }

  console.log('✅ User has active premium subscription')

  // Check Discord connection
  const { data: discordConnection } = await supabase
    .from('discord_connections')
    .select('*')
    .eq('user_id', user.id)
    .single()

  if (!discordConnection) {
    console.error('❌ User has not connected Discord account')
    console.log('💡 Tip: User must complete Discord OAuth flow first')
    process.exit(1)
  }

  console.log(`✅ Discord connected: @${discordConnection.discord_username}`)

  // Get a test item (Abyssal whip - ID 4151)
  const testItemId = '4151'
  const testItemName = 'Abyssal whip'

  console.log(`\n🎯 Creating test alert for: ${testItemName} (ID: ${testItemId})`)

  // Get current price
  const { data: currentPrice } = await supabase
    .from('item_prices_current')
    .select('high_price')
    .eq('item_id', testItemId)
    .single()

  const targetPrice = currentPrice?.high_price ? currentPrice.high_price - 1000000 : 1
  console.log(`📊 Current price: ${currentPrice?.high_price?.toLocaleString() || 'Unknown'}`)
  console.log(`🎯 Target price: ${targetPrice.toLocaleString()} (guaranteed to trigger)`)

  // Create test alert
  const testAlert = {
    user_id: user.id,
    item_id: testItemId,
    item_name: testItemName,
    alert_type: 'absolute',
    target_price: targetPrice,
    price_direction: 'down',
    notification_type: 'bot_dm',
    discord_user_id: discordConnection.discord_user_id,
    behavior: 'one_shot',
    notes: '[TEST ALERT] Created by test-alert script',
    active: true
  }

  const { data: createdAlert, error: createError } = await supabase
    .from('user_alerts')
    .insert(testAlert)
    .select()
    .single()

  if (createError) {
    console.error('❌ Error creating alert:', createError.message)
    process.exit(1)
  }

  console.log(`\n✅ Test alert created successfully!`)
  console.log(`   Alert ID: ${createdAlert.id}`)
  console.log(`   Item: ${createdAlert.item_name}`)
  console.log(`   Type: ${createdAlert.alert_type}`)
  console.log(`   Target: ${createdAlert.target_price} gp`)
  console.log(`   Direction: ${createdAlert.price_direction}`)
  console.log(`   Notification: ${createdAlert.notification_type}`)

  // Instructions
  console.log('\n📋 ========== TESTING INSTRUCTIONS ==========\n')
  console.log('1. Verify alert in database:')
  console.log(`   SELECT * FROM user_alerts WHERE id = ${createdAlert.id};\n`)

  console.log('2. Trigger the worker manually:')
  console.log('   a. Using wrangler (local):')
  console.log('      cd app/worker && npx wrangler dev src/index.ts')
  console.log('      curl -X POST http://localhost:8787\n')
  console.log('   b. Using production worker:')
  console.log('      Visit Cloudflare Dashboard → Workers → ge-vault-worker → Trigger Cron\n')

  console.log('3. Expected result:')
  console.log(`   - Discord DM sent to @${discordConnection.discord_username}`)
  console.log(`   - Message: "🔔 Price Alert! ${testItemName} is now <price> gp!"`)
  console.log(`   - Alert deactivated (behavior: one_shot)\n`)

  console.log('4. Verify alert was triggered:')
  console.log(`   SELECT * FROM alert_history WHERE alert_id = ${createdAlert.id} ORDER BY triggered_at DESC LIMIT 1;\n`)

  console.log('5. Check notification status:')
  console.log('   - notification_sent: should be TRUE')
  console.log('   - notification_error: should be NULL')
  console.log('   - Alert active status: should be FALSE\n')

  console.log('📊 Check worker logs for detailed metrics and any errors.\n')

  const cleanup = await prompt('Would you like to clean up (delete) this test alert? (y/N): ')

  if (cleanup.toLowerCase() === 'y' || cleanup.toLowerCase() === 'yes') {
    await supabase.from('user_alerts').delete().eq('id', createdAlert.id)
    console.log('✅ Test alert deleted')
  } else {
    console.log('ℹ️  Test alert kept in database for manual inspection')
  }

  console.log('\n✨ Test setup complete!\n')
  rl.close()
}

main().catch((error) => {
  console.error('💥 Fatal error:', error)
  rl.close()
  process.exit(1)
})
