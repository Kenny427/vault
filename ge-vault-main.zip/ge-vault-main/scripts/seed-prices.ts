/**
 * Seed Current Prices Script
 *
 * Fetches current OSRS item prices from the Wiki API and populates item_prices_current.
 * Run with: npm run seed:prices
 */

import { createClient } from '@supabase/supabase-js'
import * as dotenv from 'dotenv'
import * as path from 'path'
import { fileURLToPath } from 'url'

const __dirname = path.dirname(fileURLToPath(import.meta.url))
dotenv.config({ path: path.join(__dirname, '../.env.local') })

const supabaseUrl = process.env.VITE_SUPABASE_URL!
const supabaseServiceKey = process.env.SUPABASE_SERVICE_KEY!

if (!supabaseUrl || !supabaseServiceKey) {
  console.error('❌ Missing environment variables!')
  process.exit(1)
}

const supabase = createClient(supabaseUrl, supabaseServiceKey)

interface WikiPrice {
  high: number | null
  highTime: number | null
  low: number | null
  lowTime: number | null
}

interface WikiPricesResponse {
  [itemId: string]: WikiPrice
}

async function seedPrices() {
  console.log('🚀 Starting OSRS price seeding process...\n')

  try {
    // 1. Fetch latest prices from OSRS Wiki API
    console.log('📡 Fetching current prices from OSRS Wiki API...')
    const response = await fetch('https://prices.runescape.wiki/api/v1/osrs/latest')

    if (!response.ok) {
      throw new Error(`API request failed: ${response.status} ${response.statusText}`)
    }

    const pricesData = await response.json()
    const prices: WikiPricesResponse = pricesData.data

    const itemIds = Object.keys(prices)
    console.log(`✅ Fetched prices for ${itemIds.length.toLocaleString()} items\n`)

    // 2. Get valid item IDs from our database
    console.log('🔍 Fetching valid item IDs from database...')
    const { data: dbItems, error: itemsError } = await supabase
      .from('items')
      .select('id')

    if (itemsError) throw itemsError

    const validItemIds = new Set(dbItems?.map(item => item.id) || [])
    console.log(`✅ Found ${validItemIds.size.toLocaleString()} items in database\n`)

    // 3. Transform data for database (only for items we have)
    console.log('🔄 Transforming price data...')
    const pricesToInsert = itemIds
      .filter(id => {
        const itemId = parseInt(id)
        return validItemIds.has(itemId) && (prices[id].high !== null || prices[id].low !== null)
      })
      .map(id => ({
        item_id: parseInt(id),
        high_price: prices[id].high,
        low_price: prices[id].low,
        high_volume: null, // Not provided by latest endpoint
        low_volume: null,
        updated_at: new Date().toISOString()
      }))

    console.log(`✅ Prepared ${pricesToInsert.length.toLocaleString()} price entries (matched with our items)\n`)

    // 4. Insert/update prices in batches
    const BATCH_SIZE = 1000
    const batches = Math.ceil(pricesToInsert.length / BATCH_SIZE)

    console.log(`📦 Upserting prices in ${batches} batches of ${BATCH_SIZE}...\n`)

    let totalUpserted = 0
    for (let i = 0; i < batches; i++) {
      const start = i * BATCH_SIZE
      const end = Math.min((i + 1) * BATCH_SIZE, pricesToInsert.length)
      const batch = pricesToInsert.slice(start, end)

      console.log(`  Batch ${i + 1}/${batches}: Upserting ${batch.length} prices...`)

      const { error } = await supabase
        .from('item_prices_current')
        .upsert(batch, { onConflict: 'item_id' })

      if (error) {
        console.error(`  ❌ Error in batch ${i + 1}:`, error.message)
        throw error
      }

      totalUpserted += batch.length
      console.log(`  ✅ Batch ${i + 1}/${batches} complete (${totalUpserted.toLocaleString()} total)`)
    }

    console.log(`\n✅ Successfully seeded ${totalUpserted.toLocaleString()} price entries!`)

    // 5. Verify the data
    console.log('\n🔍 Verifying data...')
    const { count, error: countError } = await supabase
      .from('item_prices_current')
      .select('*', { count: 'exact', head: true })

    if (countError) {
      console.error('❌ Error verifying data:', countError)
    } else {
      console.log(`✅ Verified: ${count?.toLocaleString()} price entries in database`)
    }

    // 6. Show some sample prices
    console.log('\n📋 Sample current prices:')
    const { data: samplePrices, error: sampleError } = await supabase
      .from('item_prices_current')
      .select(`
        item_id,
        high_price,
        low_price,
        items (name)
      `)
      .not('high_price', 'is', null)
      .limit(5)

    if (sampleError) {
      console.error('❌ Error fetching samples:', sampleError)
    } else {
      samplePrices?.forEach((price: any) => {
        console.log(`  - ${price.items.name}: ${price.high_price?.toLocaleString()} GP (high) / ${price.low_price?.toLocaleString()} GP (low)`)
      })
    }

    console.log('\n🎉 Price seeding complete!')
    console.log('💡 Prices will be displayed in your portfolio now!')

  } catch (error: any) {
    console.error('\n❌ Price seeding failed:', error.message)
    process.exit(1)
  }
}

// Run the seeding function
seedPrices()
