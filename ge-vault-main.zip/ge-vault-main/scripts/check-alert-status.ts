#!/usr/bin/env tsx
import { createClient } from '@supabase/supabase-js';

const SUPABASE_URL = process.env.VITE_SUPABASE_URL || process.env.SUPABASE_URL;
const SUPABASE_SERVICE_KEY = process.env.SUPABASE_SERVICE_KEY;

if (!SUPABASE_URL || !SUPABASE_SERVICE_KEY) {
  console.error('Missing env vars');
  process.exit(1);
}

const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_KEY);

async function main() {
  const alertId = process.argv[2] || '7';

  const { data: history } = await supabase
    .from('alert_history')
    .select('*')
    .eq('alert_id', alertId)
    .order('triggered_at', { ascending: false })
    .limit(1);

  console.log('=== Alert History ===');
  console.log(JSON.stringify(history, null, 2));

  const { data: alert } = await supabase
    .from('user_alerts')
    .select('*')
    .eq('id', alertId)
    .single();

  console.log('\n=== Alert Status ===');
  console.log('Alert ID:', alert?.id);
  console.log('Active:', alert?.active);
  console.log('Trigger Count:', alert?.trigger_count);
  console.log('Last Triggered:', alert?.last_triggered_at);
}

main().catch(console.error);
