#!/usr/bin/env tsx
import 'dotenv/config';
import { createClient } from '@supabase/supabase-js';

const supabase = createClient(
  process.env.VITE_SUPABASE_URL!,
  process.env.VITE_SUPABASE_ANON_KEY!
);

async function checkAlert() {
  // Get the test alert (ID 6)
  const { data: alert, error: alertError } = await supabase
    .from('user_alerts')
    .select('*')
    .eq('id', 6)
    .single();

  if (alertError) {
    console.error('❌ Error fetching alert:', alertError);
    return;
  }

  console.log('\n📋 Alert Details:');
  console.log('  Item:', alert.item_name, `(ID: ${alert.item_id})`);
  console.log('  Alert Type:', alert.alert_type);
  console.log('  Target Price:', alert.target_price, 'gp');
  console.log('  Direction:', alert.price_direction);
  console.log('  Active:', alert.active);

  // Get current price
  const { data: currentPrice, error: priceError } = await supabase
    .from('item_prices_current')
    .select('*')
    .eq('item_id', alert.item_id)
    .single();

  if (priceError) {
    console.error('❌ Error fetching price:', priceError);
    return;
  }

  console.log('\n💰 Current Price:');
  console.log('  High:', currentPrice.high_price, 'gp');
  console.log('  Low:', currentPrice.low_price, 'gp');
  console.log('  Last Updated:', new Date(currentPrice.updated_at).toLocaleString());

  // Check if alert should trigger
  console.log('\n🔔 Alert Trigger Check:');
  const price = currentPrice.high_price;
  const target = alert.target_price;
  const direction = alert.price_direction;

  let shouldTrigger = false;
  if (direction === 'down') {
    shouldTrigger = price <= target;
    console.log(`  Price (${price}) <= Target (${target})?`, shouldTrigger);
  } else if (direction === 'up') {
    shouldTrigger = price >= target;
    console.log(`  Price (${price}) >= Target (${target})?`, shouldTrigger);
  } else {
    console.log(`  Direction is 'either', checking both conditions...`);
    shouldTrigger = price <= target || price >= target;
  }

  console.log('\n  ✅ Should Trigger:', shouldTrigger ? 'YES' : 'NO');

  if (!shouldTrigger) {
    console.log('\n💡 Tip: To make it trigger, you need to adjust the alert:');
    if (direction === 'down') {
      console.log(`  - Set target price to ${price + 1} or higher`);
    } else if (direction === 'up') {
      console.log(`  - Set target price to ${price - 1} or lower`);
    }
  }
}

checkAlert().catch(console.error);
