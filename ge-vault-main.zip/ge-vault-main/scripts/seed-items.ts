/**
 * Seed Items Script
 *
 * Fetches all OSRS items from the Wiki API and populates the items table.
 * Run with: npx tsx scripts/seed-items.ts
 */

import { createClient } from '@supabase/supabase-js'

// Load environment variables
import * as dotenv from 'dotenv'
import * as path from 'path'
import { fileURLToPath } from 'url'

const __dirname = path.dirname(fileURLToPath(import.meta.url))
dotenv.config({ path: path.join(__dirname, '../.env.local') })

const supabaseUrl = process.env.VITE_SUPABASE_URL!
const supabaseServiceKey = process.env.SUPABASE_SERVICE_KEY!

if (!supabaseUrl || !supabaseServiceKey) {
  console.error('❌ Missing environment variables!')
  console.error('Make sure VITE_SUPABASE_URL and SUPABASE_SERVICE_KEY are set in .env.local')
  process.exit(1)
}

const supabase = createClient(supabaseUrl, supabaseServiceKey)

interface WikiItem {
  examine: string
  id: number
  members: boolean
  lowalch?: number
  limit?: number
  value: number
  highalch?: number
  icon: string
  name: string
}

async function seedItems() {
  console.log('🚀 Starting OSRS items seeding process...\n')

  try {
    // 1. Fetch items from OSRS Wiki API
    console.log('📡 Fetching items from OSRS Wiki API...')
    const response = await fetch('https://prices.runescape.wiki/api/v1/osrs/mapping')

    if (!response.ok) {
      throw new Error(`API request failed: ${response.status} ${response.statusText}`)
    }

    const wikiItems: WikiItem[] = await response.json()
    console.log(`✅ Fetched ${wikiItems.length.toLocaleString()} items from Wiki API\n`)

    // 2. Transform data for database
    console.log('🔄 Transforming data for database...')
    const itemsToInsert = wikiItems.map(item => ({
      id: item.id,
      name: item.name,
      icon_url: `https://oldschool.runescape.wiki/images/${encodeURIComponent(item.icon.replace(/ /g, '_'))}`,
      examine: item.examine,
      members: item.members
    }))
    console.log(`✅ Transformed ${itemsToInsert.length.toLocaleString()} items\n`)

    // 3. Insert in batches (Supabase has a limit on batch size)
    const BATCH_SIZE = 1000
    const batches = Math.ceil(itemsToInsert.length / BATCH_SIZE)

    console.log(`📦 Inserting items in ${batches} batches of ${BATCH_SIZE}...\n`)

    let totalInserted = 0
    for (let i = 0; i < batches; i++) {
      const start = i * BATCH_SIZE
      const end = Math.min((i + 1) * BATCH_SIZE, itemsToInsert.length)
      const batch = itemsToInsert.slice(start, end)

      console.log(`  Batch ${i + 1}/${batches}: Inserting items ${start + 1}-${end}...`)

      const { data, error } = await supabase
        .from('items')
        .upsert(batch, { onConflict: 'id' })

      if (error) {
        console.error(`  ❌ Error in batch ${i + 1}:`, error.message)
        throw error
      }

      totalInserted += batch.length
      console.log(`  ✅ Batch ${i + 1}/${batches} complete (${totalInserted.toLocaleString()} total)`)
    }

    console.log(`\n✅ Successfully seeded ${totalInserted.toLocaleString()} items!`)

    // 4. Verify the data
    console.log('\n🔍 Verifying data...')
    const { count, error: countError } = await supabase
      .from('items')
      .select('*', { count: 'exact', head: true })

    if (countError) {
      console.error('❌ Error verifying data:', countError)
    } else {
      console.log(`✅ Verified: ${count?.toLocaleString()} items in database`)
    }

    // 5. Show some sample items
    console.log('\n📋 Sample items from database:')
    const { data: sampleItems, error: sampleError } = await supabase
      .from('items')
      .select('id, name, members')
      .limit(5)

    if (sampleError) {
      console.error('❌ Error fetching samples:', sampleError)
    } else {
      sampleItems?.forEach(item => {
        console.log(`  - ${item.name} (ID: ${item.id}) ${item.members ? '[Members]' : '[F2P]'}`)
      })
    }

    console.log('\n🎉 Seeding complete!')

  } catch (error: any) {
    console.error('\n❌ Seeding failed:', error.message)
    process.exit(1)
  }
}

// Run the seeding function
seedItems()
