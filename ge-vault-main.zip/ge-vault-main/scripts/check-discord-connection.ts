#!/usr/bin/env tsx
import { createClient } from '@supabase/supabase-js';

const SUPABASE_URL = process.env.VITE_SUPABASE_URL || process.env.SUPABASE_URL;
const SUPABASE_SERVICE_KEY = process.env.SUPABASE_SERVICE_KEY;

if (!SUPABASE_URL || !SUPABASE_SERVICE_KEY) {
  console.error('Missing env vars');
  process.exit(1);
}

const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_KEY);

async function main() {
  const userId = '23f75d13-20ec-4c7a-a659-d171049ad81b';
  const shouldCleanup = process.argv[2] === 'cleanup';

  if (shouldCleanup) {
    console.log('🧹 Cleaning up OAuth data...\n');

    // Delete old oauth_states for the user
    await supabase.from('oauth_states').delete().eq('user_id', userId);
    console.log('✅ Cleared oauth_states');

    // Delete discord_connections (if any exist)
    await supabase.from('discord_connections').delete().eq('user_id', userId);
    console.log('✅ Cleared discord_connections\n');

    console.log('✨ Database cleaned! Ready for fresh OAuth flow test.\n');
    return;
  }

  // Check oauth_states table
  const { data: oauthStates, error: oauthError } = await supabase
    .from('oauth_states')
    .select('*')
    .eq('user_id', userId);

  console.log('=== OAuth States ===');
  if (oauthError) {
    console.error('Error:', oauthError);
  } else {
    console.log(JSON.stringify(oauthStates, null, 2));
  }

  // Check discord_connections table
  const { data: discordConn, error: discordError } = await supabase
    .from('discord_connections')
    .select('*')
    .eq('user_id', userId);

  console.log('\n=== Discord Connections ===');
  if (discordError) {
    console.error('Error:', discordError);
  } else {
    console.log(JSON.stringify(discordConn, null, 2));
  }
}

main().catch(console.error);
