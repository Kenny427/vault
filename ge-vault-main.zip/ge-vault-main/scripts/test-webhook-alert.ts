#!/usr/bin/env tsx
/**
 * Test Webhook Alert Script
 *
 * Creates a test alert with webhook notification
 */

import { createClient } from '@supabase/supabase-js'

const SUPABASE_URL = process.env.VITE_SUPABASE_URL || process.env.SUPABASE_URL
const SUPABASE_SERVICE_KEY = process.env.SUPABASE_SERVICE_KEY

if (!SUPABASE_URL || !SUPABASE_SERVICE_KEY) {
  console.error('❌ Error: SUPABASE_URL and SUPABASE_SERVICE_KEY environment variables are required')
  process.exit(1)
}

const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_KEY)

async function main() {
  console.log('🧪 ========== WEBHOOK ALERT TEST ==========\n')

  const userEmail = process.argv[2]
  const webhookUrl = process.argv[3]

  if (!userEmail || !webhookUrl) {
    console.error('❌ Usage: npx tsx scripts/test-webhook-alert.ts <email> <webhook_url>')
    process.exit(1)
  }

  // Find user by email
  console.log(`🔍 Looking up user: ${userEmail}...`)
  const { data: { users }, error: usersError } = await supabase.auth.admin.listUsers()

  if (usersError) {
    console.error('❌ Error fetching users:', usersError.message)
    process.exit(1)
  }

  const user = users?.find(u => u.email === userEmail)
  if (!user) {
    console.error(`❌ User not found: ${userEmail}`)
    process.exit(1)
  }

  console.log(`✅ Found user: ${user.email} (${user.id})`)

  // Check premium status
  const { data: subscription } = await supabase
    .from('user_subscriptions')
    .select('status')
    .eq('user_id', user.id)
    .eq('status', 'active')
    .single()

  if (!subscription) {
    console.error('❌ User does not have an active premium subscription')
    process.exit(1)
  }

  console.log('✅ User has active premium subscription')

  // Test item (Abyssal whip - ID 4151)
  const testItemId = '4151'
  const testItemName = 'Abyssal whip'

  console.log(`\n🎯 Creating webhook alert for: ${testItemName} (ID: ${testItemId})`)

  // Get current price
  const { data: currentPrice } = await supabase
    .from('item_prices_current')
    .select('high_price')
    .eq('item_id', testItemId)
    .single()

  const targetPrice = currentPrice?.high_price ? currentPrice.high_price - 1000000 : 1
  console.log(`📊 Current price: ${currentPrice?.high_price?.toLocaleString() || 'Unknown'}`)
  console.log(`🎯 Target price: ${targetPrice.toLocaleString()} (guaranteed to trigger)`)

  // Create test alert with webhook
  const testAlert = {
    user_id: user.id,
    item_id: testItemId,
    item_name: testItemName,
    alert_type: 'absolute',
    target_price: targetPrice,
    price_direction: 'down',
    notification_type: 'webhook',
    discord_webhook_url: webhookUrl,
    behavior: 'one_shot',
    notes: '[TEST] Webhook notification test',
    active: true
  }

  const { data: createdAlert, error: createError } = await supabase
    .from('user_alerts')
    .insert(testAlert)
    .select()
    .single()

  if (createError) {
    console.error('❌ Error creating alert:', createError.message)
    process.exit(1)
  }

  console.log(`\n✅ Test webhook alert created successfully!`)
  console.log(`   Alert ID: ${createdAlert.id}`)
  console.log(`   Item: ${createdAlert.item_name}`)
  console.log(`   Target: ${createdAlert.target_price} gp`)
  console.log(`   Notification: webhook`)
  console.log(`   Webhook: ${webhookUrl.substring(0, 50)}...`)

  console.log('\n📋 ========== NEXT STEPS ==========\n')
  console.log('1. Trigger the worker to process this alert:')
  console.log('   cd worker && npx wrangler dev src/index.ts')
  console.log('   curl -X POST http://localhost:8787\n')
  console.log('   OR trigger production worker in Cloudflare Dashboard\n')
  console.log('2. Check your Discord channel for the webhook message!')
  console.log('3. Verify alert was triggered:')
  console.log(`   SELECT * FROM alert_history WHERE alert_id = ${createdAlert.id};\n`)
}

main().catch((error) => {
  console.error('💥 Fatal error:', error)
  process.exit(1)
})
