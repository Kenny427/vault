#!/usr/bin/env tsx
import { createClient } from '@supabase/supabase-js';

const SUPABASE_URL = process.env.VITE_SUPABASE_URL || process.env.SUPABASE_URL;
const SUPABASE_SERVICE_KEY = process.env.SUPABASE_SERVICE_KEY;

if (!SUPABASE_URL || !SUPABASE_SERVICE_KEY) {
  console.error('Missing required env vars: SUPABASE_URL, SUPABASE_SERVICE_KEY');
  process.exit(1);
}

const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_KEY);

async function main() {
  // Find the user who has Discord connected
  const { data: connections } = await supabase
    .from('discord_connections')
    .select('*')
    .order('connected_at', { ascending: false })
    .limit(1);

  if (!connections || connections.length === 0) {
    console.error('No Discord connections found!');
    process.exit(1);
  }

  const connection = connections[0];
  console.log('Discord connected as:', connection.discord_username);

  // Get the user
  const { data: { user }, error: userError } = await supabase.auth.admin.getUserById(connection.user_id);

  if (userError || !user) {
    console.error('Failed to get user:', userError);
    process.exit(1);
  }

  console.log('Creating bot DM alert for user:', user.email);

  // Use Twisted bow - a popular high-value item
  const testItemId = 20997;
  const testItemName = 'Twisted bow';

  // Set a low target price so the alert will definitely trigger when worker runs
  // Twisted bow is typically ~3-4B, so set target to 1B (will trigger immediately)
  const targetPrice = 1_000_000_000; // 1B gp

  console.log(`Using ${testItemName} (ID: ${testItemId})`);
  console.log(`Target price: ${targetPrice.toLocaleString()} gp (price direction: up)`);
  console.log(`Alert will trigger when worker fetches prices and finds Twisted bow > 1B`);

  // Create the alert with bot_dm notification type
  const testAlert = {
    user_id: user.id,
    item_id: testItemId,
    item_name: testItemName,
    alert_type: 'absolute',
    target_price: targetPrice,
    price_direction: 'up',
    notification_type: 'bot_dm', // Bot DM instead of webhook
    discord_user_id: connection.discord_user_id, // Required for bot_dm
    behavior: 'one_shot',
    notes: '[TEST] Bot DM notification test',
    active: true
  };

  const { data: alert, error: alertError } = await supabase
    .from('user_alerts')
    .insert(testAlert)
    .select()
    .single();

  if (alertError) {
    console.error('Failed to create alert:', alertError);
    process.exit(1);
  }

  console.log('\n✅ Bot DM test alert created successfully!');
  console.log('Alert ID:', alert.id);
  console.log('Item:', alert.item_name);
  console.log('Target:', `${alert.target_price} gp (${alert.price_direction})`);
  console.log('Notification:', 'Bot DM to', connection.discord_username);
  console.log('\nNow trigger the worker to test the notification!');
}

main().catch(console.error);
