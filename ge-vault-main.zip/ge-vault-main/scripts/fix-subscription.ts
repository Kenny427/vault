/**
 * Manually update subscription in database
 * Run this when webhooks don't fire during local testing
 */

import { createClient } from '@supabase/supabase-js'
import 'dotenv/config'

const supabaseUrl = process.env.VITE_SUPABASE_URL!
const supabaseKey = process.env.SUPABASE_SERVICE_KEY!

const supabase = createClient(supabaseUrl, supabaseKey)

async function updateSubscription() {
  const subscriptionData = {
    user_id: '9c57b944-6572-4357-9e5a-443773116c46',
    stripe_customer_id: 'cus_TOQpAO3SNWQ2Sk',
    stripe_subscription_id: 'sub_1SRdyMJjH0KnjxLCEmFilHRK',
    stripe_price_id: 'price_1SRdy6JjH0KnjxLCqntJTe0g',
    status: 'active',
    plan_type: 'yearly',
    current_period_start: new Date(1762715298 * 1000).toISOString(),
    current_period_end: new Date(1794251298 * 1000).toISOString(),
    cancel_at_period_end: false
  }

  console.log('Updating subscription with data:')
  console.log(JSON.stringify(subscriptionData, null, 2))

  const { data, error } = await supabase
    .from('user_subscriptions')
    .upsert(subscriptionData, {
      onConflict: 'user_id'
    })
    .select()

  if (error) {
    console.error('❌ Error updating subscription:', error)
    process.exit(1)
  }

  console.log('✅ Subscription updated successfully!')
  console.log(JSON.stringify(data, null, 2))
}

updateSubscription()
