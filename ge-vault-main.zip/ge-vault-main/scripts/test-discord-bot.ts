#!/usr/bin/env tsx
/**
 * Discord Bot Configuration Test
 *
 * Tests that the Discord bot is properly configured and can send messages
 */

const DISCORD_BOT_TOKEN = process.env.DISCORD_BOT_TOKEN;
const TEST_DISCORD_USER_ID = '212883437789511681'; // Your Discord user ID

if (!DISCORD_BOT_TOKEN) {
  console.error('❌ DISCORD_BOT_TOKEN environment variable is required');
  process.exit(1);
}

async function main() {
  console.log('🤖 ========== DISCORD BOT TEST ==========\n');

  // 1. Test bot token validity
  console.log('1️⃣ Testing bot token validity...');
  const botRes = await fetch('https://discord.com/api/v10/users/@me', {
    headers: {
      'Authorization': `Bot ${DISCORD_BOT_TOKEN}`,
    },
  });

  if (!botRes.ok) {
    const error = await botRes.text();
    console.error('❌ Bot token is invalid or bot account not found');
    console.error(`   Error: ${botRes.status} - ${error}`);
    process.exit(1);
  }

  const botUser = await botRes.json();
  console.log(`✅ Bot authenticated: ${botUser.username}#${botUser.discriminator} (ID: ${botUser.id})\n`);

  // 2. Test creating DM channel
  console.log('2️⃣ Testing DM channel creation...');
  const dmRes = await fetch('https://discord.com/api/v10/users/@me/channels', {
    method: 'POST',
    headers: {
      'Authorization': `Bot ${DISCORD_BOT_TOKEN}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      recipient_id: TEST_DISCORD_USER_ID,
    }),
  });

  if (!dmRes.ok) {
    const error = await dmRes.text();
    console.error('❌ Failed to create DM channel');
    console.error(`   Error: ${dmRes.status} - ${error}`);
    console.error('\n💡 Common issues:');
    console.error('   - Bot needs MESSAGE CONTENT intent enabled in Discord Developer Portal');
    console.error('   - User must share a server with the bot OR have DMs from server members enabled');
    console.error('   - User may have blocked the bot');
    process.exit(1);
  }

  const dmChannel = await dmRes.json();
  console.log(`✅ DM channel created: ${dmChannel.id}\n`);

  // 3. Test sending a message
  console.log('3️⃣ Sending test message...');
  const message = '🧪 **Test Message from GE Vault Bot**\n\nIf you can see this, the bot is configured correctly and can send you price alerts!';

  const msgRes = await fetch(`https://discord.com/api/v10/channels/${dmChannel.id}/messages`, {
    method: 'POST',
    headers: {
      'Authorization': `Bot ${DISCORD_BOT_TOKEN}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      content: message,
    }),
  });

  if (!msgRes.ok) {
    const error = await msgRes.text();
    console.error('❌ Failed to send DM');
    console.error(`   Error: ${msgRes.status} - ${error}`);
    console.error('\n💡 Common issues:');
    console.error('   - User has DMs disabled from server members');
    console.error('   - User has blocked the bot');
    console.error('   - Bot lacks SEND_MESSAGES permission');
    process.exit(1);
  }

  const sentMsg = await msgRes.json();
  console.log(`✅ Message sent successfully! (Message ID: ${sentMsg.id})\n`);

  // 4. Check bot intents/permissions
  console.log('4️⃣ Bot configuration summary:');
  console.log(`   Bot Username: ${botUser.username}`);
  console.log(`   Bot ID: ${botUser.id}`);
  console.log(`   Test User ID: ${TEST_DISCORD_USER_ID}`);
  console.log('\n📋 Required Discord Developer Portal settings:');
  console.log('   ✓ Bot → Privileged Gateway Intents → MESSAGE CONTENT INTENT: Enabled');
  console.log('   ✓ Bot → Token: Properly set in environment variables');
  console.log('   ✓ OAuth2 → Scopes: bot, identify');
  console.log('   ✓ Bot → Permissions: Send Messages, Read Message History\n');

  console.log('✅ ========== ALL TESTS PASSED! ==========\n');
  console.log('Check your Discord DMs - you should have received a test message!');
  console.log('Your bot is ready to send price alert notifications.\n');
}

main().catch((error) => {
  console.error('💥 Fatal error:', error);
  process.exit(1);
});
