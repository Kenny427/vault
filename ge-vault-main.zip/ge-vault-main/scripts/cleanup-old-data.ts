#!/usr/bin/env tsx
/**
 * Database Cleanup Script
 *
 * Cleans up old data from the database to prevent unbounded growth.
 * Safe to run repeatedly (idempotent).
 *
 * Usage:
 *   npm run cleanup:db [--dry-run]
 *
 * Environment Variables:
 *   ALERT_HISTORY_RETENTION_DAYS (default: 90) - Days to keep alert history
 *   OAUTH_STATE_EXPIRY_MINUTES (default: 10) - Minutes before OAuth states expire
 */

import { createClient } from '@supabase/supabase-js'

const SUPABASE_URL = process.env.VITE_SUPABASE_URL || process.env.SUPABASE_URL
const SUPABASE_SERVICE_KEY = process.env.SUPABASE_SERVICE_KEY

if (!SUPABASE_URL || !SUPABASE_SERVICE_KEY) {
  console.error('❌ Error: SUPABASE_URL and SUPABASE_SERVICE_KEY environment variables are required')
  process.exit(1)
}

const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_KEY)

// Configuration
const ALERT_HISTORY_RETENTION_DAYS = parseInt(process.env.ALERT_HISTORY_RETENTION_DAYS || '90')
const OAUTH_STATE_EXPIRY_MINUTES = parseInt(process.env.OAUTH_STATE_EXPIRY_MINUTES || '10')
const DRY_RUN = process.argv.includes('--dry-run')

interface CleanupMetrics {
  alertHistoryDeleted: number
  oauthStatesDeleted: number
  errors: string[]
  startTime: number
  endTime: number
}

async function main() {
  const startTime = Date.now()
  console.log('🧹 ========== DATABASE CLEANUP SCRIPT ==========\n')

  if (DRY_RUN) {
    console.log('🔍 DRY RUN MODE - No data will be deleted\n')
  }

  const metrics: CleanupMetrics = {
    alertHistoryDeleted: 0,
    oauthStatesDeleted: 0,
    errors: [],
    startTime,
    endTime: 0
  }

  // 1. Clean up old alert history
  console.log(`📋 Cleaning up alert history older than ${ALERT_HISTORY_RETENTION_DAYS} days...`)
  const alertHistoryCutoff = new Date()
  alertHistoryCutoff.setDate(alertHistoryCutoff.getDate() - ALERT_HISTORY_RETENTION_DAYS)

  try {
    // First count how many records will be deleted
    const { count: alertHistoryCount, error: countError } = await supabase
      .from('alert_history')
      .select('*', { count: 'exact', head: true })
      .lt('triggered_at', alertHistoryCutoff.toISOString())

    if (countError) {
      const errorMsg = `Error counting alert history: ${countError.message}`
      console.error('❌', errorMsg)
      metrics.errors.push(errorMsg)
    } else {
      console.log(`   Found ${alertHistoryCount || 0} old alert history records`)

      if (!DRY_RUN && alertHistoryCount && alertHistoryCount > 0) {
        const { error: deleteError } = await supabase
          .from('alert_history')
          .delete()
          .lt('triggered_at', alertHistoryCutoff.toISOString())

        if (deleteError) {
          const errorMsg = `Error deleting alert history: ${deleteError.message}`
          console.error('❌', errorMsg)
          metrics.errors.push(errorMsg)
        } else {
          metrics.alertHistoryDeleted = alertHistoryCount
          console.log(`   ✅ Deleted ${alertHistoryCount} alert history records`)
        }
      } else if (DRY_RUN && alertHistoryCount && alertHistoryCount > 0) {
        console.log(`   🔍 Would delete ${alertHistoryCount} records (dry run)`)
      } else {
        console.log('   ℹ️  No old alert history to clean up')
      }
    }
  } catch (error: any) {
    const errorMsg = `Exception cleaning alert history: ${error.message}`
    console.error('💥', errorMsg)
    metrics.errors.push(errorMsg)
  }

  // 2. Clean up expired OAuth states
  console.log(`\n🔐 Cleaning up expired OAuth states (older than ${OAUTH_STATE_EXPIRY_MINUTES} minutes)...`)
  const oauthCutoff = new Date()
  oauthCutoff.setMinutes(oauthCutoff.getMinutes() - OAUTH_STATE_EXPIRY_MINUTES)

  try {
    // First count how many records will be deleted
    const { count: oauthCount, error: countError } = await supabase
      .from('oauth_states')
      .select('*', { count: 'exact', head: true })
      .or(`expires_at.lt.${new Date().toISOString()},used.eq.true`)

    if (countError) {
      const errorMsg = `Error counting OAuth states: ${countError.message}`
      console.error('❌', errorMsg)
      metrics.errors.push(errorMsg)
    } else {
      console.log(`   Found ${oauthCount || 0} expired/used OAuth states`)

      if (!DRY_RUN && oauthCount && oauthCount > 0) {
        const { error: deleteError } = await supabase
          .from('oauth_states')
          .delete()
          .or(`expires_at.lt.${new Date().toISOString()},used.eq.true`)

        if (deleteError) {
          const errorMsg = `Error deleting OAuth states: ${deleteError.message}`
          console.error('❌', errorMsg)
          metrics.errors.push(errorMsg)
        } else {
          metrics.oauthStatesDeleted = oauthCount
          console.log(`   ✅ Deleted ${oauthCount} OAuth state records`)
        }
      } else if (DRY_RUN && oauthCount && oauthCount > 0) {
        console.log(`   🔍 Would delete ${oauthCount} records (dry run)`)
      } else {
        console.log('   ℹ️  No expired OAuth states to clean up')
      }
    }
  } catch (error: any) {
    const errorMsg = `Exception cleaning OAuth states: ${error.message}`
    console.error('💥', errorMsg)
    metrics.errors.push(errorMsg)
  }

  // Summary
  metrics.endTime = Date.now()
  const executionTime = ((metrics.endTime - metrics.startTime) / 1000).toFixed(2)

  console.log('\n📊 ========== CLEANUP SUMMARY ==========')
  console.log(JSON.stringify({
    timestamp: new Date().toISOString(),
    dryRun: DRY_RUN,
    alertHistoryDeleted: metrics.alertHistoryDeleted,
    oauthStatesDeleted: metrics.oauthStatesDeleted,
    totalDeleted: metrics.alertHistoryDeleted + metrics.oauthStatesDeleted,
    executionTimeSeconds: parseFloat(executionTime),
    errorCount: metrics.errors.length
  }, null, 2))

  if (metrics.errors.length > 0) {
    console.log('\n⚠️  Errors encountered:')
    metrics.errors.forEach((error, index) => {
      console.log(`  ${index + 1}. ${error}`)
    })
  }

  console.log('========================================\n')

  if (DRY_RUN) {
    console.log('💡 Run without --dry-run to actually delete data\n')
  }

  if (metrics.errors.length > 0) {
    process.exit(1)
  }
}

main().catch((error) => {
  console.error('💥 Fatal error:', error)
  process.exit(1)
})
