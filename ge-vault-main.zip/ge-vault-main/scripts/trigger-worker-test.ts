#!/usr/bin/env tsx
/**
 * Manually trigger worker alert processing for testing
 * This simulates what the worker does without needing to deploy
 */
import { createClient } from '@supabase/supabase-js';

const SUPABASE_URL = process.env.VITE_SUPABASE_URL || process.env.SUPABASE_URL;
const SUPABASE_SERVICE_KEY = process.env.SUPABASE_SERVICE_KEY;
const DISCORD_BOT_TOKEN = process.env.DISCORD_BOT_TOKEN;

if (!SUPABASE_URL || !SUPABASE_SERVICE_KEY || !DISCORD_BOT_TOKEN) {
  console.error('Missing env vars');
  process.exit(1);
}

const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_KEY);

async function sendDiscordDM(discordUserId: string, message: string) {
  console.log(`\n📤 Sending DM to Discord user ${discordUserId}...`);

  // First, create a DM channel with the user
  const dmResponse = await fetch('https://discord.com/api/v10/users/@me/channels', {
    method: 'POST',
    headers: {
      'Authorization': `Bot ${DISCORD_BOT_TOKEN}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      recipient_id: discordUserId,
    }),
  });

  if (!dmResponse.ok) {
    const error = await dmResponse.text();
    console.error('❌ Failed to create DM channel:', error);
    throw new Error(`Failed to create DM channel: ${error}`);
  }

  const dmChannel = await dmResponse.json();
  console.log(`✓ DM channel created: ${dmChannel.id}`);

  // Send the message
  const messageResponse = await fetch(`https://discord.com/api/v10/channels/${dmChannel.id}/messages`, {
    method: 'POST',
    headers: {
      'Authorization': `Bot ${DISCORD_BOT_TOKEN}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      content: message,
    }),
  });

  if (!messageResponse.ok) {
    const error = await messageResponse.text();
    console.error('❌ Failed to send message:', error);
    throw new Error(`Failed to send message: ${error}`);
  }

  console.log('✅ Bot DM sent successfully!');
}

async function main() {
  console.log('🔍 Fetching active bot_dm alerts...');

  const { data: alerts, error: alertsError } = await supabase
    .from('user_alerts')
    .select('*')
    .eq('active', true)
    .eq('notification_type', 'bot_dm');

  if (alertsError) {
    console.error('Failed to fetch alerts:', alertsError);
    process.exit(1);
  }

  console.log(`Found ${alerts?.length || 0} active bot_dm alerts`);

  if (!alerts || alerts.length === 0) {
    console.log('No alerts to process');
    return;
  }

  for (const alert of alerts) {
    console.log(`\n📋 Processing alert #${alert.id}:`);
    console.log(`   Item: ${alert.item_name}`);
    console.log(`   Type: ${alert.alert_type}`);
    console.log(`   Target: ${alert.target_price} gp (${alert.price_direction})`);
    console.log(`   Discord User ID: ${alert.discord_user_id}`);

    // For testing, always trigger the alert
    console.log('   ✓ Alert condition met (test mode)');

    try {
      const message = `🔔 **Price Alert from GE Vault!**\n\n` +
        `**${alert.item_name}** has reached your target!\n` +
        `Target: ${alert.target_price?.toLocaleString()} gp (${alert.price_direction})\n\n` +
        `${alert.notes || ''}`;

      await sendDiscordDM(alert.discord_user_id, message);

      // Update alert status
      if (alert.behavior === 'one_shot') {
        await supabase
          .from('user_alerts')
          .update({ active: false, last_triggered_at: new Date().toISOString(), trigger_count: alert.trigger_count + 1 })
          .eq('id', alert.id);
        console.log('   ✓ Alert deactivated (one_shot)');
      } else {
        await supabase
          .from('user_alerts')
          .update({ last_triggered_at: new Date().toISOString(), trigger_count: alert.trigger_count + 1 })
          .eq('id', alert.id);
        console.log('   ✓ Alert updated');
      }

      // Record in history
      await supabase
        .from('alert_history')
        .insert({
          alert_id: alert.id,
          item_id: alert.item_id,
          triggered_price: alert.target_price,
          trigger_type: alert.alert_type,
        });
      console.log('   ✓ Recorded in history');

    } catch (error) {
      console.error('   ❌ Failed to process alert:', error);
    }
  }

  console.log('\n✅ Done! Check Discord for the DM.');
}

main().catch(console.error);
