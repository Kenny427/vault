# Deployment Configuration

This repository automatically deploys to Cloudflare on every push to `main`.

## What Gets Deployed

1. **Cloudflare Pages** - The main React application
2. **Cloudflare Worker** - The price updater cron job

## Required GitHub Secrets

Configure these in: **Settings → Secrets and variables → Actions → Repository secrets**

### Cloudflare (for both Pages and Worker)
- `CLOUDFLARE_API_TOKEN` - Cloudflare API token with Pages and Workers permissions
  - Get from: https://dash.cloudflare.com/profile/api-tokens
  - Permissions needed: "Account - Cloudflare Pages:Edit" and "Account - Workers Scripts:Edit"
- `CLOUDFLARE_ACCOUNT_ID` - Your Cloudflare account ID
  - Get from: https://dash.cloudflare.com → Click any domain → Right sidebar

### Supabase (for build-time environment variables)
- `VITE_SUPABASE_URL` - Your Supabase project URL
- `VITE_SUPABASE_ANON_KEY` - Your Supabase anonymous key

## Worker Secrets (Cloudflare)

The Worker needs runtime secrets that are NOT in GitHub. Set these once via CLI:

```bash
cd app/worker
npx wrangler secret put SUPABASE_URL
npx wrangler secret put SUPABASE_SERVICE_KEY
```

These are stored securely in Cloudflare and persist across deployments.

## Manual Deployment

If you need to deploy manually:

```bash
# Deploy Pages
cd app
npm run build
npx wrangler pages deploy dist --project-name=ge-vault

# Deploy Worker
cd app/worker
npx wrangler deploy
```

## Viewing Deployments

- **Pages**: https://dash.cloudflare.com → Workers & Pages → ge-vault
- **Worker**: https://dash.cloudflare.com → Workers & Pages → ge-vault-price-updater
- **GitHub Actions**: https://github.com/[your-username]/ge-vault/actions
