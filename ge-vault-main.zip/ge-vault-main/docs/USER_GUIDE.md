# User Guide

Complete guide for using GE Vault to track your OSRS Grand Exchange investments.

## Table of Contents

- [Getting Started](#getting-started)
- [Managing Your Portfolio](#managing-your-portfolio)
- [Understanding Profit & Loss](#understanding-profit--loss)
- [Premium Subscription](#premium-subscription)
- [Price Alerts](#price-alerts)
- [Discord Integration](#discord-integration)
- [Account Management](#account-management)
- [FAQ](#faq)

---

## Getting Started

### What is GE Vault?

GE Vault is a web application that helps Old School RuneScape (OSRS) players track their Grand Exchange investments and get notified when prices change.

**Key Features:**
- Track unlimited portfolio items
- Real-time price updates (hourly)
- Automatic profit/loss calculation
- GE tax consideration (1% on items ≥100 gp)
- Price history charts
- Premium price alerts via Discord

---

### Creating an Account

**1. Visit GE Vault:**
- Go to https://gevault.com
- Click "Sign In" or "Get Started"

**2. Sign Up:**
- Enter your email address
- Create a strong password (minimum 8 characters)
- Click "Sign Up"

**3. Verify Email:**
- Check your email inbox
- Click the verification link
- Return to GE Vault and log in

**4. Start Tracking:**
- You'll be redirected to your dashboard
- Ready to add your first item!

---

### First Portfolio Entry

**1. Click "Add Item" Button:**
- Located in the top-right of your dashboard

**2. Search for Item:**
- Type item name (e.g., "Dragon bones")
- Autocomplete will show matching items
- Click the item you want

**3. Enter Details:**
- **Quantity:** How many you bought (e.g., 1000)
- **Buy Price:** Price per item in GP (e.g., 2500)
- **Notes:** (Optional) Reminder notes

**4. Save:**
- Click "Add to Portfolio"
- Item appears in your portfolio immediately
- Profit/loss calculated automatically

**Example:**
```
Item: Dragon bones
Quantity: 1,000
Buy Price: 2,500 gp each
Notes: "Bought for prayer training flipping"

Your Investment: 2,500,000 gp
Current Value: 2,800,000 gp (if current price is 2,800 gp)
Profit: +300,000 gp (12%)
```

---

## Managing Your Portfolio

### Viewing Your Portfolio

**Portfolio Grid:**
Your dashboard shows all items in a grid layout with:
- Item icon and name
- Quantity owned
- Buy price (what you paid)
- Current market price (high/low)
- Total invested
- Current value
- Profit/loss (absolute and percentage)
- GE tax (if applicable)

**Color Coding:**
- **Green** = Profit (current value > invested)
- **Red** = Loss (current value < invested)

---

### Adding Items

You can add the same item multiple times with different buy prices (e.g., bought at different times):

**Example:**
```
Dragon bones - Lot 1: 500 @ 2,500 gp
Dragon bones - Lot 2: 300 @ 2,700 gp
Dragon bones - Lot 3: 200 @ 2,400 gp
```

Each lot is tracked separately with its own profit/loss.

---

### Editing Items

**1. Click Edit Icon:**
- Click pencil icon on item card

**2. Update Fields:**
- Change quantity
- Change buy price
- Update notes

**3. Save Changes:**
- Click "Save"
- Calculations update automatically

**Common Use Cases:**
- Bought more of the same item
- Made a mistake in quantity
- Partially sold and want to update

---

### Deleting Items

**1. Click Delete Icon:**
- Click trash icon on item card

**2. Confirm Deletion:**
- Confirm you want to delete
- Item removed from portfolio

**When to Delete:**
- Sold all items
- No longer tracking this investment
- Made duplicate entry by mistake

---

### Portfolio Summary

At the top of your dashboard, you'll see:

**Total Invested:**
- Sum of all (quantity × buy price)
- Shows how much GP you've put in

**Current Value:**
- Sum of all (quantity × current market price)
- Shows what portfolio is worth now

**Total Profit/Loss:**
- Current Value - Total Invested - GE Tax
- Green = profit, Red = loss

**GE Tax:**
- 1% of current value for items ≥100 gp
- Automatically deducted from profit

**Profit Percentage:**
- (Profit / Total Invested) × 100%
- Example: +12.5% means you're up 12.5%

**Item Count:**
- How many different lots you're tracking
- Free tier: Up to 50 items
- Premium: Unlimited

---

### Price History Charts

**View Price Trends:**
1. Click on any item card
2. Price history chart appears (if available)
3. Shows last 30 days of price data
4. Hover over chart to see specific prices

**Chart Features:**
- Blue line = High price
- Orange line = Low price
- X-axis = Date
- Y-axis = Price in GP

**Use Cases:**
- Spot price trends (rising/falling)
- Find best time to sell
- Understand market volatility

---

## Understanding Profit & Loss

### How Profit is Calculated

**Basic Formula:**
```
Current Value = Quantity × Current Market Price
Total Invested = Quantity × Buy Price
GE Tax = Current Value × 1% (if item ≥100 gp)
Profit/Loss = Current Value - Total Invested - GE Tax
```

**Example:**
```
Item: Abyssal whip
Quantity: 10
Buy Price: 2,000,000 gp each
Current Price: 2,200,000 gp each

Total Invested: 10 × 2,000,000 = 20,000,000 gp
Current Value: 10 × 2,200,000 = 22,000,000 gp
GE Tax: 22,000,000 × 1% = 220,000 gp
Profit: 22,000,000 - 20,000,000 - 220,000 = 1,780,000 gp
Profit %: (1,780,000 / 20,000,000) × 100% = 8.9%
```

---

### GE Tax Explained

**What is GE Tax?**
When you sell items on the Grand Exchange, OSRS takes a 1% tax on items worth 100 gp or more.

**How GE Vault Handles It:**
- Automatically calculates 1% tax on items ≥100 gp
- Deducts from profit/loss
- Shows tax amount separately in summary

**Example:**
```
Without tax consideration:
Profit: 300,000 gp ❌ (incorrect)

With tax (GE Vault):
Profit: 270,000 gp ✅ (correct)
Tax: 30,000 gp
```

This gives you a realistic view of actual profit after selling.

---

### High vs Low Prices

**Why Two Prices?**
- **High Price:** Instant buy price (buy offers)
- **Low Price:** Instant sell price (sell offers)
- Spread = difference between high and low

**Which Price is Used?**
- GE Vault uses **high price** for profit calculation
- Assumes you'll instant-sell at high price
- More conservative than using low price

**Example:**
```
Dragon bones:
High: 2,800 gp (instant buy)
Low: 2,750 gp (instant sell)

Your lot: 1,000 Dragon bones
Current Value: 1,000 × 2,800 = 2,800,000 gp (high price used)
```

---

## Premium Subscription

### What is Premium?

Premium unlocks price alerts - get notified via Discord when item prices hit your targets.

**Premium Features:**
- Unlimited price alerts
- Discord DM notifications
- Discord webhook notifications
- Email notifications (coming soon)
- Priority support

**Free Tier:**
- Unlimited portfolio tracking
- Real-time price updates
- Price history charts
- No alerts

---

### Subscription Tiers

**☕ Coffee ($2/month or $20/year)**
- Support GE Vault development
- All premium features
- Cancel anytime

**⭐ Standard ($5/month or $50/year)**
- Standard premium tier
- All premium features
- Cancel anytime

**🚀 Super ($10/month or $100/year)**
- Premium features + extra support
- Help fund new features
- Cancel anytime

**💖 Custom ($2-999/month)**
- Choose your own amount
- Support development
- All premium features

**Annual Billing:**
- Save ~16% compared to monthly
- Example: $20/year vs $24/year (monthly × 12)

---

### Subscribing to Premium

**1. Click "Go Premium" Button:**
- Located in top-right corner
- Or when trying to create an alert

**2. Select Tier:**
- Choose Coffee, Standard, Super, or Custom
- If Custom, enter amount ($2-999)

**3. Select Billing:**
- Monthly or Annual
- Annual saves ~16%

**4. Checkout:**
- Redirects to secure Stripe checkout
- Enter payment details
- Click "Subscribe"

**5. Confirmation:**
- Redirected back to GE Vault
- "Premium Active" badge appears
- Can now create alerts

**Payment Methods Accepted:**
- Credit/debit cards (Visa, Mastercard, Amex)
- Digital wallets (Apple Pay, Google Pay)
- Bank transfers (varies by country)

---

### Managing Subscription

**Access Customer Portal:**
1. Click profile menu (top-right)
2. Click "Manage Subscription"
3. Redirects to Stripe Customer Portal

**In Customer Portal You Can:**
- Update payment method
- View payment history
- Download invoices
- Update billing address
- Cancel subscription
- Resume canceled subscription

**Canceling Subscription:**
1. Click "Manage Subscription"
2. Click "Cancel subscription"
3. Confirm cancellation
4. Subscription remains active until end of billing period
5. No refunds for partial periods

**What Happens After Canceling:**
- Access to premium features until period ends
- Existing alerts stop triggering after period ends
- Alert history remains viewable
- Portfolio tracking continues (free tier)

---

## Price Alerts

**Premium Feature - Requires active subscription**

### What are Price Alerts?

Get notified via Discord when item prices reach your target.

**Use Cases:**
- "Alert me when Dragon bones drop below 2,500 gp" (buy opportunity)
- "Alert me when Abyssal whip rises above 2,500,000 gp" (sell signal)
- "Alert me when Twisted bow changes by 5%" (volatility tracking)

---

### Alert Types

**1. Absolute Price Alerts:**
Trigger when price reaches exact GP amount.

**Examples:**
```
Item: Dragon bones
Type: Absolute
Target: 2,500 gp
Direction: Down (below)
→ Notifies when price drops to 2,500 gp or below

Item: Abyssal whip
Type: Absolute
Target: 2,500,000 gp
Direction: Up (above)
→ Notifies when price rises to 2,500,000 gp or above
```

**2. Percentage Change Alerts:**
Trigger when price changes by percentage from baseline.

**Examples:**
```
Item: Twisted bow
Type: Percentage
Baseline: 1,000,000,000 gp (current price)
Threshold: 10%
Direction: Either
→ Notifies when price changes ±10% from 1B
   (below 900M or above 1.1B)

Item: Dragon claws
Type: Percentage
Baseline: 50,000,000 gp
Threshold: 5%
Direction: Down
→ Notifies when price drops 5% from 50M (below 47.5M)
```

---

### Alert Behaviors

**1. One-Shot:**
- Alert triggers once
- Automatically deactivates after triggering
- Good for: Single buy/sell opportunities

**Example:**
```
"Alert me once when Dragon bones drop below 2,500 gp,
then stop alerting"
```

**2. Recurring:**
- Alert triggers every time condition is met
- Stays active after triggering
- Good for: Monitoring ongoing opportunities

**Example:**
```
"Alert me every time Dragon bones drop below 2,500 gp
(could trigger multiple times if price fluctuates)"
```

**3. Cooldown:**
- Alert triggers, then waits X hours before next trigger
- Stays active but rate-limited
- Good for: Avoiding spam from volatile markets

**Example:**
```
"Alert me when Dragon bones drop below 2,500 gp,
but only once every 24 hours"

Cooldown options: 1-168 hours (1 hour - 1 week)
```

---

### Creating an Alert

**1. Go to Alerts Page:**
- Click "Alerts" in navigation

**2. Connect Discord (First Time Only):**
- Click "Connect Discord"
- Authorize GE Vault app
- Return to alerts page

**3. Click "Create Alert":**
- Alert creation form appears

**4. Fill in Alert Details:**

**Basic Info:**
- **Item:** Search and select item
- **Alert Type:** Absolute or Percentage
- **Direction:** Up, Down, or Either

**Price Settings:**
- **For Absolute:** Enter target price (e.g., 2500)
- **For Percentage:**
  - Enter baseline price (e.g., current price)
  - Enter percentage threshold (e.g., 10)

**Notification:**
- **Type:** Bot DM or Webhook
- **For Bot DM:** Uses your connected Discord account
- **For Webhook:** Enter Discord webhook URL

**Behavior:**
- **Type:** One-shot, Recurring, or Cooldown
- **For Cooldown:** Enter hours (1-168)

**Optional:**
- **Notes:** Reminder for yourself (e.g., "Buy for merch")

**5. Save Alert:**
- Click "Create Alert"
- Alert appears in your list
- Worker checks hourly

---

### Using Alert Templates

**Quick Setup with Templates:**
GE Vault provides pre-configured templates for popular items:

**Available Templates:**
- Dragon bones (buy low)
- Abyssal whip (sell high)
- Twisted bow (volatility tracker)
- And more...

**How to Use:**
1. Click "Use Template" on template card
2. Form pre-fills with template values
3. Adjust values if needed
4. Save alert

**Customizing Templates:**
- Change target price
- Change notification type
- Change behavior
- Add notes

---

### Managing Alerts

**View All Alerts:**
- Go to Alerts page
- See list of active and inactive alerts

**Alert Card Shows:**
- Item name
- Alert type and condition
- Target price / threshold
- Notification type
- Last triggered (if ever)
- Trigger count
- Active status

**Edit Alert:**
1. Click "Edit" on alert card
2. Modify any field
3. Click "Save"

**Pause Alert:**
1. Click toggle switch on alert card
2. Alert becomes inactive
3. Won't trigger until re-enabled
4. Click again to reactivate

**Delete Alert:**
1. Click "Delete" button
2. Confirm deletion
3. Alert removed permanently

---

### Alert Notifications

**Discord Bot DM:**
When alert triggers, you receive a Discord DM:

```
🔔 **Price Alert!**

**Dragon bones** is now **2,450** gp!

Your alert for "Dragon bones" has triggered.
Target: 2,500 gp (down)
Current Price: 2,450 gp

Alert ID: 123
```

**Discord Webhook:**
Message posted to your configured webhook channel:

```
🔔 **Price Alert!**

**Twisted bow** changed by **11.2%**!

Your alert for "Twisted bow" has triggered.
Baseline: 1,000,000,000 gp
Change: +11.2% (112,000,000 gp)
Current Price: 1,112,000,000 gp

Alert ID: 456
```

**Notification Frequency:**
- Worker checks alerts every hour (top of the hour)
- Maximum 1 notification per hour per alert
- Cooldown alerts respect cooldown period

---

### Alert History

**View Past Triggers:**
1. Go to Alerts page
2. Click "History" tab
3. See all past alert triggers

**History Shows:**
- Alert name
- Triggered at (date/time)
- Trigger price
- Target price
- Notification type
- Success/failure status
- Error message (if failed)

**Use Cases:**
- Confirm alert triggered
- Track market movements
- Debug notification issues
- Historical price tracking

---

## Discord Integration

### Connecting Discord

**Why Connect Discord?**
Required for Discord bot DM notifications (price alerts).

**How to Connect:**
1. Go to Alerts page
2. Click "Connect Discord"
3. Redirected to Discord authorization page
4. Click "Authorize"
5. Redirected back to GE Vault
6. "Discord Connected" badge appears

**What GE Vault Can Access:**
- Your Discord user ID
- Your Discord username
- Nothing else (minimal permissions)

**What GE Vault Cannot Access:**
- Your messages
- Your servers
- Your friends list
- Your account password

---

### Discord DM Notifications

**How it Works:**
1. You create alert with "Bot DM" notification
2. Worker checks alert hourly
3. When triggered, bot sends you a DM
4. You receive notification in Discord

**Requirements:**
- Discord account connected
- Premium subscription active
- Alert set to "bot_dm" notification type
- Discord DMs enabled (user setting)

**If You Don't Receive DMs:**
- Check Discord privacy settings:
  - User Settings > Privacy & Safety
  - Enable "Allow direct messages from server members"
- Check you're not blocking the bot
- Check Discord connection is active
- Check alert is active

---

### Discord Webhook Notifications

**What is a Webhook?**
A webhook is a URL that Discord provides to post messages to a specific channel.

**Use Cases:**
- Post alerts to a private Discord server
- Share alerts with a team
- Log all alerts to a dedicated channel

**How to Get Webhook URL:**
1. Go to your Discord server
2. Right-click channel > "Edit Channel"
3. Go to "Integrations" > "Webhooks"
4. Click "New Webhook"
5. Copy webhook URL
6. Paste into GE Vault alert form

**Webhook URL Format:**
```
https://discord.com/api/webhooks/123456789/AbCdEfGhIjKlMnOpQrStUvWxYz
```

**Security:**
- Keep webhook URLs private
- Anyone with URL can post to your channel
- Delete webhook if compromised

---

### Disconnecting Discord

**When to Disconnect:**
- No longer using Discord alerts
- Switching Discord accounts
- Troubleshooting connection issues

**How to Disconnect:**
1. Go to Alerts page
2. Click "Disconnect Discord"
3. Confirm disconnection
4. Discord connection removed

**What Happens:**
- Existing bot_dm alerts become inactive
- Can't create new bot_dm alerts
- Can still use webhook alerts (with URL)
- Alert history remains

**Reconnecting:**
- Click "Connect Discord" again
- Go through authorization flow
- Existing alerts stay inactive (manually re-enable)

---

## Account Management

### Profile Settings

**Access Profile:**
1. Click profile icon (top-right)
2. View account details:
   - Email address
   - Subscription status
   - Member since date

---

### Changing Password

**How to Change:**
1. Go to profile
2. Click "Change Password"
3. Enter current password
4. Enter new password (minimum 8 characters)
5. Confirm new password
6. Click "Update Password"

**Forgot Password:**
1. Go to login page
2. Click "Forgot password?"
3. Enter email address
4. Check email for reset link
5. Click link and set new password

---

### Email Verification

**Why Verify?**
- Ensures you can recover account
- Required for some features
- Improves account security

**Resend Verification Email:**
1. Go to profile
2. Click "Resend verification email"
3. Check inbox
4. Click verification link

---

### Deleting Account

**Warning: This is permanent and cannot be undone**

**What Gets Deleted:**
- Your account
- All portfolio items
- All price alerts
- Alert history
- Subscription (if active)

**What Doesn't Get Deleted:**
- Stripe subscription (cancel separately)

**How to Delete:**
1. Contact support
2. Confirm deletion request
3. Account deleted within 24 hours

**Before Deleting:**
- Export portfolio data (if needed)
- Cancel subscription
- Download invoices

---

## FAQ

### General Questions

**Q: How often do prices update?**
A: Prices update every hour at the top of the hour (e.g., 1:00, 2:00, 3:00). The worker fetches latest prices from OSRS Wiki API.

**Q: Where do prices come from?**
A: Prices come from the official OSRS Wiki Prices API, which aggregates real Grand Exchange data from in-game.

**Q: Are prices accurate?**
A: Yes, prices are the actual current Grand Exchange prices. However, they update hourly, so very recent changes may not show immediately.

**Q: Why is my profit different from in-game?**
A: GE Vault accounts for the 1% GE tax on items worth 100+ gp. In-game, you won't see profit until after selling and paying tax.

**Q: Can I track F2P and P2P items?**
A: Yes, GE Vault tracks all tradeable items on the Grand Exchange, both F2P and P2P.

---

### Portfolio Questions

**Q: Is there a limit to portfolio items?**
A: Free tier: 50 items maximum. Premium: Unlimited items.

**Q: Can I add the same item multiple times?**
A: Yes! You can track multiple "lots" of the same item with different buy prices.

**Q: What happens if I sell items in-game?**
A: GE Vault doesn't sync with your in-game account. You manually update or delete items as you sell them.

**Q: Can I import my portfolio from elsewhere?**
A: Not currently. You must add items manually. Bulk import feature planned for future.

**Q: Why are some items not in the database?**
A: Only tradeable Grand Exchange items are available. Untradeable items (quest items, minigame rewards, etc.) are not tracked.

---

### Alert Questions

**Q: How fast do alerts trigger?**
A: Worker checks alerts every hour. If price meets condition, notification sent within minutes.

**Q: Can I get alerts via email?**
A: Not yet. Currently only Discord notifications. Email alerts coming soon.

**Q: Why didn't I get an alert notification?**
A: Check:
1. Alert is active (not paused)
2. Premium subscription active
3. Discord connected (for bot DM)
4. Price actually met condition
5. Cooldown period hasn't expired
6. Discord DMs enabled

**Q: Can I set alerts for multiple items at once?**
A: Not currently. You create alerts one at a time. Bulk alert creation planned for future.

**Q: Do alerts work for historical prices?**
A: No. Alerts only check current prices going forward. They don't retroactively check past prices.

---

### Subscription Questions

**Q: Can I cancel anytime?**
A: Yes, cancel anytime. You keep premium access until end of current billing period.

**Q: Do you offer refunds?**
A: No refunds for partial periods. You keep access until period ends.

**Q: What payment methods are accepted?**
A: All major credit/debit cards, Apple Pay, Google Pay, and bank transfers (varies by country).

**Q: Is my payment information secure?**
A: Yes. All payments processed by Stripe (PCI DSS Level 1 certified). GE Vault never sees your card details.

**Q: Can I change billing from monthly to annual?**
A: Yes, in Stripe Customer Portal. New billing starts at next renewal.

**Q: What happens if payment fails?**
A: You'll receive email from Stripe. Subscription marked "Past Due". Premium features disabled after grace period (usually 3 days).

---

### Technical Questions

**Q: Does GE Vault work on mobile?**
A: Yes, responsive design works on phones and tablets. Native mobile app planned for future.

**Q: Which browsers are supported?**
A: All modern browsers: Chrome, Firefox, Safari, Edge. Internet Explorer not supported.

**Q: Is my data private?**
A: Yes. Your portfolio is private. Only you can see it. We don't share data with third parties.

**Q: Can I export my data?**
A: Not currently. Data export feature planned for future.

**Q: Does GE Vault access my RuneScape account?**
A: No. GE Vault is not affiliated with Jagex. It doesn't access your OSRS account or require game credentials.

---

### Troubleshooting

**Q: I can't log in. What do I do?**
A: Try:
1. Reset password
2. Check email verification
3. Clear browser cache
4. Try different browser
5. Contact support

**Q: Prices aren't updating. Why?**
A: Check:
1. OSRS Wiki API status
2. Last update time (should be within 1 hour)
3. Try refreshing page
4. Check if worker is running (contact support)

**Q: Alert triggered but I didn't get notification. Why?**
A: Check Alert History for error message. Common causes:
1. Discord connection expired (reconnect)
2. Discord DMs disabled (enable in settings)
3. Webhook URL invalid (update webhook)

---

## Getting Help

**Need Help?**

1. **Check Documentation:**
   - This guide covers most user questions
   - [Troubleshooting Guide](./TROUBLESHOOTING.md) for common issues

2. **Check FAQ:**
   - Scroll up to FAQ section
   - Most common questions answered

3. **Contact Support:**
   - Email: support@gevault.com
   - GitHub Issues: https://github.com/GEVault/ge-vault/issues
   - Response time: Usually within 24 hours

4. **Report Bugs:**
   - Create GitHub issue with details
   - Include screenshots if possible
   - Describe steps to reproduce

---

**Last Updated:** January 2025
**User Guide Version:** 1.0
