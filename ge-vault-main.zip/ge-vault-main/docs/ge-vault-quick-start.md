# GE Vault - Quick Start Guide

**Goal:** Launch MVP in 2-3 weeks as standalone product

**⚠️ Important Note:** The git repository is located at the project root. The application code is in the `app/` subdirectory.
All npm commands should be run from `ge-vault/app/`, and git commands from the root `ge-vault/`.

---

## Week 1: Foundation

### Day 1-2: Setup & Domain

**Tasks:**
- [x] Domain purchased: gevault.com via Cloudflare Registrar ($10.46/year) ✅
- [ ] Create Supabase project: https://supabase.com/dashboard
  - Project name: "ge-vault-prod"
  - Region: Choose closest to target users (US East for NA)
  - Database password: Save securely
- [ ] Create GitHub repo: "ge-vault"
  - Initialize with React + TypeScript + Vite template
  - Add .gitignore for node_modules, .env, etc.

**Estimated time:** 1-2 hours (domain already done!)

---

### Day 3-4: Database Schema

**Tasks:**
- [ ] Connect to Supabase and run schema SQL
- [ ] Enable Row Level Security (RLS) policies
- [ ] Seed items table with OSRS Wiki data
- [ ] Test database connections

**SQL to run in Supabase SQL Editor:**

```sql
-- All OSRS items (seeded once from Wiki)
CREATE TABLE items (
  id INTEGER PRIMARY KEY,
  name TEXT NOT NULL,
  icon_url TEXT,
  examine TEXT,
  members BOOLEAN DEFAULT false,
  created_at TIMESTAMP DEFAULT NOW()
);

-- Current prices for ALL items (updated daily)
CREATE TABLE item_prices_current (
  item_id INTEGER PRIMARY KEY REFERENCES items(id),
  high_price BIGINT,
  low_price BIGINT,
  high_volume BIGINT,
  low_volume BIGINT,
  updated_at TIMESTAMP DEFAULT NOW()
);

-- Historical prices (all items, hourly snapshots)
-- Note: Use the migration file at app/worker/price_history_migration.sql instead
-- This table is automatically populated by the Cloudflare Worker
CREATE TABLE price_history (
  id BIGSERIAL PRIMARY KEY,
  item_id INT NOT NULL REFERENCES items(id) ON DELETE CASCADE,
  price BIGINT NOT NULL,
  price_type VARCHAR(10) NOT NULL CHECK (price_type IN ('high', 'low')),
  timestamp TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_price_history_item_time ON price_history (item_id, timestamp DESC);
CREATE INDEX idx_price_history_timestamp ON price_history (timestamp DESC);

-- User portfolios
CREATE TABLE portfolio_items (
  id SERIAL PRIMARY KEY,
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  item_id INTEGER REFERENCES items(id),
  quantity INTEGER NOT NULL CHECK (quantity > 0),
  buy_price BIGINT NOT NULL CHECK (buy_price > 0),
  date_purchased DATE NOT NULL,
  notes TEXT,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);
CREATE INDEX idx_portfolio_user ON portfolio_items(user_id);
CREATE INDEX idx_portfolio_item ON portfolio_items(item_id);

-- Enable Row Level Security
ALTER TABLE portfolio_items ENABLE ROW LEVEL SECURITY;

-- Users can only see their own portfolio items
CREATE POLICY "Users can view own portfolio items"
  ON portfolio_items FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own portfolio items"
  ON portfolio_items FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own portfolio items"
  ON portfolio_items FOR UPDATE
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete own portfolio items"
  ON portfolio_items FOR DELETE
  USING (auth.uid() = user_id);

-- Items and prices are public (read-only)
ALTER TABLE items ENABLE ROW LEVEL SECURITY;
ALTER TABLE item_prices_current ENABLE ROW LEVEL SECURITY;
ALTER TABLE price_history ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Items are viewable by everyone"
  ON items FOR SELECT
  USING (true);

CREATE POLICY "Current prices are viewable by everyone"
  ON item_prices_current FOR SELECT
  USING (true);

CREATE POLICY "Historical prices are viewable by everyone"
  ON price_history FOR SELECT
  USING (true);
```

**Seed items data:**
- Download OSRS Wiki item mapping: https://prices.runescape.wiki/api/v1/osrs/mapping
- Write script to insert into `items` table
- ~10,000 tradeable items

**Estimated time:** 4-5 hours

---

### Day 5-7: Auth & Basic UI

**Tasks:**
- [ ] Set up Supabase Auth (email + magic link)
- [ ] Create basic React app structure:
  - `/` - Landing page
  - `/login` - Login/signup
  - `/dashboard` - Portfolio view (protected route)
- [ ] Build auth components (login, signup, password reset)
- [ ] Test auth flow end-to-end

**Tech stack setup:**
```bash
npm create vite@latest ge-vault -- --template react-ts
cd ge-vault
npm install @supabase/supabase-js
npm install react-router-dom
npm install tailwindcss postcss autoprefixer
npm install recharts # for charts later
```

**Estimated time:** 8-10 hours

---

## Week 2: Core Features

### Day 8-10: Add Items to Portfolio

**Features to build:**
- [ ] Item search autocomplete (search `items` table)
- [ ] Add item form:
  - Item selection
  - Quantity input
  - Buy price input (GP)
  - Date purchased picker
  - Optional notes
- [ ] Submit to `portfolio_items` table
- [ ] Success/error handling

**UI Components needed:**
- ItemSearchInput (with autocomplete)
- AddItemForm
- ItemCard (preview before adding)

**Estimated time:** 6-8 hours

---

### Day 11-14: View Portfolio

**Features to build:**
- [ ] Fetch user's portfolio items with current prices
- [ ] Display portfolio table/cards:
  - Item name + icon
  - Quantity
  - Buy price (per item + total)
  - Current price (per item + total)
  - Profit/loss ($ and %)
  - Date purchased
- [ ] Portfolio summary stats:
  - Total invested
  - Current value
  - Total profit/loss
  - Best/worst performing items
- [ ] Delete item from portfolio
- [ ] Edit item (quantity, buy price, notes)

**SQL query for portfolio view:**
```sql
SELECT 
  pi.id,
  pi.quantity,
  pi.buy_price,
  pi.date_purchased,
  pi.notes,
  i.name,
  i.icon_url,
  ipc.high_price as current_price,
  ipc.updated_at as price_updated_at,
  (ipc.high_price * pi.quantity) as current_value,
  ((ipc.high_price - pi.buy_price) * pi.quantity) as total_profit,
  ((ipc.high_price - pi.buy_price) / pi.buy_price::float * 100) as profit_percentage
FROM portfolio_items pi
JOIN items i ON pi.item_id = i.id
JOIN item_prices_current ipc ON i.id = ipc.item_id
WHERE pi.user_id = $1
ORDER BY pi.date_purchased DESC;
```

**Estimated time:** 10-12 hours

---

## Week 3: Automation & Polish

### Day 15-17: Price Updates (Cron + Manual Refresh)

**Set up Cloudflare Workers:**

**Step 1: Create /functions directory**
```bash
# In your project root
mkdir -p functions/api

# Files in /functions automatically become API routes
# Example: /functions/api/refresh-prices.ts → /api/refresh-prices
```

**Step 2: Manual Refresh Endpoint**
- [ ] Create `/functions/api/refresh-prices.ts`
- [ ] Logic:
  - Check `item_prices_current.updated_at` timestamp
  - If < 15 minutes: return cached (prevent spam)
  - If > 15 minutes: fetch from OSRS Wiki API
  - Upsert all prices to `item_prices_current`
  - Return success + timestamp
- [ ] Add environment variables in Cloudflare dashboard:
  - `SUPABASE_URL`
  - `SUPABASE_SERVICE_KEY`

**Step 3: Frontend Refresh Button**
- [ ] Add "Refresh Prices" button to portfolio dashboard
- [ ] Show "Last updated: X ago" timestamp
- [ ] Handle loading states
- [ ] Show success message after refresh

**Step 4: Cron Worker (Daily Auto-Update)**
- [ ] Create `wrangler.toml` in project root:
  ```toml
  name = "ge-vault-cron"
  [triggers]
  crons = ["0 0 * * *"]  # Daily at midnight UTC
  ```
- [ ] Create cron worker that uses same update logic
- [ ] Deploy: `wrangler deploy`

**Step 5: Shared Update Logic**
- [ ] Extract `updatePrices()` function
- [ ] Used by both manual refresh AND cron
- [ ] Prevents code duplication

**Cron schedule:** Run daily at 00:00 UTC

**Key insight:** One user's manual refresh updates prices for everyone (shared cache)

**Estimated time:** 6-8 hours

---

### Day 18-21: Polish & Deploy

**Tasks:**
- [ ] Add loading states
- [ ] Add error handling
- [ ] Improve mobile responsiveness
- [ ] Add Ko-fi donation button
- [ ] Create landing page (marketing copy)
- [ ] Set up analytics (Plausible or similar)
- [ ] Deploy to Cloudflare Pages:
  - Run: `npm run build`
  - Run: `npx wrangler pages deploy dist --project-name=ge-vault`
  - Configure custom domain in Cloudflare dashboard (gevault.com)
  - Set environment variables (Supabase keys)
- [ ] Test in production
- [ ] Write launch post for r/2007scape

**Estimated time:** 8-10 hours

---

## Post-Launch: Week 4+

### Monitoring & Iteration
- [ ] Monitor user signups and portfolio additions
- [ ] Gather feedback via Discord/Reddit
- [ ] Fix bugs and UX issues
- [ ] Track analytics:
  - Daily/weekly active users
  - Portfolio items added
  - Retention rate

### Phase 2 Features (if traction is good)
- [ ] 30-day price history charts
- [ ] Item detail pages
- [ ] Export portfolio (CSV)
- [ ] Performance analytics

---

## Key Resources

**Supabase Docs:**
- Auth: https://supabase.com/docs/guides/auth
- Database: https://supabase.com/docs/guides/database
- Row Level Security: https://supabase.com/docs/guides/auth/row-level-security

**OSRS Wiki API:**
- Real-time prices: https://prices.runescape.wiki/api/v1/osrs/latest
- Item mapping: https://prices.runescape.wiki/api/v1/osrs/mapping
- API docs: https://oldschool.runescape.wiki/w/RuneScape:Real-time_Prices

**Cloudflare:**
- Pages deployment: https://developers.cloudflare.com/pages/
- Workers: https://developers.cloudflare.com/workers/
- Cron triggers: https://developers.cloudflare.com/workers/configuration/cron-triggers/
- Custom domains: https://developers.cloudflare.com/pages/configuration/custom-domains/

---

## Environment Variables Needed

Create `.env.local` in your project root:

```bash
# Supabase
VITE_SUPABASE_URL=https://your-project.supabase.co
VITE_SUPABASE_ANON_KEY=your-anon-key

# Analytics (optional)
VITE_PLAUSIBLE_DOMAIN=gevault.com
```

For Cloudflare Worker (cron job):
```bash
SUPABASE_URL=https://your-project.supabase.co
SUPABASE_SERVICE_KEY=your-service-role-key # Note: service key, not anon
```

---

## Success Criteria for MVP

**Technical:**
- ✅ Users can sign up and log in
- ✅ Users can add items to portfolio
- ✅ Portfolio displays with current prices
- ✅ Prices update daily automatically
- ✅ Site is live on custom domain

**User Metrics (first 30 days):**
- Target: 50+ signups
- Target: 500+ portfolio items added
- Target: 20+ weekly active users

**Decision point:** If metrics are hit, proceed to Phase 2 (historical data + charts). If not, gather feedback and iterate on core value prop.

---

## Budget

**Costs (monthly):**
- Domain: ~$1/month (annual payment - already paid $10.46)
- Supabase: $0 (free tier - unlimited projects, 500MB per project, 50k MAU per project)
- Cloudflare Pages: $0 (free tier - unlimited builds)
- Cloudflare Workers: $0 (free tier - 100k requests/day)

**Total: ~$1/month until you need to scale**

When you hit free tier limits:
- Supabase Pro: $25/month per project (8GB storage, 100k MAU)
- Cloudflare Workers Paid: $5/month (10M requests/day)

---

## Marketing Launch Plan

**Day 1: Soft Launch**
- Post to r/2007scape: "I built a tool to track your OSRS items long-term"
- Keep it humble, ask for feedback
- Post during peak hours (6-8pm EST)

**Week 1: Community Feedback**
- Engage with comments
- Fix reported bugs quickly
- Gather feature requests

**Week 2: Expand Reach**
- Post to OSRS Discord servers (flipping, merchanting communities)
- Share on OSRS Twitter/X
- Consider OSRS YouTuber outreach (small creators)

**Month 2+: Content Marketing**
- Blog: "Best OSRS Items to Merch in 2025"
- Blog: "I Tracked a 1B Bank for 30 Days"
- Cross-promote with Flip Dashboard

---

## Next Immediate Step

**RIGHT NOW:** Go to Namecheap and check if `gevault.com` is available. If yes, buy it (~$12/year). If not, check `runevault.com` or `longhold.gg`.

**THEN:** Create Supabase project and GitHub repo. You're off to the races.
