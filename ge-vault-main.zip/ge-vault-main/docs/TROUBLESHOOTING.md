# Troubleshooting Guide

Common issues and solutions for GE Vault.

## Table of Contents

- [Alerts Not Triggering](#alerts-not-triggering)
- [Build Failing in CI/CD](#build-failing-in-cicd)
- [Discord Connection Issues](#discord-connection-issues)
- [Stripe Payment Problems](#stripe-payment-problems)
- [Authentication Errors](#authentication-errors)
- [Database Connection Issues](#database-connection-issues)
- [Worker Not Running](#worker-not-running)
- [Price Data Not Updating](#price-data-not-updating)
- [Portfolio Items Not Loading](#portfolio-items-not-loading)
- [Performance Issues](#performance-issues)
- [Deployment Failures](#deployment-failures)
- [CORS Errors](#cors-errors)
- [Missing Environment Variables](#missing-environment-variables)
- [TypeScript Build Errors](#typescript-build-errors)
- [Test Failures](#test-failures)

---

## Alerts Not Triggering

### Symptoms
- Alert created successfully
- Alert shows as "Active"
- No Discord DM or webhook received
- Worker runs hourly but no notifications

### Diagnosis Steps

**1. Check Worker Logs:**
```bash
wrangler tail

# Look for:
# - "Price update completed"
# - "Checked X alerts"
# - "Triggered X alerts"
# - Any error messages
```

**2. Verify Alert Configuration:**
```sql
-- In Supabase SQL Editor
SELECT * FROM user_alerts
WHERE user_id = 'YOUR_USER_ID'
AND active = true;

-- Check:
-- - active = true
-- - item_id is correct
-- - target_price matches expectation
-- - notification_type is 'bot_dm' or 'webhook'
```

**3. Check Discord Connection:**
```sql
SELECT * FROM discord_connections
WHERE user_id = 'YOUR_USER_ID';

-- Verify:
-- - Record exists (for bot_dm alerts)
-- - token_expires_at > NOW()
-- - discord_user_id is populated
```

**4. Check Current Price:**
```sql
SELECT * FROM item_prices_current
WHERE item_id = 'ITEM_ID';

-- Compare with alert target_price
-- Does current price meet the condition?
```

**5. Check Alert History:**
```sql
SELECT * FROM alert_history
WHERE alert_id = ALERT_ID
ORDER BY triggered_at DESC
LIMIT 10;

-- If notification_sent = false, check notification_error column
```

---

### Solutions

**Worker Not Deployed:**
```bash
cd app/worker
wrangler deploy
```

**Discord Token Expired:**
```sql
-- Check expiry
SELECT token_expires_at FROM discord_connections
WHERE user_id = 'YOUR_USER_ID';

-- If expired, user must reconnect Discord
-- Go to /alerts page > "Disconnect Discord" > "Connect Discord"
```

**Bot Token Missing:**
```bash
# Set Discord bot token in worker
wrangler secret put DISCORD_BOT_TOKEN
# Paste your bot token
```

**Alert Condition Not Met:**
```
Current price: 5,500 gp
Target price: 5,000 gp
Direction: down

Issue: Current price is still above target
Solution: Wait for price to drop, or adjust target price
```

**One-Shot Alert Already Triggered:**
```sql
-- Check if alert has fired before
SELECT * FROM alert_history
WHERE alert_id = ALERT_ID
AND notification_sent = true;

-- If record exists, alert won't fire again (one_shot behavior)
-- Solution: Create new alert or change behavior to 'recurring'
```

**Cooldown Period Active:**
```sql
-- Check last trigger time
SELECT last_triggered_at, cooldown_hours
FROM user_alerts
WHERE id = ALERT_ID;

-- If last_triggered_at + cooldown_hours > NOW(), alert is cooling down
-- Solution: Wait for cooldown to expire
```

**Discord Webhook URL Invalid:**
```sql
SELECT discord_webhook_url FROM user_alerts WHERE id = ALERT_ID;

-- Verify URL:
-- - Contains 'discord.com'
-- - Contains '/api/webhooks/'
-- - Format: https://discord.com/api/webhooks/ID/TOKEN
```

**Worker Environment Variables Missing:**
```bash
# List current secrets
wrangler secret list

# Required secrets:
# - SUPABASE_URL
# - SUPABASE_SERVICE_KEY
# - DISCORD_BOT_TOKEN
# - DISCORD_CLIENT_ID
# - DISCORD_CLIENT_SECRET

# Add missing secrets
wrangler secret put MISSING_SECRET_NAME
```

---

## Build Failing in CI/CD

### Symptoms
- GitHub Actions workflow fails on build step
- Red X on commit in GitHub
- Deployment doesn't update

### Diagnosis Steps

**1. Check GitHub Actions Logs:**
- Go to repository > Actions tab
- Click failed workflow run
- Expand "Build" step
- Read error message

**2. Common Error Patterns:**
```
Error: Type error in src/pages/Dashboard.tsx
Error: Module not found: '../components/AlertForm'
Error: Property 'xyz' does not exist on type 'User'
```

---

### Solutions

**TypeScript Errors in Test Files:**
```bash
# Check tsconfig.app.json
cat app/tsconfig.app.json

# Ensure test files are excluded:
{
  "exclude": [
    "src/**/*.test.tsx",
    "src/**/*.test.ts",
    "src/**/__tests__"
  ]
}
```

**Missing Environment Variables:**
```bash
# Add to GitHub repository secrets
# Settings > Secrets and variables > Actions > New repository secret

Required secrets:
- VITE_SUPABASE_URL
- VITE_SUPABASE_ANON_KEY
- SUPABASE_SERVICE_KEY
- DISCORD_CLIENT_ID
- DISCORD_CLIENT_SECRET
- STRIPE_SECRET_KEY
- STRIPE_WEBHOOK_SECRET
- CLOUDFLARE_API_TOKEN
- CLOUDFLARE_ACCOUNT_ID
```

**Dependency Installation Failure:**
```bash
# Clear npm cache (in GitHub Actions)
# Add to workflow file:
- name: Clear cache
  run: npm cache clean --force

- name: Install dependencies
  run: npm ci
```

**Build Command Fails:**
```bash
# Test locally
npm run build

# If fails, fix errors shown
# Then commit and push
```

**Node Version Mismatch:**
```yaml
# In .github/workflows/deploy.yml
# Ensure Node.js version matches package.json engines

- name: Setup Node
  uses: actions/setup-node@v4
  with:
    node-version: '20'  # Must match your development version
```

---

## Discord Connection Issues

### Symptoms
- "Connect Discord" button doesn't work
- Redirect to Discord but callback fails
- "Discord not connected" error when creating bot_dm alert

### Diagnosis Steps

**1. Check OAuth State:**
```sql
SELECT * FROM oauth_states
WHERE user_id = 'YOUR_USER_ID'
ORDER BY created_at DESC
LIMIT 5;

-- Check:
-- - State created recently
-- - expires_at > NOW()
-- - used = false
```

**2. Check Discord Application Settings:**
- Discord Developer Portal > Your App > OAuth2
- Verify redirect URL: `https://yourdomain.com/api/discord/callback`

**3. Check Browser Console:**
- Open DevTools > Console tab
- Look for errors during redirect

**4. Check API Logs:**
```bash
# Cloudflare Pages logs
# Look for /api/discord/connect and /api/discord/callback requests
```

---

### Solutions

**Redirect URI Mismatch:**
```bash
# Update Discord application settings
# Redirect URIs must exactly match:
# https://gevault.com/api/discord/callback

# Also update environment variable:
DISCORD_REDIRECT_URI=https://gevault.com/api/discord/callback
```

**OAuth State Expired:**
```sql
-- States expire after 10 minutes
-- Solution: Try connecting again (generates new state)
```

**Missing Client ID/Secret:**
```bash
# Verify environment variables in Cloudflare Pages
# Settings > Environment variables

DISCORD_CLIENT_ID=your_client_id
DISCORD_CLIENT_SECRET=your_client_secret
```

**CORS Issue:**
```typescript
// Ensure API returns proper CORS headers
return new Response(JSON.stringify(data), {
  headers: {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*'
  }
})
```

**Token Refresh Fails:**
```sql
-- Check refresh_token validity
SELECT refresh_token, token_expires_at
FROM discord_connections
WHERE user_id = 'YOUR_USER_ID';

-- If refresh fails, disconnect and reconnect:
-- /alerts > "Disconnect Discord" > "Connect Discord"
```

---

## Stripe Payment Problems

### Symptoms
- Checkout session doesn't open
- Payment succeeds but subscription not activated
- Webhook events not received

### Diagnosis Steps

**1. Check Stripe Dashboard:**
- Payments tab - Was payment successful?
- Webhooks tab - Are events being delivered?

**2. Check Webhook Endpoint:**
```bash
# Test webhook is reachable
curl -X POST https://gevault.com/api/stripe-webhook \
  -H "Content-Type: application/json" \
  -d '{"type":"test"}'

# Should return 400 (invalid signature) not 404
```

**3. Check Database:**
```sql
SELECT * FROM user_subscriptions
WHERE user_id = 'YOUR_USER_ID';

-- If no record after successful payment, webhook didn't process
```

---

### Solutions

**Webhook Secret Mismatch:**
```bash
# Get webhook secret from Stripe Dashboard
# Developers > Webhooks > [Your endpoint] > Signing secret

# Update in Cloudflare Pages environment variables
STRIPE_WEBHOOK_SECRET=whsec_your_actual_secret

# Redeploy after update
```

**Webhook URL Wrong:**
```
# Stripe Dashboard > Developers > Webhooks
# Update endpoint URL to production domain:
https://gevault.com/api/stripe-webhook

# Not:
https://ge-vault.pages.dev/api/stripe-webhook
```

**Test Mode vs Live Mode:**
```bash
# Ensure you're using matching keys
# All test mode OR all live mode

# Test mode keys start with:
sk_test_...
pk_test_...

# Live mode keys start with:
sk_live_...
pk_live_...
```

**Missing Events:**
```
# Stripe webhook endpoint must listen to:
- checkout.session.completed
- customer.subscription.updated
- customer.subscription.deleted
- invoice.payment_failed
- invoice.payment_succeeded

# Add missing events in Stripe Dashboard
```

**Subscription Not Activating:**
```sql
-- Manually check webhook processing
-- Run in Stripe Dashboard > Developers > Events
-- Click event > "Send test webhook"

-- Check Cloudflare logs for processing errors
```

---

## Authentication Errors

### Symptoms
- "Unauthorized" error on protected pages
- Logged out unexpectedly
- "Invalid token" errors in console

### Diagnosis Steps

**1. Check Session:**
```typescript
// In browser console
const { data, error } = await window.supabase.auth.getSession()
console.log(data.session)

// Should show access_token and expiry
```

**2. Check Supabase Status:**
- Visit https://status.supabase.com
- Check if there are ongoing issues

**3. Check Token Expiry:**
```typescript
// Token expires after 1 hour
const session = await window.supabase.auth.getSession()
const expiresAt = new Date(session.data.session.expires_at * 1000)
console.log('Expires at:', expiresAt)
```

---

### Solutions

**Token Expired:**
```typescript
// Supabase should auto-refresh
// If not, manually refresh:
const { data, error } = await supabase.auth.refreshSession()
```

**Session Storage Cleared:**
```
// Check browser localStorage
// Should contain 'sb-YOUR_PROJECT_ID-auth-token'

// If missing, user must log in again
```

**Wrong Supabase URL/Key:**
```bash
# Verify environment variables
echo $VITE_SUPABASE_URL
echo $VITE_SUPABASE_ANON_KEY

# Must match Supabase project settings
```

**RLS Policy Blocking:**
```sql
-- Check RLS policies are correct
SELECT * FROM pg_policies
WHERE tablename = 'portfolio_items';

-- Test policy manually:
SET request.jwt.claims.sub = 'YOUR_USER_ID';
SELECT * FROM portfolio_items;
```

**CORS Blocking API Calls:**
```typescript
// Ensure Supabase allows your domain
// Supabase Dashboard > Authentication > URL Configuration
// Add your domain to "Site URL" and "Redirect URLs"
```

---

## Database Connection Issues

### Symptoms
- "Failed to fetch" errors
- Database queries timeout
- Intermittent connection drops

### Diagnosis Steps

**1. Test Connection:**
```sql
-- In Supabase SQL Editor
SELECT NOW();

-- Should return current timestamp
```

**2. Check Connection Pooling:**
```sql
-- Check active connections
SELECT count(*) FROM pg_stat_activity;

-- Supabase free tier limit: 60 connections
```

**3. Check Network:**
```bash
# Ping Supabase
ping your-project.supabase.co

# Test HTTPS connection
curl https://your-project.supabase.co/rest/v1/
```

---

### Solutions

**Connection Limit Exceeded:**
```typescript
// Use connection pooling
// Supabase client automatically pools connections

// Don't create multiple clients:
// ❌ Bad
const client1 = createClient(...)
const client2 = createClient(...)

// ✅ Good (reuse single client)
import { supabase } from './lib/supabase'
```

**Slow Queries:**
```sql
-- Add indexes to frequently queried columns
CREATE INDEX idx_portfolio_user ON portfolio_items(user_id);
CREATE INDEX idx_alerts_active ON user_alerts(active, item_id)
  WHERE active = true;
```

**Network Timeout:**
```typescript
// Increase timeout (in fetch options)
const { data, error } = await supabase
  .from('items')
  .select()
  .abortSignal(AbortSignal.timeout(10000)) // 10 second timeout
```

**Supabase Project Paused:**
```
// Free tier projects pause after 7 days of inactivity
// Solution: Log into Supabase dashboard to wake project
// Or upgrade to Pro plan
```

---

## Worker Not Running

### Symptoms
- Prices not updating hourly
- Worker metrics show 0 requests
- Alerts not being checked

### Diagnosis Steps

**1. Check Deployment:**
```bash
wrangler deployments list

# Should show recent deployment
```

**2. Check Cron Trigger:**
```bash
wrangler triggers list

# Should show: 0 * * * * (hourly)
```

**3. Check Worker Logs:**
```bash
wrangler tail

# Should show activity every hour
# If no output, worker not running
```

**4. Check Worker Metrics:**
```
# Cloudflare Dashboard > Workers & Pages > ge-vault-worker > Metrics
# Should show ~24 requests/day
```

---

### Solutions

**Worker Not Deployed:**
```bash
cd app/worker
wrangler deploy
```

**Cron Trigger Disabled:**
```bash
# Check wrangler.toml
cat wrangler.toml

# Should contain:
[triggers]
crons = ["0 * * * *"]

# If missing, add and redeploy
wrangler deploy
```

**Worker Error:**
```bash
# Check for errors in code
wrangler tail

# Look for:
# - Uncaught exceptions
# - Missing environment variables
# - Database connection errors

# Fix errors and redeploy
```

**Environment Variables Missing:**
```bash
# List secrets
wrangler secret list

# Required:
# - SUPABASE_URL
# - SUPABASE_SERVICE_KEY
# - DISCORD_BOT_TOKEN
# - DISCORD_CLIENT_ID
# - DISCORD_CLIENT_SECRET

# Add missing:
wrangler secret put MISSING_SECRET
```

**Free Tier Limit Exceeded:**
```
# Cloudflare Workers free tier: 100,000 requests/day
# Hourly cron = 24 requests/day
# Should never exceed unless manually triggered

# Check for excessive manual triggers
# Upgrade to Paid plan if needed ($5/10M requests)
```

---

## Price Data Not Updating

### Symptoms
- Prices shown as "Last updated: X hours ago"
- Price history chart shows gap
- All items show same old price

### Diagnosis Steps

**1. Check Worker Execution:**
```bash
wrangler tail

# Should show hourly execution with:
# "Fetched prices for X items"
# "Updated X current prices"
```

**2. Check OSRS Wiki API:**
```bash
curl https://prices.runescape.wiki/api/v1/osrs/latest

# Should return JSON with price data
# If error, API may be down
```

**3. Check Database Updates:**
```sql
SELECT COUNT(*), MAX(updated_at)
FROM item_prices_current;

-- updated_at should be within last hour
```

---

### Solutions

**OSRS Wiki API Down:**
```
# Check OSRS Wiki status
# Visit: https://prices.runescape.wiki

# If down, wait for service to restore
# Worker will resume updating on next run
```

**Worker Failing Silently:**
```bash
# Check worker logs for errors
wrangler tail

# Common errors:
# - Network timeout
# - Database connection failure
# - Invalid API response

# Fix error and redeploy
```

**Database Write Permission:**
```sql
-- Verify service role can write
-- RLS policies should allow service_role

-- Check policy:
SELECT * FROM pg_policies
WHERE tablename = 'item_prices_current';

-- Should have policy allowing service_role to UPDATE/INSERT
```

**Price Update Function Error:**
```sql
-- Test refresh_item_prices function
SELECT refresh_item_prices('[
  {"item_id": "2", "high_price": 100, "low_price": 95}
]'::jsonb);

-- Should return 1 (number of rows updated)
-- If error, check function definition
```

---

## Portfolio Items Not Loading

### Symptoms
- Dashboard shows "Loading..." indefinitely
- Empty portfolio despite having items
- Error in browser console

### Diagnosis Steps

**1. Check Browser Console:**
```
F12 > Console tab
Look for errors:
- "Failed to fetch"
- "Unauthorized"
- "Network error"
```

**2. Check Network Tab:**
```
F12 > Network tab
Filter: Fetch/XHR
Look for request to Supabase
Check response status and body
```

**3. Check Database:**
```sql
SELECT * FROM portfolio_items
WHERE user_id = 'YOUR_USER_ID';

-- Are items actually in database?
```

---

### Solutions

**RLS Policy Blocking:**
```sql
-- Check RLS policy allows user to read own items
SELECT * FROM pg_policies
WHERE tablename = 'portfolio_items';

-- Policy should be:
CREATE POLICY portfolio_user_policy ON portfolio_items
  FOR ALL USING (auth.uid() = user_id);

-- Test with actual user ID:
SET request.jwt.claims.sub = 'actual-user-id';
SELECT * FROM portfolio_items;
```

**Not Authenticated:**
```typescript
// Check if user is logged in
const { data: { user } } = await supabase.auth.getUser()
console.log(user)

// If null, redirect to /auth
```

**Items Not Joined with Prices:**
```typescript
// Ensure query joins with items and prices
const { data, error } = await supabase
  .from('portfolio_items')
  .select(`
    *,
    items!inner (id, name, icon_name),
    item_prices_current!left (high_price, low_price)
  `)
  .eq('user_id', userId)
```

**Component State Issue:**
```typescript
// Check useEffect dependencies
useEffect(() => {
  fetchPortfolio()
}, [userId]) // Must include dependencies

// Ensure loading state is set correctly
setLoading(true)
fetchPortfolio()
  .then(setItems)
  .finally(() => setLoading(false))
```

---

## Performance Issues

### Symptoms
- Slow page loads
- Laggy interactions
- High memory usage
- Browser freezes

### Diagnosis Steps

**1. Run Lighthouse:**
```bash
# Chrome DevTools > Lighthouse tab
# Run audit
# Look for low Performance score
```

**2. Check React DevTools Profiler:**
```
# Install React DevTools extension
# Profiler tab > Record
# Perform actions
# Look for expensive renders
```

**3. Check Bundle Size:**
```bash
npm run build
# Check dist/ folder size
# Should be < 1MB total
```

---

### Solutions

**Large Bundle Size:**
```typescript
// Implement code splitting
const Dashboard = lazy(() => import('./pages/Dashboard'))
const Alerts = lazy(() => import('./pages/Alerts'))

<Suspense fallback={<Loading />}>
  <Routes>
    <Route path="/dashboard" element={<Dashboard />} />
  </Routes>
</Suspense>
```

**Expensive Re-renders:**
```typescript
// Use React.memo for components
export const ExpensiveComponent = React.memo(({ data }) => {
  // ...
})

// Use useMemo for calculations
const total = useMemo(() => {
  return items.reduce((sum, item) => sum + item.value, 0)
}, [items])

// Use useCallback for handlers
const handleClick = useCallback(() => {
  doSomething()
}, [dependency])
```

**Too Many Database Queries:**
```typescript
// Batch queries together
const { data } = await supabase
  .from('portfolio_items')
  .select(`
    *,
    items!inner (*),
    item_prices_current!left (*)
  `) // Single query instead of N+1
```

**Unoptimized Images:**
```html
<!-- Use proper image sizes -->
<img
  src="icon.png"
  width="32"
  height="32"
  loading="lazy"
  alt="Item icon"
/>
```

**No Caching:**
```typescript
// Cache API responses
const CACHE_KEY = 'portfolio_items'
const CACHE_TTL = 5 * 60 * 1000 // 5 minutes

const cached = sessionStorage.getItem(CACHE_KEY)
if (cached) {
  const { data, timestamp } = JSON.parse(cached)
  if (Date.now() - timestamp < CACHE_TTL) {
    return data
  }
}
```

---

## Deployment Failures

### Symptoms
- "Deployment failed" in Cloudflare Pages
- Build step fails
- Functions not deploying

### Diagnosis Steps

**1. Check Build Logs:**
```
Cloudflare Dashboard > Workers & Pages > ge-vault > View details
Look for error in build output
```

**2. Test Build Locally:**
```bash
npm run build
# Should complete without errors
```

**3. Check Environment Variables:**
```
Cloudflare Pages > Settings > Environment variables
Verify all required variables are set
```

---

### Solutions

**Missing Build Command:**
```
# Cloudflare Pages settings:
Build command: npm run build
Build output directory: dist
Root directory: app
```

**Environment Variable Not Set:**
```
# Add in Cloudflare Pages > Settings > Environment variables
# Click "Add variable"
# For production deployment, select "Production" environment
```

**Node Version Mismatch:**
```
# Set Node.js version in Cloudflare Pages
# Settings > Builds & deployments > Environment variables
# Add: NODE_VERSION = 20
```

**Functions Build Error:**
```bash
# Build functions locally to test
cd app
node scripts/build-functions.js

# Fix any TypeScript errors
# Commit and push
```

**Out of Memory:**
```bash
# Increase Node memory limit
# In package.json:
"scripts": {
  "build": "NODE_OPTIONS=--max_old_space_size=4096 vite build"
}
```

---

## CORS Errors

### Symptoms
- "CORS policy" error in browser console
- "No 'Access-Control-Allow-Origin' header"
- API requests fail from browser

### Diagnosis Steps

**1. Check Browser Console:**
```
F12 > Console
Look for exact CORS error message
Note which origin is being blocked
```

**2. Check Network Tab:**
```
F12 > Network
Look for OPTIONS preflight request
Check response headers
```

---

### Solutions

**Missing CORS Headers in API:**
```typescript
// Add CORS headers to all API responses
return new Response(JSON.stringify(data), {
  status: 200,
  headers: {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization'
  }
})
```

**Preflight Request Failing:**
```typescript
// Handle OPTIONS requests
export const onRequestOptions = async () => {
  return new Response(null, {
    status: 204,
    headers: {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization',
      'Access-Control-Max-Age': '86400'
    }
  })
}
```

**Supabase CORS:**
```
# Check Supabase > Authentication > URL Configuration
# Add your domain to allowed URLs:
https://gevault.com
http://localhost:5173 (for development)
```

---

## Missing Environment Variables

### Symptoms
- "undefined" errors for process.env variables
- Features don't work (Stripe, Discord, etc.)
- "Environment variable not found" errors

### Diagnosis Steps

**1. Check .env File:**
```bash
cat app/.env
# Should contain all required variables
```

**2. Check Variable Names:**
```bash
# Frontend variables must start with VITE_
echo $VITE_SUPABASE_URL

# Backend variables have no prefix
echo $STRIPE_SECRET_KEY
```

**3. Check Cloudflare Settings:**
```
Cloudflare Pages > Settings > Environment variables
List all production variables
```

---

### Solutions

**Variable Not Prefixed:**
```bash
# Frontend variable MUST start with VITE_
# ❌ Wrong:
SUPABASE_URL=...

# ✅ Correct:
VITE_SUPABASE_URL=...
```

**Variable Not in .env:**
```bash
# Copy from .env.example
cp .env.example .env

# Fill in actual values
nano .env
```

**Dev Server Not Restarted:**
```bash
# After changing .env, restart dev server
# Ctrl+C to stop
npm run dev
```

**Cloudflare Variables Not Set:**
```bash
# Set in Cloudflare Pages
# Settings > Environment variables > Add variable

# Select correct environment:
# - Production
# - Preview
# - Both (if variable needed in both)
```

---

## TypeScript Build Errors

### Symptoms
- "Type error" during build
- "Property does not exist on type"
- "Cannot find module"

### Diagnosis Steps

**1. Check Error Message:**
```bash
npm run build

# Read error carefully:
# - Which file?
# - Which line?
# - What type issue?
```

**2. Check tsconfig.json:**
```bash
cat tsconfig.json
cat tsconfig.app.json
```

---

### Solutions

**Test Files in Build:**
```json
// tsconfig.app.json
{
  "exclude": [
    "src/**/*.test.tsx",
    "src/**/*.test.ts",
    "src/**/__tests__"
  ]
}
```

**Missing Type Definitions:**
```bash
# Install type definitions
npm install -D @types/node
npm install -D @types/react
```

**Incorrect Import:**
```typescript
// ❌ Wrong extension
import { Component } from './Component.tsx'

// ✅ Correct (no extension)
import { Component } from './Component'
```

**Strict Mode Error:**
```typescript
// If strict mode is too restrictive
// tsconfig.json:
{
  "compilerOptions": {
    "strict": false // Temporary workaround
  }
}

// Better: Fix the type issue properly
```

---

## Test Failures

### Symptoms
- `npm run test` fails
- Specific tests fail in CI/CD
- Tests pass locally but fail in CI

### Diagnosis Steps

**1. Run Tests Locally:**
```bash
npm run test

# Read error messages
# Which test file?
# Which assertion failed?
```

**2. Run Single Test:**
```bash
npm run test src/components/__tests__/AlertForm.test.tsx
```

**3. Check Test Environment:**
```bash
# Check vitest.config.ts
cat vitest.config.ts
```

---

### Solutions

**Async Test Not Awaited:**
```typescript
// ❌ Wrong
it('fetches data', () => {
  const data = fetchData() // Not awaited
  expect(data).toBeDefined()
})

// ✅ Correct
it('fetches data', async () => {
  const data = await fetchData()
  expect(data).toBeDefined()
})
```

**Mock Not Set Up:**
```typescript
// Set up mock before test
import { vi } from 'vitest'

vi.mock('../lib/supabase', () => ({
  supabase: {
    from: vi.fn(() => ({
      select: vi.fn(() => Promise.resolve({ data: [], error: null }))
    }))
  }
}))
```

**DOM Not Available:**
```typescript
// Use happy-dom or jsdom
// vitest.config.ts:
export default defineConfig({
  test: {
    environment: 'happy-dom'
  }
})
```

**Timing Issue:**
```typescript
// Use waitFor for async updates
import { waitFor } from '@testing-library/react'

await waitFor(() => {
  expect(screen.getByText('Loaded')).toBeInTheDocument()
})
```

---

## Getting Help

If you can't find a solution here:

1. **Check Documentation:**
   - [Architecture](./ARCHITECTURE.md)
   - [API Reference](./API.md)
   - [Development Guide](./DEVELOPMENT.md)

2. **Search Issues:**
   - [GitHub Issues](https://github.com/GEVault/ge-vault/issues)
   - Check if someone else had the same problem

3. **Create New Issue:**
   - Include error message
   - Include steps to reproduce
   - Include environment details (OS, Node version, etc.)

4. **Check Service Status:**
   - [Cloudflare Status](https://www.cloudflarestatus.com)
   - [Supabase Status](https://status.supabase.com)
   - [Stripe Status](https://status.stripe.com)
   - [Discord Status](https://discordstatus.com)

---

**Last Updated:** January 2025
**Troubleshooting Guide Version:** 1.0
