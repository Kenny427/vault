# GE Vault - Deployment Guide

**Current Status:** ✅ Fully automated via GitHub Actions

The application is automatically deployed to Cloudflare Pages on every push to the `main` branch.

- **Production URL:** https://gevault.com
- **GitHub Repo:** https://github.com/GEVault/ge-vault
- **CI/CD:** GitHub Actions
- **Hosting:** Cloudflare Pages

---

## Automated Deployment (Current Setup)

### How it Works

1. Push code to `main` branch
2. GitHub Actions triggers automatically
3. Builds the Vite app with Node 20
4. Deploys to Cloudflare Pages using wrangler
5. Live at gevault.com in ~2 minutes

### Making Changes

```bash
# Make your changes
git add .
git commit -m "Your change description"
git push origin main

# GitHub Actions automatically builds and deploys!
```

### Monitoring Deployments

- **GitHub Actions:** https://github.com/GEVault/ge-vault/actions
- **Cloudflare Dashboard:** https://dash.cloudflare.com → Workers & Pages → ge-vault

---

## Manual Deployment (Alternative)

If you need to deploy manually without GitHub Actions:

### Step 1: Build Locally

```bash
cd "/home/mreedon/projects/GE Vault/app"

# Initialize git (if not already done)
git init

# Add all files
git add .

# Commit
git commit -m "Initial commit - GE Vault MVP ready for deployment"

# Add remote (create repo on GitHub first: github.com/new)
git remote add origin https://github.com/YOUR_USERNAME/ge-vault.git

# Push to GitHub
git push -u origin main
```

---

## Step 2: Connect GitHub to Cloudflare Pages

1. Go to https://dash.cloudflare.com
2. Click **Workers & Pages** in the sidebar
3. Click **Create** → **Pages** → **Connect to Git**
4. **Select your GitHub repository:** `ge-vault`
5. Click **Begin setup**

---

## Step 3: Configure Build Settings

**Framework preset:** Vite

**Build configuration:**
```
Build command: npm run build
Build output directory: dist
Root directory: /
```

**Build environment variables:**
Click **Add variable** and add these:

```
VITE_SUPABASE_URL=https://your-project.supabase.co
VITE_SUPABASE_ANON_KEY=your_supabase_anon_key
```

**Node version (if needed):**
```
NODE_VERSION=18
```

---

## Step 4: Deploy!

1. Click **Save and Deploy**
2. Wait 1-2 minutes for the build to complete
3. You'll get a URL like: `https://ge-vault.pages.dev`

---

## Step 5: Add Custom Domain

1. In Cloudflare Pages, go to your project
2. Click **Custom domains** tab
3. Click **Set up a custom domain**
4. Enter: `gevault.com`
5. Click **Continue**
6. Cloudflare will automatically configure DNS (since domain is on Cloudflare)
7. Wait 1-2 minutes for SSL certificate

✅ Your site will be live at **https://gevault.com**

---

## Environment Variables Reference

### Production (Cloudflare Pages)
```bash
# Frontend environment variables (set in Cloudflare Pages dashboard)
VITE_SUPABASE_URL=https://your-project.supabase.co
VITE_SUPABASE_ANON_KEY=your_supabase_anon_key
VITE_DISCORD_SERVER_INVITE=https://discord.gg/your_invite_code

# Stripe (optional, for premium features)
VITE_STRIPE_PUBLISHABLE_KEY=pk_test_your_key
STRIPE_SECRET_KEY=sk_test_your_key
STRIPE_WEBHOOK_SECRET=whsec_xxx
```

### Cloudflare Pages Functions (Environment Variables)
```bash
# Set these in Cloudflare Pages dashboard → Settings → Environment Variables
# These are available to /functions/api/* endpoints

DISCORD_CLIENT_ID=your_discord_client_id
DISCORD_CLIENT_SECRET=your_discord_client_secret
DISCORD_REDIRECT_URI=https://gevault.com/api/discord/callback
REDIRECT_DOMAIN=https://gevault.com
```

### Cloudflare Worker Secrets (Price Updater + Alerts)
```bash
# Set these using: cd worker && npx wrangler secret put SECRET_NAME
# These are encrypted and only accessible to the worker

SUPABASE_URL=https://your-project.supabase.co
SUPABASE_SERVICE_KEY=your_supabase_service_role_key
DISCORD_BOT_TOKEN=your_discord_bot_token
DISCORD_CLIENT_ID=your_discord_client_id
DISCORD_CLIENT_SECRET=your_discord_client_secret
```

### Setting Worker Secrets
```bash
cd worker

# Set each secret interactively
echo "your_supabase_url" | npx wrangler secret put SUPABASE_URL
echo "your_service_key" | npx wrangler secret put SUPABASE_SERVICE_KEY
echo "your_bot_token" | npx wrangler secret put DISCORD_BOT_TOKEN
echo "your_client_id" | npx wrangler secret put DISCORD_CLIENT_ID
echo "your_client_secret" | npx wrangler secret put DISCORD_CLIENT_SECRET

# Verify secrets are set
npx wrangler secret list
```

---

## Post-Deployment Checklist

After deployment, test these features:

### Core Features
- [ ] Landing page loads at gevault.com
- [ ] Can sign up for new account
- [ ] Can log in with existing account
- [ ] Can search for OSRS items
- [ ] Can add items to portfolio
- [ ] Portfolio displays with current prices
- [ ] Profit/loss calculations show correctly
- [ ] Can delete items from portfolio
- [ ] Portfolio summary shows total stats
- [ ] Can log out

### Premium Features (if configured)
- [ ] Premium modal shows subscription tiers
- [ ] Can create Stripe checkout session
- [ ] Webhook receives subscription events
- [ ] Premium status reflects in user account

### Discord Notifications (if configured)
- [ ] Can access /alerts page (premium users)
- [ ] Discord connection button appears
- [ ] One-click flow opens server invite
- [ ] OAuth redirect works correctly
- [ ] Discord connection shows in UI
- [ ] Can create price alerts
- [ ] Worker processes alerts (check logs)
- [ ] Bot DM notifications received
- [ ] Webhook notifications received (if configured)
- [ ] Alert history displays correctly

---

## Troubleshooting

### Build fails with "Module not found"
- Check that all dependencies are in `package.json`
- Run `npm install` locally to verify

### Site shows blank page
- Check browser console for errors
- Verify environment variables are set correctly in Cloudflare
- Make sure VITE_ prefix is used for frontend variables

### Auth doesn't work
- Check Supabase dashboard → Authentication → URL Configuration
- Add your production domain to allowed redirect URLs:
  - `https://gevault.com/*`
  - `https://gevault.com/auth/callback`

### Prices don't show
- Verify `item_prices_current` table is seeded
- Run: `npm run seed:prices` locally first
- Check Supabase dashboard → Table Editor

---

## Updating the Site

Any push to the `main` branch will automatically trigger a new deployment:

```bash
git add .
git commit -m "Add new feature"
git push origin main
```

Cloudflare Pages will automatically rebuild and deploy in 1-2 minutes.

---

## Manual Deployment with Wrangler

Alternatively, you can deploy directly from your local machine:

```bash
# Install Wrangler globally
npm install -g wrangler

# Login to Cloudflare
wrangler login

# Deploy
npm run build
npx wrangler pages deploy dist --project-name=ge-vault
```

---

## Cost Breakdown

**Current Setup (All Free):**
- Cloudflare Pages: $0/month (500 builds/month)
- Cloudflare Workers: $0/month (100k requests/day)
- Supabase: $0/month (500MB storage, 50k MAU)
- Domain: $10.46/year (~$0.87/month - already paid)

**Total: ~$1/month**

**When you'll need to upgrade:**
- Cloudflare Workers: $5/mo if >100k requests/day
- Supabase Pro: $25/mo if >500MB storage or >50k users

---

## Next Steps (Phase 2)

After deployment, consider adding:

1. **Cloudflare Worker for Price Updates**
   - Daily cron job to refresh prices automatically
   - Saves users from running manual scripts

2. **Analytics**
   - Add Plausible or Cloudflare Web Analytics
   - Track signups, item additions, retention

3. **Error Monitoring**
   - Add Sentry for error tracking
   - Get alerts when things break in production

4. **Performance Optimization**
   - Enable Cloudflare caching
   - Optimize images (use WebP)
   - Add service worker for offline support

---

**You're ready to deploy! 🚀**
