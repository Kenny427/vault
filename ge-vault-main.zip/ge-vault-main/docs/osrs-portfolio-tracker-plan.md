# GE Vault - Project Plan

**Project Name:** GE Vault (Grand Exchange Vault)  
**Domain:** gevault.com ✅ (purchased 2025-11-08 via Cloudflare Registrar)  
**Created:** November 8, 2025  
**Status:** Foundation Phase  
**Target Launch:** December 2025 (MVP)

---

## Executive Summary

A standalone OSRS long-term item tracking platform that allows any player to monitor their merchant holds and investments over time. Unlike the Flip Dashboard (which requires RuneLite + Flipping Copilot plugin), GE Vault is universally accessible to all OSRS players regardless of client or plugins used.

**Core Value Proposition:** "Stop manually checking prices on your long-term holds. Track your OSRS investments like a real portfolio."

**Why Standalone:**
- **Flip Dashboard** = Active trading tool, requires RuneLite + Flipping Copilot CSV exports
- **GE Vault** = Passive portfolio tracking, works for ANY OSRS player (mobile, desktop, any client)
- Broader addressable market (all OSRS players vs. just active flippers using specific plugins)
- Clean separation of concerns and independent monetization potential

---

## Branding & Positioning

### Name: GE Vault

**Why this name works:**
- **"GE"** = Grand Exchange (universally recognized OSRS term)
- **"Vault"** = Secure storage, long-term holding (gaming terminology)
- Professional enough for portfolio showcase
- Memorable, short, brandable
- SEO-friendly ("ge vault osrs", "grand exchange vault")

**Tagline Options:**
- Primary: "Your OSRS item vault"
- Alternative: "Track your Grand Exchange portfolio"
- Descriptive: "Long-term item tracking for OSRS"

**Visual Identity:**
- Vault door icon + GE gold coin imagery
- Color scheme: Gold (#D4AF37) + Deep Blue (#1a1f3a) for trust/security
- Clean, professional UI that appeals to both casual and serious merchants

### Target Audience (Broader than Flip Dashboard)

1. **Long-term merchants:** Players with 100M+ banks holding expensive items
2. **Gear investors:** Players who buy rare items as investments (party hats, 3rd age, etc.)
3. **Mobile players:** Can track portfolio even though they can't export flip data
4. **Returning players:** Check bank value without logging in
5. **Multi-account players:** Track items across multiple accounts in one place
6. **Any OSRS player** with items they want to monitor (no plugin required)

---

## Competitive Landscape

### Existing Solutions

**1. GE Tracker (getracker.com)**
- **Strengths:** Established brand, comprehensive data, price predictions
- **Weaknesses:** Complex UI, expensive premium ($5-15/mo), focuses on flipping not long-term tracking
- **Positioning:** Power users who want everything, can be overwhelming for casual traders

**2. Manual Tracking (Spreadsheets)**
- **Strengths:** Free, fully customizable, no login required
- **Weaknesses:** No automation, manual price updates, no charts, tedious
- **Positioning:** DIY users willing to do manual work

**3. RuneLite Plugins (Bank Value, etc.)**
- **Strengths:** Free, integrated into game client, real-time
- **Weaknesses:** Desktop only, requires RuneLite, no historical tracking, can't check without logging in
- **Positioning:** Active players who are always in-game

### GE Vault Differentiation

**Key Advantages:**
1. **Focus:** Purpose-built for long-term holds, not flipping (cleaner, simpler UX)
2. **Universal Access:** Works for ANY player (mobile, web, any client) - competitors require specific setup
3. **Passive Tracking:** Check portfolio without logging into OSRS (unique value for returning players)
4. **Generous Free Tier:** 30-day history free (competitors paywall historical data aggressively)
5. **Modern UX:** Clean, mobile-responsive, fast (many competitors have outdated interfaces)
6. **Fair Pricing:** $5/mo vs. competitors at $10-15/mo for basic features

**Target Gap:** Players who want to track 5-20 long-term holds without complexity of full trading platforms.

---

## Project Goals

### Primary Goals
1. **Validate demand:** Determine if OSRS players want long-term portfolio tracking
2. **Build foundation:** Create sustainable, scalable architecture using free-tier services
3. **Career showcase:** Demonstrate full-stack SaaS development skills (auth, database, cron jobs, monetization)

### Success Metrics
- **Phase 1 (Validation):** 100+ weekly active users within 3 months
- **Phase 2 (Monetization):** 20+ paying subscribers within 6 months of launch
- **Phase 3 (Scale):** Profitable operation (revenue > costs) by month 9

---

## Technical Architecture

### Tech Stack

**Frontend:**
- React 19 + TypeScript
- TailwindCSS for styling
- Recharts for data visualization
- Vite for build tooling

**Backend:**
- Supabase (PostgreSQL + Auth + Realtime)
- Cloudflare Workers for OSRS Wiki API proxy
- Cloudflare Cron Triggers for daily price updates

**Hosting:**
- Cloudflare Pages for frontend (integrates with domain, Workers, cron)
- Supabase free tier (500MB storage, 50k MAU per project)

**External APIs:**
- OSRS Wiki API (prices.runescape.wiki)

### Infrastructure Stack Decision

**Chosen: Cloudflare Pages + Workers + Supabase**

**Why this combination:**

1. **Cloudflare Pages (Frontend Hosting)**
   - Domain already on Cloudflare (gevault.com)
   - Seamless integration with Workers and cron
   - Free tier: Unlimited builds, CDN, SSL
   - Faster deployment pipeline
   - Single dashboard for hosting, API, domain

2. **Cloudflare Workers (API Routes + Cron)**
   - Edge computing (low latency)
   - Free tier: 100k requests/day
   - Built-in cron triggers for daily price updates
   - Simple function-based routing (/functions → /api routes)
   - Natural fit with Pages hosting

3. **Supabase (Database + Auth)**
   - Built-in authentication (saves 10-15 hours of dev work)
   - Row Level Security (PostgreSQL RLS) - critical for multi-tenant security
   - Free tier: Unlimited projects, 500MB per project, 50k MAU per project
   - Auto-generated REST API
   - Realtime subscriptions (for live price updates)
   - Point-in-time recovery and backups

**Alternative considered:** Cloudflare D1 + Clerk Auth
- **Pros:** Everything in Cloudflare ecosystem
- **Cons:** 
  - No built-in RLS (manual security in every Worker)
  - Requires external auth service (Clerk)
  - More development time to secure multi-tenant data
  - Less mature than PostgreSQL
- **Conclusion:** Not worth the complexity for MVP

**Cost projection:**
```
Cloudflare Pages: $0/month (free tier)
Cloudflare Workers: $0/month (under 100k requests/day)
Supabase: $0/month (under 50k MAU, under 500MB per project)
Domain: $10.46/year (already paid)

Total: ~$1/month until significant scale
```

**Upgrade thresholds:**
- Cloudflare Workers: $5/mo if >100k requests/day
- Supabase Pro: $25/mo if >500MB storage OR >50k users (per project)

**Supabase Multi-Project Clarification:**
- Free tier allows **unlimited projects** per account
- Each project has its own 500MB storage + 50k MAU quota
- Projects are isolated (don't share resources or quotas)
- GE Vault as project #3 is perfectly fine on free tier

### Mobile Strategy

**Phase 1 (MVP):**
- Mobile-responsive design from day 1
- Tailwind mobile-first breakpoints (sm, md, lg, xl)
- Touch targets minimum 44x44px (iOS guidelines)
- Simplified charts for small screens (Recharts responsive container)

**Design Considerations:**
- Single-column layout on mobile
- Bottom navigation for key actions (Add Item, View Portfolio)
- Collapsible filters and advanced options
- Swipe gestures for delete/edit (Phase 2)

**Performance:**
- Lazy load images (item icons)
- Virtual scrolling for large portfolios (react-window)
- Minimize initial bundle size (<200kb gzipped)

**PWA Capabilities (Phase 2):**
- Add to Home Screen prompt
- Offline mode (view cached portfolio)
- Push notifications for price alerts (premium feature)
- Service worker for background sync

**Testing:**
- Test on iOS Safari (most common OSRS mobile client)
- Test on Android Chrome
- Test on smaller screens (iPhone SE size)

### Database Schema

```sql
-- All OSRS items (seeded once from Wiki)
CREATE TABLE items (
  id INTEGER PRIMARY KEY,
  name TEXT NOT NULL,
  icon_url TEXT,
  examine TEXT,
  members BOOLEAN DEFAULT false,
  created_at TIMESTAMP DEFAULT NOW()
);

-- Current prices for ALL items (updated daily)
CREATE TABLE item_prices_current (
  item_id INTEGER PRIMARY KEY REFERENCES items(id),
  high_price BIGINT,
  low_price BIGINT,
  high_volume BIGINT,
  low_volume BIGINT,
  updated_at TIMESTAMP DEFAULT NOW()
);

-- Historical prices (all items, hourly snapshots)
-- Note: Actual implementation uses price_history table (see app/worker/price_history_migration.sql)
CREATE TABLE price_history (
  id BIGSERIAL PRIMARY KEY,
  item_id INT NOT NULL REFERENCES items(id) ON DELETE CASCADE,
  price BIGINT NOT NULL,
  price_type VARCHAR(10) NOT NULL CHECK (price_type IN ('high', 'low')),
  timestamp TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_price_history_item_time ON price_history (item_id, timestamp DESC);
CREATE INDEX idx_price_history_timestamp ON price_history (timestamp DESC);

-- User portfolios
CREATE TABLE portfolio_items (
  id SERIAL PRIMARY KEY,
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  item_id INTEGER REFERENCES items(id),
  quantity INTEGER NOT NULL CHECK (quantity > 0),
  buy_price BIGINT NOT NULL CHECK (buy_price > 0),
  date_purchased DATE NOT NULL,
  notes TEXT,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);
CREATE INDEX idx_portfolio_user ON portfolio_items(user_id);
CREATE INDEX idx_portfolio_item ON portfolio_items(item_id);

-- User subscription tracking (for future monetization)
CREATE TABLE user_subscriptions (
  user_id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  subscription_tier TEXT DEFAULT 'free', -- 'free', 'premium'
  stripe_customer_id TEXT,
  stripe_subscription_id TEXT,
  subscription_start DATE,
  subscription_end DATE,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);
```

### Data Flow

**Daily Price Update (Cron Job):**
```
1. Fetch ALL current prices from OSRS Wiki API (1 request)
2. Upsert into item_prices_current (all ~10k items)
3. Insert into price_history for all items (both high and low prices)
4. Cleanup: DELETE FROM price_history WHERE timestamp < (NOW() - INTERVAL '30 days') -- retention policy (free tier)
```

**User Views Portfolio:**
```sql
SELECT 
  pi.id,
  pi.quantity,
  pi.buy_price,
  pi.date_purchased,
  pi.notes,
  i.name,
  i.icon_url,
  ipc.high_price as current_price,
  ipc.updated_at as price_updated_at,
  (ipc.high_price * pi.quantity) as current_value,
  ((ipc.high_price - pi.buy_price) * pi.quantity) as total_profit,
  ((ipc.high_price - pi.buy_price) / pi.buy_price::float * 100) as profit_percentage
FROM portfolio_items pi
JOIN items i ON pi.item_id = i.id
JOIN item_prices_current ipc ON i.id = ipc.item_id
WHERE pi.user_id = $1
ORDER BY pi.date_purchased DESC;
```

**User Views Price Chart:**
```sql
SELECT
  timestamp,
  price,
  price_type
FROM price_history
WHERE item_id = $1
  AND timestamp >= (NOW() - INTERVAL '30 days') -- or 365 days for premium
ORDER BY timestamp ASC;
```

**Manual Price Refresh (User-Triggered):**
```
1. User clicks "Refresh Prices" button
2. Frontend calls Cloudflare Worker: /api/refresh-prices
3. Worker checks: When were prices last updated?
   - If < 15 minutes ago → Return cached (prevent API spam)
   - If > 15 minutes ago → Proceed to step 4
4. Worker fetches ALL prices from OSRS Wiki API
5. Worker upserts into item_prices_current (same as cron)
6. Response: { success: true, itemsUpdated: 10000, lastUpdated: timestamp }
7. Frontend shows success message and refetches portfolio
8. All users immediately see updated prices (shared cache)
```

**Rate Limiting Strategy:**
- Time-based: 15-minute cache (prevents excessive API calls)
- Future: Per-user limit (3 refreshes/hour) if needed
- Premium users: No rate limits (Phase 4)

**Shared Update Logic:**
Both cron job and manual refresh use the same `updatePrices()` function:
- Prevents code duplication
- Ensures consistent behavior
- One user's refresh benefits all users

### Error Handling & Edge Cases

**OSRS Wiki API Failures:**
- **Scenario:** API is down or rate limited
- **Handling:** 
  - Use cached prices (last successful fetch)
  - Display "Last updated: X hours ago" warning
  - Retry with exponential backoff
  - Alert admin if failure >24 hours

**Missing Price Data:**
- **Scenario:** Item has no current price (newly released, untradeable)
- **Handling:**
  - Show "Price unavailable" instead of $0
  - Exclude from total portfolio value calculations
  - Provide "Manual price entry" option (Phase 2)

**Item No Longer Exists:**
- **Scenario:** User adds item ID that's been removed from game
- **Handling:**
  - Soft validation during add (check against items table)
  - If item not in DB, show "Unknown item" error
  - Provide feedback link: "Is this item new? Let us know"

**Database Connection Issues:**
- **Scenario:** Supabase temporarily unavailable
- **Handling:**
  - Retry up to 3 times with backoff
  - Show user-friendly error: "Having trouble connecting. Please try again."
  - Log error to Sentry for investigation

**User Data Integrity:**
- **Scenario:** User has portfolio items but prices are missing
- **Handling:**
  - Background job to backfill missing prices
  - Display partial data with note: "Some prices are updating..."
  - Never show incorrect data (better to show "unavailable" than wrong price)

**Cron Job Failures:**
- **Scenario:** Daily price update fails to run
- **Handling:**
  - Cloudflare Worker retry logic (3 attempts)
  - Email alert if cron doesn't complete
  - Manual trigger endpoint for emergency price updates
  - Display "Last update: X hours ago" if stale

**Large Portfolio Performance:**
- **Scenario:** User has 1000+ items in portfolio
- **Handling:**
  - Pagination (50 items per page)
  - SQL LIMIT/OFFSET for queries
  - Virtual scrolling on frontend
  - "Load more" button vs infinite scroll

### Storage Projections

**Free Tier Capacity: 500 MB**

Conservative estimates:
- **Items table:** 10k items × 150 bytes = ~1.5 MB
- **Current prices:** 10k items × 80 bytes = ~0.8 MB
- **Historical prices (30-day retention):**
  - 200 tracked items × 30 days × 60 bytes = ~0.4 MB
- **User portfolios:** 1,000 users × 50 items × 100 bytes = ~5 MB
- **Auth/metadata:** ~2 MB

**Total at moderate scale: ~10 MB**

Headroom for growth: **490 MB** (or 49x current usage)

With premium tier (365-day history for 200 items):
- Additional ~4.5 MB per year

**Conclusion:** Can operate on free tier for a very long time.

---

## Implementation Phases

### Phase 1: MVP (Week 1-2)
**Goal:** Get something working that validates core functionality

**Features:**
- [x] Planning doc created
- [x] Project name finalized (GE Vault)
- [x] Domain purchased (gevault.com)
- [ ] Supabase project setup + auth (email/password + magic link)
- [ ] Database schema implemented
- [ ] Seed items table from OSRS Wiki item mapping
- [ ] Basic UI: Add item to portfolio (item search, qty, buy price, date)
- [ ] Basic UI: View portfolio with current value vs cost basis
- [ ] Cloudflare Worker: Daily price update cron (current prices only)
- [ ] Deploy to Cloudflare Pages with custom domain (gevault.com)

**Success Criteria:**
- Can create account, add items, see current value
- Prices update daily automatically
- Hosted and accessible

**Estimated Time:** 15-20 hours

---

### Phase 2: Polish & Historical Data (Week 3-4)
**Goal:** Make it actually useful and engaging

**Features:**
- [ ] User onboarding flow:
  - Welcome screen after signup ("Track your OSRS investments")
  - "Add your first item" guided flow
  - Empty state UX (helpful when portfolio is empty)
  - Optional: Sample portfolio (pre-filled demo with common items)
- [ ] Mobile responsiveness:
  - Touch-friendly buttons (min 44x44px targets)
  - Responsive charts (work on small screens)
  - Mobile-optimized table/card view
  - Test on iOS Safari and Android Chrome
- [ ] Implement 30-day historical price tracking (tracked items only)
- [ ] Price charts using Recharts (30-day line chart per item)
- [ ] Manual price refresh button:
  - Cloudflare Worker endpoint /api/refresh-prices
  - 15-minute cache (prevent API spam)
  - "Last updated: X ago" timestamp display
  - One user's refresh updates prices for everyone
  - Loading states and success feedback
- [ ] Portfolio summary dashboard (total invested, current value, profit/loss)
- [ ] Item detail page (price history chart, buy/sell volume data)
- [ ] Add Ko-fi/Buy Me a Coffee donation button
- [ ] Analytics setup (Plausible - track events from section above)
- [ ] Export portfolio (CSV/JSON)
- [ ] Error handling:
  - OSRS Wiki API down → show cached prices with warning
  - Missing price data → show "Price unavailable"
  - Failed item add → clear error message

**Success Criteria:**
- Users can see price trends over 30 days
- Dashboard feels polished and professional
- Works smoothly on mobile devices
- Analytics tracking user behavior
- <2 minute time to first item added

**Estimated Time:** 15-20 hours

---

### Phase 3: Beta Testing & User Feedback (Month 2-3)
**Goal:** Validate demand and gather feature requests

**Beta Testing (Week 1-2):**
- [ ] Closed beta with 10-20 trusted testers:
  - Friends, family, OSRS community members
  - Give them specific tasks to complete
  - Gather structured feedback (survey + direct messages)
  - Fix critical bugs before public launch
- [ ] Monitor beta metrics:
  - Did they complete onboarding?
  - Did they add items?
  - Did they return after first session?
- [ ] Iterate on UX issues discovered in beta

**Public Launch (Week 3-4):**
- [ ] Soft launch to r/2007scape:
  - Post during peak hours (6-8pm EST)
  - "I built a tool to track OSRS items long-term - looking for feedback"
  - Keep it humble, emphasize free tier
  - Include screenshots/demo
- [ ] Share on OSRS Discord servers (flipping, merchanting communities)
- [ ] Monitor analytics: DAU, portfolio items added, retention
- [ ] Engage with feedback and bug reports
- [ ] Quick bug fixes and UX improvements
- [ ] Track donations (if any)

**Decision Point:** 
- If 100+ weekly active users → proceed to monetization
- If 50-100 users → continue marketing, gather feature requests
- If <50 users → reassess product-market fit, consider pivots
- If donation rate >1% → strong signal for paid features

**Estimated Time:** Ongoing maintenance (5-10 hours/week)

---

### Phase 4: Monetization (Month 4+)
**Goal:** Build sustainable revenue model

**Features:**
- [ ] Stripe integration (subscriptions)
- [ ] Premium tier: 365-day historical data
- [ ] Premium tier: Price alerts (email/Discord webhooks)
- [ ] Premium tier: Advanced analytics (volatility, correlations, portfolio diversification)
- [ ] Billing dashboard (manage subscription, payment history)
- [ ] "Early supporter" pricing: Grandfather existing users at $3/month

**Pricing:**
- Free: Unlimited items, current prices, 30-day history
- Premium: $5/month or $50/year - 365-day history, alerts, advanced analytics

**Success Criteria:**
- 20+ paying subscribers within 2 months of launch
- Monthly revenue > infrastructure costs ($25-50/month at scale)
- Churn rate <10% monthly

**Estimated Time:** 20-25 hours

---

### Phase 5: Growth & Advanced Features (Month 6+)
**Goal:** Scale and differentiate

**Potential Features:**
- [ ] Multi-account portfolio support
- [ ] Portfolio sharing (public links)
- [ ] Community features (popular items being tracked, trending holds)
- [ ] Integration with Flip Dashboard (unified trading + investing view)
- [ ] Mobile app (PWA or React Native)
- [ ] API access for power users
- [ ] Tax export (profit/loss reporting for real-world tax purposes)

**Estimated Time:** Variable, based on demand

---

## Monetization Strategy

### Free Tier
**Value:** Fully functional portfolio tracking for casual users

- ✓ Unlimited portfolio items
- ✓ Current market prices
- ✓ 30-day price history & charts
- ✓ Basic profit/loss tracking
- ✓ Portfolio export (CSV)

### Premium Tier: $5/month or $50/year
**Value:** Professional trading analytics for serious merchants

- ✓ Everything in Free
- ✓ 365-day historical charts
- ✓ Price alerts (email + Discord webhooks)
- ✓ Advanced analytics:
  - Volatility tracking
  - Item correlation analysis
  - Portfolio diversification score
  - Best/worst time to buy analysis
- ✓ API access (rate limited)
- ✓ Priority support

### Early Supporter Program
**During Phase 1-3 (pre-monetization):**

Users who donate $20+ via Ko-fi get locked into $3/month forever when premium launches.

**Announcement strategy:**
```
"Monetization coming in 60 days! 
 Current users: Locked into $3/month forever (40% off)
 New users after launch: $5/month"
```

Creates urgency without being manipulative, rewards early believers.

---

## Competitive Landscape

### Existing Solutions

**1. GE Tracker (getracker.com)**
- **Pricing:** Freemium - Free basic, Premium ~$3-5/month
- **Key Features:**
  - Real-time price tracking
  - Item flipping margins
  - Trade volume data
  - Historical price graphs
  - Discord bot integration
- **Strengths:** Established brand, large user base, comprehensive data
- **Weaknesses:** 
  - Cluttered UI, overwhelming for new users
  - Focuses heavily on active flipping vs long-term holds
  - Premium features feel like paywalls rather than upgrades
  - No portfolio tracking focused on investments

**2. Platinum Tokens / Plat.inium**
- **Pricing:** Free with ads
- **Key Features:**
  - Item price lookup
  - Basic charts
  - Flip tracking
- **Strengths:** Free, simple
- **Weaknesses:**
  - Ad-heavy experience
  - Basic functionality only
  - Not focused on portfolio management
  - Limited analytics

**3. Manual Spreadsheets (Google Sheets / Excel)**
- **Pricing:** Free
- **Key Features:**
  - Full customization
  - Manual data entry
- **Strengths:** Free, flexible, private
- **Weaknesses:**
  - No automation (manual price updates)
  - Time-consuming to maintain
  - No charts without manual setup
  - Error-prone

### GE Vault Differentiation Strategy

**Core Differences:**
1. **Focus:** Portfolio tracking for long-term holds (not active flipping margins)
2. **UX:** Clean, focused interface - not trying to be "everything to everyone"
3. **Automation:** Set-and-forget price updates with automatic profit/loss tracking
4. **Fair Pricing:** Generous free tier, premium features that actually add value
5. **Mobile-First:** Responsive design from day 1, works on any device

**Value Proposition vs Competitors:**
- vs **GE Tracker:** "Less noise, more signal - focused on what you own, not what you could flip"
- vs **Plat.inium:** "No ads, automated updates, professional analytics"
- vs **Spreadsheets:** "Automation without the manual work"

**Positioning Statement:**
"GE Vault is the portfolio tracker for OSRS players who want to monitor their long-term investments without the complexity of active trading tools."

---

## Analytics & Metrics Strategy

### Event Tracking Plan

**Critical Events (Phase 1):**
- `account_created` - New user signup
- `first_item_added` - Critical conversion moment
- `portfolio_viewed` - Core engagement
- `item_deleted` - Understanding churn signals
- `logout` - Session end

**Engagement Events (Phase 2):**
- `chart_viewed` - Feature adoption for historical data
- `item_edited` - Power user behavior
- `portfolio_exported` - Value extraction
- `price_refresh_manual` - User dissatisfaction signal (should be auto)

**Monetization Events (Phase 4):**
- `premium_viewed` - Interest in upgrade
- `checkout_started` - Funnel tracking
- `subscription_created` - Conversion
- `subscription_cancelled` - Churn analysis

### Metrics Dashboard

**Daily Monitoring:**
- New signups
- Daily Active Users (DAU)
- Portfolio items added
- Error rate (client + server)

**Weekly Review:**
- Weekly Active Users (WAU)
- DAU/WAU ratio (stickiness)
- Time to first item added (onboarding friction)
- Average portfolio size
- Retention cohorts

**Monthly Analysis:**
- Monthly Active Users (MAU)
- Churn rate
- Feature adoption rates
- Premium conversion funnel
- LTV calculations

### Analytics Tools

**Phase 1 (MVP):**
- **Plausible Analytics** (privacy-friendly, GDPR compliant, ~$9/mo or self-hosted free)
  - Page views, user counts
  - No cookies needed
  - Simple, clean interface

**Phase 2+ (Growth):**
- Add **PostHog** or **Mixpanel** for event tracking
- Custom events via Supabase database triggers
- A/B testing framework for premium conversion

---

## User Onboarding Strategy

### First-Time User Experience

**Goal:** Get user to add first item within 2 minutes

**Flow:**
1. **Landing Page** → Clear value prop, "Sign up free" CTA
2. **Signup** → Email + password (or magic link for friction-less)
3. **Welcome Screen:**
   - "Welcome to GE Vault! Let's track your first item."
   - 3 quick benefits: Auto updates, Price charts, Profit tracking
   - Big "Add Your First Item" button
4. **Add Item Flow:**
   - Search for item (autocomplete helps)
   - Enter quantity, buy price, purchase date
   - Success animation: "✓ Twisted Bow added to your vault!"
5. **Empty State → First Item:**
   - Show item card with current price
   - Green/red indicator for profit/loss
   - "Add another item" CTA

**Empty State Handling:**
- After signup: "Your vault is empty. Let's add your first item!"
- With items: Clear "Add Item" button always visible
- Zero results: "No items match your search. Try 'Twisted Bow' or 'Abyssal Whip'"

**Optional: Demo Portfolio**
- "See an example" link on empty state
- Loads pre-filled portfolio with common high-value items
- Banner: "This is a demo. Add your own items to track."
- "Clear demo and start fresh" button

### Onboarding Checklist (Optional Phase 2)

Subtle progress tracker in dashboard:
- ✓ Account created
- ✓ First item added
- ⬜ Add 5 items (build your portfolio)
- ⬜ View price chart (explore historical data)
- ⬜ Export portfolio (get your data)

---

## Operational Playbook

### Support Strategy

**Phase 1 (MVP - First 100 users):**
- **Email support:** support@gevault.com (goes to your personal email)
- **Response time:** Within 24 hours
- **FAQ page:** Common questions answered
  - How to add items
  - How prices update (daily, automatic)
  - How to export data
  - Privacy/security questions

**Phase 2 (Growing - 100-1000 users):**
- **Discord server:** Community support, feature requests
- **In-app help:** "?" tooltips on key features
- **Video tutorials:** Short 1-2 minute guides
- **Knowledge base:** Searchable help articles

**Phase 3 (Scale - 1000+ users):**
- **Priority support** for premium users
- **Community moderators** in Discord
- **Live chat** (Intercom or similar) for premium

### Monitoring & Alerts

**Uptime Monitoring:**
- **UptimeRobot** (free tier) - checks site every 5 minutes
- Alert via email if site is down
- Monitor: Homepage, API health endpoint, auth flow

**Error Tracking:**
- **Sentry** (free tier for low volume)
- Track JavaScript errors
- Monitor API failures
- Alert on spike in errors

**Performance Monitoring:**
- Cloudflare Web Analytics (built-in with Pages)
- Track page load times
- Identify slow queries
- Monitor API response times (Workers analytics)

**Database Monitoring:**
- Supabase dashboard (built-in)
- Track query performance
- Monitor storage usage
- Watch for slow queries

### Backup & Recovery Strategy

**Automated Backups:**
- **Supabase:** Daily automatic backups (included in free tier)
- **Point-in-time recovery:** 7 days of history (Pro tier feature, but have plan)
- **Manual backups:** Weekly export to external storage (Google Drive/S3)

**Disaster Recovery Plan:**
1. **Data loss:** Restore from Supabase backup (2-4 hour RTO)
2. **Supabase outage:** Read-only mode with cached data (implement Phase 2)
3. **Total failure:** Restore to new Supabase instance from backup (<24 hours)

**User-Level Protections:**
- Soft deletes for portfolio items (keep in DB for 30 days)
- "Are you sure?" confirmation for delete all
- Export functionality so users have their own backups

### Security Considerations

**Authentication:**
- Supabase Auth handles password hashing (bcrypt)
- Optional 2FA in Phase 2
- Rate limiting on auth endpoints (prevent brute force)

**Data Protection:**
- Row Level Security (RLS) enforced on all tables
- Users can only access their own portfolio data
- No sensitive data stored (just item IDs, quantities, prices)
- HTTPS everywhere (enforced by Cloudflare Pages)

**API Security:**
- Cloudflare Worker proxies OSRS Wiki API (rate limit protection)
- Supabase service key kept server-side only (never in client)
- CORS properly configured

**Privacy Compliance:**
- Privacy policy (template from Termly or similar)
- Cookie consent (if using analytics with cookies)
- Data export available to users (GDPR right to data portability)
- Account deletion removes all user data (GDPR right to erasure)

### Incident Response Plan

**If site goes down:**
1. Check Cloudflare status page (Pages + Workers)
2. Check Supabase status page
3. Review error logs in Sentry
4. Post status update on Twitter/Discord (if established)
5. Fix issue, deploy, verify
6. Post-mortem if outage >1 hour

**If data issue discovered:**
1. Assess scope (how many users affected)
2. Stop writes if corruption risk
3. Restore from backup if needed
4. Communicate transparently to affected users
5. Post-mortem and prevention plan

---

## Marketing & Growth Strategy

### Target Audience
1. **Long-term merchants:** Players with 100M+ banks holding expensive items (TBow, Scythe, etc.)
2. **Flippers who hold:** Active traders who also invest in longer-term holds
3. **Returning players:** People who quit with valuable items, want to track without logging in

### Distribution Channels
- r/2007scape (Reddit) - Timed posts, avoid spam
- OSRS Discord servers (especially merchanting/flipping communities)
- OSRS YouTube creators (sponsor mention / affiliate)
- OSRS Wiki (if they allow tool listings)
- Cross-promotion with existing Flip Dashboard users

### Content Marketing
- Blog: "The Ultimate Guide to OSRS Merching"
- Blog: "Which OSRS Items Are Good Long-Term Holds?"
- YouTube: "I Tracked My 1B Bank for 6 Months - Here's What Happened"
- Twitter/X: Regular updates on interesting price movements

---

## Risk Assessment

### Technical Risks
| Risk | Likelihood | Impact | Mitigation |
|------|------------|--------|------------|
| OSRS Wiki API changes/rate limits | Medium | High | Cache aggressively, monitor API, have fallback |
| Supabase free tier exhausted | Low | Medium | Monitor usage, upgrade to Pro ($25/mo) if needed |
| Data loss / corruption | Low | High | Regular backups, Supabase point-in-time recovery |
| Security breach (user data) | Low | Critical | Use Supabase RLS, never store sensitive data, regular audits |

### Business Risks
| Risk | Likelihood | Impact | Mitigation |
|------|------------|--------|------------|
| No product-market fit | Medium | High | Validate with free version first, iterate based on feedback |
| Competition from established tools | Medium | Medium | Differentiate with better UX, advanced analytics, fair pricing |
| OSRS player base decline | Low | Medium | Diversify to other games (e.g., RS3) if needed |
| Maintenance burden too high | Medium | Medium | Automate everything, keep infrastructure simple |

### Legal/Compliance Risks
| Risk | Likelihood | Impact | Mitigation |
|------|------------|--------|------------|
| Jagex C&D (trademark/API usage) | Low | High | Non-commercial initially, follow API ToS, rebrand if needed |
| GDPR compliance issues | Low | Medium | Use Supabase (GDPR compliant), minimal data collection, clear privacy policy |
| Stripe payment disputes | Low | Low | Clear refund policy, excellent customer service |

---

## Analytics & Event Tracking

### Analytics Platform
**Recommendation:** Plausible Analytics or Simple Analytics
- Privacy-friendly (GDPR compliant)
- No cookie banner needed
- Simple, focused metrics
- ~$10/mo for reasonable traffic

### Critical Events to Track

**User Acquisition:**
- `page_view` - Overall traffic
- `signup_started` - User clicked signup button
- `signup_completed` - Account created successfully
- `signup_method` - Email/password vs magic link

**User Activation (Critical):**
- `first_item_added` - First portfolio item created (KEY METRIC)
- `time_to_first_item` - Minutes from signup to first item (target: <2 minutes)
- `portfolio_viewed` - User viewed their dashboard

**Engagement:**
- `item_added` - Any item added to portfolio
- `item_removed` - Item deleted from portfolio
- `item_edited` - Item updated (qty, price, notes)
- `chart_viewed` - User viewed price history chart
- `portfolio_exported` - User exported portfolio data

**Retention Indicators:**
- `daily_active_user` - User logged in and viewed portfolio
- `weekly_active_user` - User active within 7 days
- `donation_clicked` - User clicked Ko-fi button (pre-monetization signal)

**Technical Metrics:**
- `page_load_time` - Performance monitoring
- `api_error` - Track API failures (OSRS Wiki API down, etc.)
- `auth_error` - Login/signup failures

### Success Metrics Dashboard

**Week 1 Targets:**
- 20+ signups
- 50%+ complete first item (activation rate)
- <5 minutes time to first item

**Month 1 Targets:**
- 100+ signups
- 200+ portfolio items added
- 30%+ week-1 retention
- 20%+ monthly active users return weekly

**Decision Points:**
- If activation rate <30%: Onboarding flow needs work
- If retention <20%: Product value prop unclear
- If donation clicks >1%: Strong signal for monetization

---

## Success Metrics & KPIs

### User Metrics
- **MAU (Monthly Active Users):** Target 500+ by month 3
- **DAU/MAU Ratio:** Target >30% (healthy engagement)
- **Portfolio Items Added:** Target 5,000+ items tracked by month 3
- **Retention:** Target >50% week-1 retention

### Financial Metrics
- **MRR (Monthly Recurring Revenue):** Target $100+ by month 6
- **CAC (Customer Acquisition Cost):** Target <$5 per paying user
- **LTV (Lifetime Value):** Target >$50 (10+ months retention at $5/mo)
- **LTV:CAC Ratio:** Target >10:1

### Product Metrics
- **Time to First Portfolio Item:** Target <2 minutes
- **Portfolio Size (median):** Target 10-20 items per user
- **Chart Views:** Track how often users view historical data
- **Feature Adoption:** Track usage of alerts, analytics (post-launch)

---

## Open Questions

1. **Branding:** Standalone product or Flip Dashboard feature?
   - ✅ **DECIDED:** Standalone product (GE Vault) - broader market appeal, clean separation of concerns

2. **Domain:** Buy custom domain now or wait?
   - ✅ **DECIDED:** Domain purchased (gevault.com via Cloudflare Registrar, $10.46/year)

3. **Historical data retention:** Should premium get unlimited history?
   - ✅ **DECIDED:** 365 days is sufficient, unlimited is overkill and expensive

4. **International support:** OSRS vs RS3?
   - **Recommendation:** Start OSRS only, add RS3 if demand exists (separate price feeds available)

5. **Mobile app:** Worth building?
   - **Recommendation:** Mobile-responsive web first (PWA capabilities), native app only if strong user demand

6. **Item data seeding:** How often to update?
   - **Recommendation:** One-time seed from OSRS Wiki, monthly check for new items (new items are rare)

7. **Support channel:** How will users get help?
   - **Recommendation:** Start with email (simple), add Discord if community grows, FAQ page for common questions

---

## Next Steps

**Completed:**
- [x] Finalize project name and branding (GE Vault)
- [x] Purchase domain (gevault.com via Cloudflare Registrar)
- [x] Create comprehensive planning documentation

**Immediate (This Week):**
- [ ] Set up Supabase project
- [ ] Create database schema with RLS policies
- [ ] Seed items table from OSRS Wiki mapping
- [ ] Initialize GitHub repository
- [ ] Set up local development environment
- [ ] Build basic auth flow (signup/login)

**Week 2:**
- [ ] Build "Add to Portfolio" UI
- [ ] Build "View Portfolio" UI with live prices
- [ ] Implement daily price update cron (Cloudflare Worker)
- [ ] Deploy MVP to Cloudflare Pages with custom domain

**Week 3-4:**
- [ ] Add user onboarding flow
- [ ] Implement 30-day historical price tracking
- [ ] Build price charts with Recharts
- [ ] Mobile responsiveness pass
- [ ] Add analytics (Plausible)
- [ ] Polish UI/UX
- [ ] Add Ko-fi donation button
- [ ] Closed beta with 10-20 testers
- [ ] Fix bugs from beta feedback

**Month 2:**
- [ ] Public launch to r/2007scape
- [ ] Share on OSRS Discord communities
- [ ] Monitor metrics and gather feedback
- [ ] Iterate based on user requests

---

## Operational Considerations

### User Support Strategy

**Phase 1-2 (MVP/Beta):**
- Email support: support@gevault.com (forward to personal email)
- Response time target: <24 hours
- FAQ page covering common questions:
  - How to add items
  - Where do prices come from
  - How often are prices updated
  - What happens to my data

**Phase 3+ (Public Launch):**
- Consider Discord server if community grows (>100 active users)
- In-app help tooltips for complex features
- Knowledge base (documentation site)

### Monitoring & Alerting

**Uptime Monitoring:**
- Use: UptimeRobot (free tier) or BetterStack
- Monitor: Main site + API health endpoint
- Alert: Email/SMS if site down >5 minutes

**Error Tracking:**
- Use: Sentry (free tier: 5k events/month)
- Track: JavaScript errors, API failures, auth issues
- Alert: High-severity errors via email

**Performance Monitoring:**
- Use: Cloudflare Web Analytics (free, privacy-friendly, included with Pages)
- Track: Page load times, Core Web Vitals, user geography
- Target: <2s page load, <500ms API responses

**Daily Health Check:**
- Verify cron job ran successfully
- Check OSRS Wiki API status
- Monitor Supabase usage (approaching free tier limits?)

### Backup & Disaster Recovery

**Database Backups:**
- Supabase automatic daily backups (7-day retention on free tier)
- Weekly manual export to external storage (Cloudflare R2 free tier)
- Test restoration process monthly

**Disaster Scenarios:**
- User accidentally deletes portfolio → Implement "soft delete" (mark as deleted, keep 30 days)
- Database corruption → Restore from Supabase point-in-time recovery
- OSRS Wiki API permanently down → Have backup price data source identified
- Entire Supabase project down → Migration plan to self-hosted PostgreSQL

**Recovery Time Objective (RTO):** <4 hours to restore service
**Recovery Point Objective (RPO):** <24 hours of data loss acceptable

### Legal & Compliance

**Before Public Launch:**
- [ ] Privacy Policy (template: Termly or similar)
- [ ] Terms of Service (template + custom OSRS-specific terms)
- [ ] Cookie policy (if using cookies beyond Supabase auth)
- [ ] GDPR compliance:
  - Data export feature (users can download their data)
  - Data deletion (delete account removes all portfolio data)
  - Clear privacy policy

**Ongoing:**
- Annual review of policies
- Stay informed on GDPR/privacy law changes
- Monitor for Jagex trademark/IP guidance

---

## Deployment Guide

### Cloudflare Pages Setup

**Initial Deployment:**
```bash
# 1. Build your React app
npm run build

# 2. Install Wrangler CLI (Cloudflare's deployment tool)
npm install -g wrangler

# 3. Login to Cloudflare
wrangler login

# 4. Deploy to Cloudflare Pages
wrangler pages deploy dist --project-name=ge-vault

# 5. Set up custom domain in Cloudflare dashboard
# Pages → ge-vault → Custom domains → Add gevault.com
```

**Environment Variables:**
```bash
# In Cloudflare Pages dashboard:
# Settings → Environment variables

VITE_SUPABASE_URL=https://xxxxx.supabase.co
VITE_SUPABASE_ANON_KEY=your-anon-key
```

**Automatic Deployments:**
- Connect GitHub repo in Cloudflare Pages dashboard
- Every push to `main` branch auto-deploys
- Preview deployments for pull requests

---

### Cloudflare Workers Setup

**For API Routes:**
```bash
# Create /functions directory in your repo
mkdir functions
mkdir functions/api

# Files automatically become API routes:
# /functions/api/refresh-prices.ts → /api/refresh-prices
```

**Example Worker (API Route):**
```typescript
// /functions/api/refresh-prices.ts
import { createClient } from '@supabase/supabase-js'

export async function onRequest(context) {
  const supabase = createClient(
    context.env.SUPABASE_URL,
    context.env.SUPABASE_SERVICE_KEY
  )
  
  // Check timestamp, fetch prices, update database
  // (Full implementation in codebase)
  
  return new Response(JSON.stringify({ success: true }), {
    headers: { 'Content-Type': 'application/json' }
  })
}
```

**Environment Variables for Workers:**
```bash
# In Cloudflare dashboard:
# Workers & Pages → ge-vault → Settings → Variables

SUPABASE_URL=https://xxxxx.supabase.co
SUPABASE_SERVICE_KEY=your-service-role-key
```

---

### Cloudflare Cron Triggers

**Setup Daily Price Updates:**
```bash
# In wrangler.toml (at project root):
name = "ge-vault-cron"

[triggers]
crons = ["0 0 * * *"]  # Run daily at midnight UTC
```

**Cron Worker Code:**
```typescript
// /workers/cron-price-update.ts
export default {
  async scheduled(event, env, ctx) {
    const supabase = createClient(
      env.SUPABASE_URL,
      env.SUPABASE_SERVICE_KEY
    )
    
    // Fetch and update prices (same logic as manual refresh)
    await updatePrices(supabase)
    
    console.log('Daily price update completed')
  }
}
```

**Deploy Cron Worker:**
```bash
wrangler deploy workers/cron-price-update.ts
```

---

### Supabase Setup

**Create Project:**
1. Go to https://supabase.com/dashboard
2. Click "New Project"
3. Name: `ge-vault-prod`
4. Region: US East (or closest to users)
5. Generate strong database password
6. Wait 2-3 minutes for provisioning

**Run Database Schema:**
1. Go to SQL Editor in Supabase dashboard
2. Paste the complete schema (from planning doc)
3. Click "Run"
4. Verify tables in Table Editor

**Get API Keys:**
1. Settings → API
2. Copy Project URL
3. Copy `anon` public key (for frontend)
4. Copy `service_role` key (for Workers - keep secret!)

---

### Deployment Checklist

**Before First Deploy:**
- [x] Domain purchased (gevault.com)
- [ ] Supabase project created
- [ ] Database schema executed
- [ ] Items table seeded
- [ ] GitHub repo created
- [ ] Environment variables configured

**First Deploy:**
- [ ] Build passes locally (`npm run build`)
- [ ] Deploy to Cloudflare Pages
- [ ] Custom domain configured
- [ ] SSL certificate active (automatic)
- [ ] Test site loads at https://gevault.com

**Post-Deploy:**
- [ ] Set up Cloudflare Workers (API routes)
- [ ] Deploy cron worker (daily price updates)
- [ ] Verify auth flow works
- [ ] Test portfolio creation
- [ ] Verify prices display correctly

**Monitoring:**
- [ ] Cloudflare Web Analytics enabled
- [ ] Sentry error tracking configured
- [ ] UptimeRobot monitoring set up
- [ ] Test all error states

---

## Resources & References

**Technical Docs:**
- [Cloudflare Pages Guide](https://developers.cloudflare.com/pages/)
- [Cloudflare Workers Guide](https://developers.cloudflare.com/workers/)
- [Cloudflare Cron Triggers](https://developers.cloudflare.com/workers/configuration/cron-triggers/)
- [Supabase Auth Guide](https://supabase.com/docs/guides/auth)
- [Supabase with Cloudflare Workers](https://supabase.com/docs/guides/integrations/cloudflare-workers)
- [OSRS Wiki API Docs](https://oldschool.runescape.wiki/w/RuneScape:Real-time_Prices)
- [Stripe Subscriptions Guide](https://stripe.com/docs/billing/subscriptions/overview)

**Community:**
- r/2007scape - Main OSRS subreddit
- OSRS Flipping Discord servers
- RuneLite Discord (for plugin ecosystem understanding)

**Inspiration:**
- GE Tracker (competitor analysis)
- Plat.inium (OSRS tool example)
- Traditional stock portfolio trackers (UI/UX patterns)

---

## Notes & Changelog

**2025-11-08 (Late Evening):** Infrastructure stack finalized
- ✅ **Hosting decision:** Cloudflare Pages + Workers (not Vercel)
  - Rationale: Domain already on Cloudflare, better integration with Workers/cron
  - Unified dashboard for hosting, API routes, domain management
- ✅ **Database decision:** Supabase (not Cloudflare D1)
  - Rationale: Built-in auth saves 10-15 hours, PostgreSQL RLS for security
  - Clarified: Supabase free tier allows unlimited projects (no 2-project limit)
  - Each project gets 500MB storage + 50k MAU independently
- ✅ **API architecture:** Cloudflare Workers for /api routes and cron jobs
- Added manual price refresh feature to Phase 2 (15-min cache, benefits all users)
- Updated all documentation to reflect Cloudflare Pages deployment
- Added infrastructure decision rationale section

**2025-11-08 (Evening):** Major updates after domain purchase
- ✅ **Domain secured:** gevault.com purchased via Cloudflare Registrar ($10.46/year)
- ✅ **Strategic decision:** Confirmed standalone product (not Flip Dashboard feature)
- Added competitive landscape analysis (GE Tracker, spreadsheets, RuneLite plugins)
- Added detailed analytics & event tracking plan (Plausible recommended)
- Added user onboarding requirements to Phase 2
- Added mobile responsiveness requirements
- Added closed beta testing phase before public launch
- Added operational considerations (support, monitoring, backups, legal)
- Updated all "pending" decisions to completed
- Marked Phase 1 progress (planning and domain complete)

**2025-11-08 (Initial):** Project plan created
- Decided on 30-day history for free, 365-day for premium
- Free tier infrastructure validated (Supabase + Cloudflare)
- Monetization strategy: $5/mo premium, $3/mo for early supporters
- MVP timeline: 2-4 weeks to launch
- Database schema designed with proper RLS policies
- Storage projections calculated (~10MB at moderate scale)

