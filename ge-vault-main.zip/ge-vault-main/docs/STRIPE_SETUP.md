# Stripe Integration Setup Guide

This guide walks through setting up Stripe subscriptions for GE Vault premium features.

## Overview

GE Vault uses a **Pay What You Want** pricing model for premium subscriptions:
- ☕ **Coffee Supporter**: $2/month or $20/year
- ⭐ **Standard Supporter**: $5/month or $50/year (recommended)
- 🚀 **Super Supporter**: $10/month or $100/year
- 💎 **Custom Amount**: Choose your own ($2-999)

**All tiers include the same premium features** - pricing is purely to support the developer and keep the service running.

## Prerequisites

- Stripe account (sign up at [stripe.com](https://stripe.com))
- Supabase project with migrations applied
- Environment variables configured

## Step 1: Run Database Migrations

Apply the subscription-related database migrations:

```bash
# In Supabase SQL Editor, run these migrations in order:

# 1. User Subscriptions Table
cat worker/subscriptions_migration.sql | pbcopy
# Paste and run in Supabase SQL Editor

# 2. Discord Alerts & Notifications System
cat worker/discord_alerts_migration.sql | pbcopy
# Paste and run in Supabase SQL Editor
```

Verify the tables were created:
```sql
SELECT table_name FROM information_schema.tables
WHERE table_schema = 'public'
AND table_name IN ('user_subscriptions', 'user_alerts', 'discord_connections', 'alert_history', 'oauth_states');
```

## Step 2: Configure Environment Variables

**No Stripe products need to be created!** GE Vault uses dynamic pricing via Stripe's `price_data` API, which creates subscriptions on-the-fly based on user selection.

Your `.env.local` should already have these from the initial setup:

```bash
# Stripe Keys
VITE_STRIPE_PUBLISHABLE_KEY=pk_test_your_publishable_key
STRIPE_SECRET_KEY=sk_test_your_secret_key
```

That's it! No Price IDs needed.

## Step 3: Set Up Stripe Webhook

Webhooks keep your database in sync with Stripe subscription events.

### For Local Development (Using Stripe CLI)

```bash
# Forward webhooks to your local server
stripe listen --forward-to http://localhost:5173/api/stripe-webhook

# This will output a webhook signing secret (starts with whsec_)
# Add it to your .env.local:
STRIPE_WEBHOOK_SECRET=whsec_your_local_webhook_secret
```

### For Production (Cloudflare Pages)

1. **Deploy your app** to get the production URL

2. **Go to Stripe Dashboard** → [Webhooks](https://dashboard.stripe.com/test/webhooks)

3. **Click "+ Add endpoint"**
   - Endpoint URL: `https://gevault.com/api/stripe-webhook`
   - Description: `GE Vault Production Webhook`

4. **Select events to listen to:**
   - `checkout.session.completed`
   - `customer.subscription.created`
   - `customer.subscription.updated`
   - `customer.subscription.deleted`
   - `invoice.payment_succeeded`
   - `invoice.payment_failed`

5. **Click "Add endpoint"**

6. **Copy the Signing Secret** (starts with `whsec_`)

7. **Add to Cloudflare Pages environment variables:**
   - Go to Cloudflare Dashboard → Pages → gevault-app → Settings → Environment Variables
   - Add `STRIPE_WEBHOOK_SECRET` with the signing secret value

## Step 4: Configure Cloudflare Pages Environment Variables

Add all Stripe-related environment variables to Cloudflare Pages:

1. Go to Cloudflare Dashboard → Pages → gevault-app → Settings → Environment Variables

2. Add these variables for **Production**:
   ```
   STRIPE_SECRET_KEY=sk_test_your_secret_key
   VITE_STRIPE_PUBLISHABLE_KEY=pk_test_your_publishable_key
   STRIPE_WEBHOOK_SECRET=whsec_your_webhook_secret
   SUPABASE_URL=https://your-project.supabase.co
   SUPABASE_SERVICE_KEY=your_service_role_key
   ```

3. **Redeploy** the application for changes to take effect

## Step 5: Test the Integration

### Test Mode Cards

Stripe test mode accepts these special card numbers:

- **Success**: `4242 4242 4242 4242`
- **Requires authentication**: `4000 0025 0000 3155`
- **Declined**: `4000 0000 0000 9995`

Use any future expiry date and any 3-digit CVC.

### Testing Flow

1. **Sign in** to your app
2. **Click on a premium feature** (this should trigger the premium modal)
3. **Select a tier** (Coffee, Standard, Super, or Custom amount)
4. **Choose billing period** (Monthly or Annual)
5. **Click "Continue to Payment"**
6. **Complete checkout** with test card `4242 4242 4242 4242`
7. **Verify subscription** in Stripe Dashboard → Customers
8. **Check database** - verify `user_subscriptions` table updated with tier metadata
9. **Verify webhook** received in Stripe Dashboard → Webhooks

### Testing Webhooks

```bash
# Using Stripe CLI, trigger test events:
stripe trigger checkout.session.completed
stripe trigger customer.subscription.updated
stripe trigger customer.subscription.deleted
```

## Step 6: Verify Database Updates

After a successful checkout, verify the subscription was saved:

```sql
SELECT
  user_id,
  status,
  plan_type,
  stripe_subscription_id,
  current_period_end
FROM user_subscriptions
WHERE status = 'active';
```

## Production Checklist

Before going live with real payments:

- [ ] Run all migrations on production Supabase
- [ ] Switch to **Live mode** Stripe keys (not Test mode)
- [ ] Update `.env.local` with **live** Stripe keys
- [ ] Set up production webhook endpoint
- [ ] Add all environment variables to Cloudflare Pages Production environment
- [ ] Test complete signup flow in production with real card (then refund)
- [ ] Set up Stripe billing portal for customers to manage subscriptions
- [ ] Configure email receipts in Stripe Dashboard → Settings → Emails
- [ ] Test all PWYW tiers (Coffee, Standard, Super, Custom amount)

## Premium Features

Once subscribed, users get access to:

- ✅ **Discord Price Alerts** - Get notified via Discord when items hit target prices
  - One-click Discord connection (server join + OAuth)
  - Bot DM notifications or custom webhooks
  - Absolute price targets or percentage-based alerts
  - One-shot, recurring, or cooldown alert behaviors
  - Full alert history and analytics
- ✅ **Advanced Analytics** - Detailed profit tracking and insights
- ✅ **Historical Charts** - Full price history and trend analysis
- ✅ **Unlimited Portfolio Items** - No limits on tracking
- ✅ **Export Data** - Download portfolio as CSV
- ✅ **Priority Support** - Faster responses to issues

## Troubleshooting

### Checkout session creation fails
- Verify Stripe secret key is correct in `.env.local`
- Check that custom amount is between $2-999
- Ensure using correct mode (test vs live)
- Check Cloudflare Functions logs for detailed errors

### Webhook not receiving events
- Check webhook URL is correct
- Verify signing secret matches
- Check Cloudflare Functions logs for errors
- Test with `stripe trigger` commands

### Subscription not updating in database
- Check webhook events in Stripe Dashboard
- Verify Supabase service key has correct permissions
- Check RLS policies on `user_subscriptions` table
- Review Cloudflare Functions logs

### Customer portal not working
- Set up in Stripe Dashboard → Settings → Billing → Customer Portal
- Configure allowed actions (cancel, update payment method)
- Add return URL to your app

## Support Resources

- [Stripe Documentation](https://stripe.com/docs)
- [Stripe Testing Guide](https://stripe.com/docs/testing)
- [Webhook Best Practices](https://stripe.com/docs/webhooks/best-practices)
- [Subscription Lifecycle](https://stripe.com/docs/billing/subscriptions/overview)

## Next Steps

1. ✅ Build Discord price alerts feature (COMPLETE)
2. Create a subscription management page for users
3. Implement advanced analytics dashboard with charts
4. Add CSV export functionality for portfolio data
5. Set up customer billing portal integration for self-service
6. Monitor alert delivery metrics and optimize notification timing
