# Cloudflare Workers Environment Variables

When you deploy your Cloudflare Workers (for API routes and cron jobs), you'll need to set these environment variables in the Cloudflare dashboard:

## How to Set Them

1. Go to Cloudflare Dashboard
2. Navigate to **Workers & Pages** → **ge-vault** → **Settings** → **Variables**
3. Add these environment variables:

```bash
SUPABASE_URL=https://delocrbhqrezxfquyvig.supabase.co
SUPABASE_SERVICE_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImRlbG9jcmJocXJlenhmcXV5dmlnIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc2MjYxOTMyMiwiZXhwIjoyMDc4MTk1MzIyfQ.whxffZrKqQKa_YauX9b-qDFc6HbgbDcNut2rWVM-JOM
```

## Important Notes

- **DO NOT** use the service key in your frontend code
- **ONLY** use service key in Cloudflare Workers (server-side)
- The service key has admin access to your database
- Keep this file out of Git (already in .gitignore)

## For Cloudflare Pages

For the frontend (Pages), you'll set these in:
**Pages** → **ge-vault** → **Settings** → **Environment variables**

```bash
VITE_SUPABASE_URL=https://delocrbhqrezxfquyvig.supabase.co
VITE_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImRlbG9jcmJocXJlenhmcXV5dmlnIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjI2MTkzMjIsImV4cCI6MjA3ODE5NTMyMn0.WHD6GaSuib41yJn3gxlAxopIk249ixz7nuVvek56tY8
```
