# Architecture Documentation

Technical architecture and system design for GE Vault.

## Table of Contents

- [System Overview](#system-overview)
- [Technology Stack](#technology-stack)
- [System Architecture](#system-architecture)
- [Data Flow](#data-flow)
- [Database Schema](#database-schema)
- [Security Architecture](#security-architecture)
- [Integration Points](#integration-points)

---

## System Overview

GE Vault is a serverless web application for tracking Old School RuneScape (OSRS) Grand Exchange portfolios and price alerts.

**Architecture Pattern:** Jamstack + Serverless Functions + Scheduled Workers

**Core Components:**
1. **React SPA** - User interface (Cloudflare Pages)
2. **API Functions** - Serverless endpoints (Cloudflare Pages Functions)
3. **Price Worker** - Scheduled cron job (Cloudflare Worker)
4. **Database** - PostgreSQL with Row Level Security (Supabase)
5. **External Integrations** - Stripe, Discord, OSRS Wiki API

---

## Technology Stack

### Frontend

| Technology | Version | Purpose |
|------------|---------|---------|
| **React** | 18.3.1 | UI framework with hooks |
| **TypeScript** | 5.9.3 | Type safety |
| **Vite** | 7.1.7 | Build tool and dev server |
| **React Router** | 7.9.5 | Client-side routing |
| **Tailwind CSS** | 3.4.18 | Utility-first styling |
| **Recharts** | 3.4.1 | Price history visualization |

**Bundle Size:** ~150KB gzipped (production)

---

### Backend & Infrastructure

| Technology | Version | Purpose |
|------------|---------|---------|
| **Cloudflare Pages** | - | Static hosting + SSR functions |
| **Cloudflare Workers** | - | Serverless cron jobs |
| **Supabase** | 2.80.0 | PostgreSQL + Auth + Realtime |
| **Stripe** | 19.3.0 | Payment processing |

**Hosting Regions:**
- Cloudflare: Global edge network (300+ cities)
- Supabase: US-East (configurable)

---

### Testing & Quality

| Technology | Version | Purpose |
|------------|---------|---------|
| **Vitest** | 4.0.9 | Unit and component testing |
| **Testing Library** | 16.3.0 | React testing utilities |
| **MSW** | 2.12.2 | API mocking |
| **ESLint** | 9.36.0 | Code linting |

**Coverage Target:** 60-80% (currently ~65%)

---

### Development Tools

| Technology | Version | Purpose |
|------------|---------|---------|
| **tsx** | 4.20.6 | TypeScript execution (scripts) |
| **esbuild** | 0.27.0 | Fast bundling |
| **PostCSS** | 8.5.6 | CSS transformations |

---

## System Architecture

### High-Level Architecture Diagram

```
┌─────────────────────────────────────────────────────────────┐
│                         INTERNET                            │
└───────────────┬──────────────────────────┬──────────────────┘
                │                          │
                │                          │
        ┌───────▼────────┐        ┌────────▼──────────┐
        │   User Browser │        │  OSRS Wiki API    │
        │   (React SPA)  │        │  (Price Data)     │
        └───────┬────────┘        └────────┬──────────┘
                │                          │
                │ HTTPS                    │ HTTPS
                │                          │
        ┌───────▼──────────────────────────▼──────────┐
        │      Cloudflare Edge Network               │
        │  ┌──────────────┐  ┌───────────────────┐  │
        │  │    Pages     │  │     Worker        │  │
        │  │  (Frontend)  │  │  (Cron: hourly)   │  │
        │  └──────┬───────┘  └─────────┬─────────┘  │
        │         │                    │             │
        │  ┌──────▼───────┐            │             │
        │  │  Functions   │            │             │
        │  │  (API Layer) │            │             │
        │  └──────┬───────┘            │             │
        └─────────┼────────────────────┼─────────────┘
                  │                    │
                  │                    │
          ┌───────▼────────────────────▼────────┐
          │         Supabase                    │
          │  ┌──────────────────────────────┐  │
          │  │  PostgreSQL Database         │  │
          │  │  - items (45k+ items)        │  │
          │  │  - item_prices_current       │  │
          │  │  - price_history (30 days)   │  │
          │  │  - portfolio_items           │  │
          │  │  - user_alerts               │  │
          │  │  - user_subscriptions        │  │
          │  │  - discord_connections       │  │
          │  └──────────────────────────────┘  │
          │  ┌──────────────────────────────┐  │
          │  │  Auth (JWT tokens)           │  │
          │  └──────────────────────────────┘  │
          └─────────────────────────────────────┘
                  │                    │
                  │                    │
          ┌───────▼────────┐  ┌────────▼─────────┐
          │     Stripe     │  │    Discord       │
          │  (Payments)    │  │  (OAuth + Bot)   │
          └────────────────┘  └──────────────────┘
```

---

### Component Architecture

```
┌─────────────────────────────────────────────────────────┐
│                    React Application                    │
│  ┌──────────────────────────────────────────────────┐  │
│  │  App.tsx (Router)                                │  │
│  │  ┌────────────┐  ┌────────────┐  ┌───────────┐  │  │
│  │  │  Landing   │  │    Auth    │  │ Dashboard │  │  │
│  │  │   Page     │  │    Page    │  │   Page    │  │  │
│  │  └────────────┘  └────────────┘  └─────┬─────┘  │  │
│  │                                         │         │  │
│  │  ┌──────────────────────────────────────▼──────┐ │  │
│  │  │  Components Layer                           │ │  │
│  │  │  - PortfolioSummary                         │ │  │
│  │  │  - PortfolioList                            │ │  │
│  │  │  - AddItemModal                             │ │  │
│  │  │  - ItemSearch                               │ │  │
│  │  │  - PriceHistoryChart                        │ │  │
│  │  └─────────────────────────────────────────────┘ │  │
│  │                                                   │  │
│  │  ┌───────────────────────────────────────────┐  │  │
│  │  │  State Management (React Hooks)           │  │  │
│  │  │  - useState, useEffect                    │  │  │
│  │  │  - Custom hooks (usePortfolio, useAlerts) │  │  │
│  │  └───────────────────────────────────────────┘  │  │
│  │                                                   │  │
│  │  ┌───────────────────────────────────────────┐  │  │
│  │  │  Library Layer (lib/)                     │  │  │
│  │  │  - supabase.ts (DB client)                │  │  │
│  │  │  - premium.ts (subscription logic)        │  │  │
│  │  │  - discord.ts (OAuth helpers)             │  │  │
│  │  │  - geTax.ts (tax calculation)             │  │  │
│  │  └───────────────────────────────────────────┘  │  │
│  └──────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────┘
```

---

### API Layer Architecture

```
┌─────────────────────────────────────────────────────┐
│         Cloudflare Pages Functions                 │
│                (Serverless Edge)                    │
│                                                     │
│  ┌──────────────────────────────────────────────┐  │
│  │  /api/alerts/[[route]].ts                    │  │
│  │  ├─ POST /create   → Create alert            │  │
│  │  ├─ GET  /list     → List alerts             │  │
│  │  ├─ PATCH /update  → Update alert            │  │
│  │  └─ DELETE /delete → Delete alert            │  │
│  └──────────────────────────────────────────────┘  │
│                                                     │
│  ┌──────────────────────────────────────────────┐  │
│  │  /api/create-checkout-session.ts             │  │
│  │  └─ POST → Create Stripe checkout            │  │
│  └──────────────────────────────────────────────┘  │
│                                                     │
│  ┌──────────────────────────────────────────────┐  │
│  │  /api/create-portal-session.ts               │  │
│  │  └─ POST → Create Stripe portal              │  │
│  └──────────────────────────────────────────────┘  │
│                                                     │
│  ┌──────────────────────────────────────────────┐  │
│  │  /api/stripe-webhook.ts                      │  │
│  │  └─ POST → Handle Stripe events              │  │
│  └──────────────────────────────────────────────┘  │
│                                                     │
│  ┌──────────────────────────────────────────────┐  │
│  │  /api/discord/[[route]].ts                   │  │
│  │  ├─ GET    /connect    → Start OAuth         │  │
│  │  ├─ GET    /callback   → Handle callback     │  │
│  │  ├─ POST   /refresh    → Refresh token       │  │
│  │  └─ DELETE /disconnect → Remove connection   │  │
│  └──────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────┘
```

---

### Worker Architecture

```
┌──────────────────────────────────────────────────────┐
│         Cloudflare Worker (Price Updater)           │
│              Cron: 0 * * * * (hourly)               │
│                                                      │
│  ┌────────────────────────────────────────────────┐ │
│  │  Main Workflow (src/index.ts)                  │ │
│  │                                                 │ │
│  │  1. Fetch Prices                                │ │
│  │     ├─ GET OSRS Wiki API                        │ │
│  │     └─ Parse 45,000+ item prices                │ │
│  │                                                  │ │
│  │  2. Check Alerts & Notify (Premium Only)        │ │
│  │     ├─ Fetch active alerts with Discord data    │ │
│  │     ├─ Filter to premium users                  │ │
│  │     ├─ Refresh expiring Discord tokens          │ │
│  │     ├─ Check alert conditions                   │ │
│  │     ├─ Call should_check_alert() RPC            │ │
│  │     ├─ Send Discord DMs/webhooks                │ │
│  │     ├─ Log alert_history                        │ │
│  │     └─ Update alert metadata                    │ │
│  │                                                  │ │
│  │  3. Update Current Prices                       │ │
│  │     ├─ Filter to items in database              │ │
│  │     └─ Upsert item_prices_current               │ │
│  │                                                  │ │
│  │  4. Insert Historical Prices                    │ │
│  │     ├─ Batch insert (1000 per batch)            │ │
│  │     └─ Insert into price_history                │ │
│  │                                                  │ │
│  │  5. Cleanup Old Data                            │ │
│  │     └─ Delete price_history > 30 days           │ │
│  └────────────────────────────────────────────────┘ │
└──────────────────────────────────────────────────────┘
```

---

## Data Flow

### Portfolio Management Flow

```
User Action: Add Item to Portfolio
          │
          ▼
┌─────────────────────┐
│  AddItemModal       │
│  - Search items     │
│  - Enter quantity   │
│  - Enter buy price  │
└─────────┬───────────┘
          │
          ▼
┌─────────────────────┐
│  Supabase Insert    │
│  INSERT INTO        │
│  portfolio_items    │
└─────────┬───────────┘
          │
          ▼
┌─────────────────────┐
│  Real-time Update   │
│  (Supabase Channel) │
└─────────┬───────────┘
          │
          ▼
┌─────────────────────┐
│  PortfolioList      │
│  Re-renders with    │
│  new item           │
└─────────┬───────────┘
          │
          ▼
┌─────────────────────┐
│  PortfolioSummary   │
│  Recalculates:      │
│  - Total invested   │
│  - Current value    │
│  - Profit/loss      │
│  - GE tax           │
└─────────────────────┘
```

---

### Price Alert Flow

```
User Creates Alert
          │
          ▼
┌─────────────────────────┐
│  AlertForm Validation   │
│  - Check premium status │
│  - Validate fields      │
│  - Check Discord conn   │
└─────────┬───────────────┘
          │
          ▼
┌─────────────────────────┐
│  POST /api/alerts/create│
│  - Validate premium     │
│  - Validate Discord     │
│  - Insert user_alerts   │
└─────────┬───────────────┘
          │
          ▼
┌─────────────────────────┐
│  Alert Created          │
│  Status: Active         │
└─────────┬───────────────┘
          │
          ▼
┌─────────────────────────────────────┐
│  Worker Runs (Every Hour)            │
│                                      │
│  For each active alert:              │
│  1. Get current item price           │
│  2. Check alert condition            │
│  3. Call should_check_alert()        │
│     - one_shot: not triggered before?│
│     - recurring: always true         │
│     - cooldown: cooldown expired?    │
│  4. If condition met:                │
│     a. Send Discord notification     │
│     b. Log alert_history             │
│     c. Update last_triggered_at      │
│     d. Increment trigger_count       │
│     e. If one_shot: deactivate       │
└─────────┬───────────────────────────┘
          │
          ▼
┌─────────────────────────┐
│  Discord Notification   │
│  - Bot DM sent          │
│    OR                   │
│  - Webhook posted       │
└─────────────────────────┘
```

---

### Authentication Flow

```
User Visits /auth
          │
          ▼
┌─────────────────────────┐
│  Supabase Auth UI       │
│  - Enter email/password │
│  - Click Sign In        │
└─────────┬───────────────┘
          │
          ▼
┌─────────────────────────┐
│  Supabase Auth Service  │
│  - Validate credentials │
│  - Generate JWT tokens  │
│  - Create session       │
└─────────┬───────────────┘
          │
          ▼
┌─────────────────────────┐
│  Session Storage        │
│  - access_token (JWT)   │
│  - refresh_token        │
│  - expires_at           │
└─────────┬───────────────┘
          │
          ▼
┌─────────────────────────┐
│  Redirect to /dashboard │
└─────────┬───────────────┘
          │
          ▼
┌─────────────────────────┐
│  Protected Route Check  │
│  - Verify session valid │
│  - Get user profile     │
│  - Check premium status │
└─────────────────────────┘
```

---

### Payment Flow

```
User Clicks "Go Premium"
          │
          ▼
┌─────────────────────────────┐
│  PremiumModal               │
│  - Select tier & billing    │
│  - Click Subscribe          │
└─────────┬───────────────────┘
          │
          ▼
┌─────────────────────────────┐
│  POST /api/                 │
│  create-checkout-session    │
│  - Get/create customer      │
│  - Create checkout session  │
│  - Return checkout URL      │
└─────────┬───────────────────┘
          │
          ▼
┌─────────────────────────────┐
│  Redirect to Stripe         │
│  - User enters card details │
│  - Stripe processes payment │
└─────────┬───────────────────┘
          │
          ▼
┌─────────────────────────────┐
│  Stripe Webhook             │
│  Event: checkout.session.   │
│         completed           │
└─────────┬───────────────────┘
          │
          ▼
┌─────────────────────────────┐
│  POST /api/stripe-webhook   │
│  - Verify signature         │
│  - Extract metadata         │
│  - Update user_subscriptions│
│  - Set status = 'active'    │
└─────────┬───────────────────┘
          │
          ▼
┌─────────────────────────────┐
│  Redirect to /dashboard     │
│  ?subscription=success      │
└─────────┬───────────────────┘
          │
          ▼
┌─────────────────────────────┐
│  Dashboard                  │
│  - Shows premium features   │
│  - Can create alerts        │
└─────────────────────────────┘
```

---

### Discord OAuth Flow

```
User Clicks "Connect Discord"
          │
          ▼
┌─────────────────────────────────┐
│  GET /api/discord/connect       │
│  ?token=<supabase_jwt>          │
│                                 │
│  1. Validate token              │
│  2. Generate random state       │
│  3. Insert into oauth_states    │
│  4. Redirect to Discord         │
└─────────┬───────────────────────┘
          │
          ▼
┌─────────────────────────────────┐
│  Discord Authorization          │
│  - User approves application    │
│  - Scope: identify              │
└─────────┬───────────────────────┘
          │
          ▼
┌─────────────────────────────────┐
│  GET /api/discord/callback      │
│  ?code=<auth_code>&state=<uuid> │
│                                 │
│  1. Verify state valid          │
│  2. Exchange code for token     │
│  3. Fetch Discord user info     │
│  4. Insert discord_connections  │
│  5. Mark state as used          │
│  6. Redirect to /alerts         │
└─────────┬───────────────────────┘
          │
          ▼
┌─────────────────────────────────┐
│  Alerts Page                    │
│  - Shows "Discord Connected"    │
│  - Can create bot_dm alerts     │
└─────────────────────────────────┘
```

---

## Database Schema

### Entity Relationship Diagram

```
┌──────────────────┐
│   auth.users     │
│  (Supabase Auth) │
└────────┬─────────┘
         │
         │ 1:N
         ├──────────────────────────────────┐
         │                                  │
         │                                  │
┌────────▼────────────┐           ┌─────────▼──────────┐
│  portfolio_items    │           │ user_subscriptions │
│  - id               │           │  - id              │
│  - user_id (FK)     │           │  - user_id (FK)    │
│  - item_id (FK)     │           │  - stripe_cust_id  │
│  - quantity         │           │  - status          │
│  - buy_price        │           │  - plan_type       │
│  - notes            │           │  - period_start/end│
│  - created_at       │           └────────────────────┘
└─────────────────────┘
         │                                  │
         │                                  │ 1:1
┌────────▼────────────┐           ┌─────────▼──────────┐
│      items          │           │discord_connections │
│  - id (PK)          │           │  - id              │
│  - name             │           │  - user_id (FK)    │
│  - examine_text     │           │  - discord_user_id │
│  - icon_name        │           │  - access_token    │
│  - members_only     │           │  - refresh_token   │
│  - wiki_name        │           │  - token_expires_at│
└─────────┬───────────┘           └────────┬───────────┘
          │                                │
          │ 1:1                            │
          │                                │
┌─────────▼──────────────┐                 │
│ item_prices_current    │                 │
│  - item_id (PK, FK)    │                 │
│  - high_price          │                 │
│  - low_price           │                 │
│  - updated_at          │                 │
└────────────────────────┘                 │
          │                                │
          │ 1:N                            │
          │                                │
┌─────────▼──────────────┐                 │
│   price_history        │                 │
│  - id                  │                 │
│  - item_id (FK)        │                 │
│  - price               │                 │
│  - price_type (h/l)    │                 │
│  - timestamp           │                 │
└────────────────────────┘                 │
                                           │
         ┌─────────────────────────────────┘
         │
         │ 1:N
┌────────▼────────────┐
│   user_alerts       │
│  - id               │
│  - user_id (FK)     │
│  - item_id          │
│  - alert_type       │
│  - target_price     │
│  - notification_type│
│  - discord_user_id  │
│  - behavior         │
│  - active           │
│  - last_triggered   │
└─────────┬───────────┘
          │
          │ 1:N
          │
┌─────────▼───────────┐
│  alert_history      │
│  - id               │
│  - alert_id (FK)    │
│  - user_id (FK)     │
│  - triggered_at     │
│  - trigger_price    │
│  - notification_sent│
└─────────────────────┘
```

---

### Key Tables

#### items (Pre-seeded)
- **Records:** ~45,000 OSRS items
- **Source:** OSRS Wiki
- **Updates:** Manual (rare)

#### item_prices_current
- **Records:** ~20,000 active items
- **Update Frequency:** Hourly (worker)
- **Storage:** ~5MB

#### price_history
- **Retention:** 30 days rolling
- **Update Frequency:** Hourly
- **Records:** ~500,000 per day (cleaned daily)
- **Storage:** ~2GB (stable with cleanup)

#### portfolio_items
- **Free Tier Limit:** 50 items per user
- **Premium:** Unlimited
- **Indexes:** user_id, item_id

#### user_alerts
- **Free Tier:** 0 alerts
- **Premium:** Unlimited
- **Indexes:** active + item_id (for worker performance)

---

### Database Functions

#### is_user_premium(user_id UUID)
```sql
RETURNS BOOLEAN
- Checks user_subscriptions table
- Returns TRUE if status IN ('active', 'trialing')
- Returns TRUE if current_period_end > NOW()
```

#### should_check_alert(alert_id, behavior, cooldown_hours)
```sql
RETURNS BOOLEAN
- one_shot: Check alert_history for any successful notification
- recurring: Always return TRUE
- cooldown: Check alert_history for notification within cooldown period
```

#### refresh_item_prices(price_updates JSONB)
```sql
RETURNS INTEGER
- Batch upsert for item_prices_current
- Returns count of updated rows
- SECURITY DEFINER (bypasses RLS)
```

---

### Row Level Security (RLS)

**Portfolio Items:**
```sql
-- Users can only see/modify their own items
CREATE POLICY portfolio_user_policy ON portfolio_items
  FOR ALL USING (auth.uid() = user_id);
```

**User Alerts:**
```sql
-- Users can only manage their own alerts
CREATE POLICY alerts_user_policy ON user_alerts
  FOR ALL USING (auth.uid() = user_id);
```

**Subscriptions:**
```sql
-- Users can read their own subscription
CREATE POLICY subscription_read_policy ON user_subscriptions
  FOR SELECT USING (auth.uid() = user_id);

-- Only service role can write
CREATE POLICY subscription_write_policy ON user_subscriptions
  FOR INSERT, UPDATE USING (auth.role() = 'service_role');
```

**Price Data:**
```sql
-- Public read access
CREATE POLICY price_read_policy ON item_prices_current
  FOR SELECT USING (true);

-- Only service role can write
CREATE POLICY price_write_policy ON item_prices_current
  FOR INSERT, UPDATE USING (auth.role() = 'service_role');
```

---

## Security Architecture

### Authentication & Authorization

**Authentication Method:** Supabase Auth (JWT)

**Token Lifecycle:**
- **Access Token:** 1 hour expiry
- **Refresh Token:** 30 days expiry
- **Storage:** localStorage (Supabase SDK handles)

**Protected Routes:**
```typescript
<ProtectedRoute>
  <Dashboard />
</ProtectedRoute>

// Checks:
// 1. Session exists
// 2. Access token valid
// 3. If expired, auto-refresh
```

---

### API Security

**Cloudflare Functions:**
```typescript
// 1. Extract token from Authorization header
const authHeader = request.headers.get('Authorization')
const token = authHeader?.replace('Bearer ', '')

// 2. Verify with Supabase
const { data: { user }, error } = await supabase.auth.getUser(token)

// 3. Reject if invalid
if (error || !user) {
  return new Response(JSON.stringify({ error: 'Unauthorized' }), {
    status: 401
  })
}
```

**Stripe Webhook Verification:**
```typescript
// Verify signature
const signature = request.headers.get('stripe-signature')
const event = stripe.webhooks.constructEvent(
  rawBody,
  signature,
  webhookSecret
)
// Throws error if signature invalid
```

**Discord OAuth CSRF Protection:**
```typescript
// 1. Generate random state (UUID)
// 2. Store in database with expiry
// 3. Validate on callback
// 4. Mark as used (prevent replay)
```

---

### Data Security

**Encryption at Rest:**
- Supabase: AES-256 encryption
- Stripe: PCI DSS Level 1 compliant

**Encryption in Transit:**
- TLS 1.3 (Cloudflare)
- HTTPS only (no HTTP allowed)

**Sensitive Data Handling:**
```typescript
// Discord tokens encrypted at rest
// Stripe customer IDs (not card details)
// Never log tokens or credentials
```

**Environment Variables:**
```bash
# Never committed to git (.gitignore)
# Stored in Cloudflare secrets
# Injected at runtime
```

---

### Rate Limiting & DDoS Protection

**Cloudflare:**
- Automatic DDoS protection
- WAF (Web Application Firewall)
- Rate limiting (configurable)

**Discord API:**
- Worker enforces 50 notifications/second
- Batch processing with delays

**Stripe:**
- Webhook retries (exponential backoff)
- Idempotency keys for safety

---

## Integration Points

### OSRS Wiki API

**Endpoint:** `https://prices.runescape.wiki/api/v1/osrs/latest`

**Authentication:** None required

**Rate Limits:** None documented (respectful usage)

**Response Format:**
```json
{
  "data": {
    "2": { "high": 150, "low": 145, "highTime": 1705320000, "lowTime": 1705320000 },
    "4": { "high": 200, "low": 195, "highTime": 1705320000, "lowTime": 1705320000 }
  }
}
```

**Usage:** Worker fetches hourly

---

### Discord API

**OAuth Endpoints:**
- **Authorize:** `https://discord.com/api/oauth2/authorize`
- **Token:** `https://discord.com/api/oauth2/token`
- **Revoke:** `https://discord.com/api/oauth2/token/revoke`

**Bot Endpoints:**
- **Create DM:** `POST /api/v10/users/@me/channels`
- **Send Message:** `POST /api/v10/channels/{id}/messages`

**Rate Limits:**
- 50 requests/second (global)
- 5 requests/second per channel

**Token Lifecycle:**
- **Access Token:** 7 days
- **Refresh Token:** Permanent (until revoked)

---

### Stripe API

**Checkout:**
- **Create Session:** `POST /v1/checkout/sessions`
- **Success URL:** `https://gevault.com/dashboard?subscription=success`

**Customer Portal:**
- **Create Session:** `POST /v1/billing_portal/sessions`
- **Return URL:** `https://gevault.com/dashboard?portal=success`

**Webhooks:**
- **Endpoint:** `https://gevault.com/api/stripe-webhook`
- **Events:** checkout.session.completed, customer.subscription.*
- **Retry:** 3 days with exponential backoff

---

### Supabase

**Services Used:**
1. **PostgreSQL** - Database
2. **Auth** - User authentication
3. **Realtime** - Live updates (optional)
4. **Storage** - Not used currently

**Connection:**
```typescript
// Client (browser)
const supabase = createClient(SUPABASE_URL, ANON_KEY)

// Server (functions/worker)
const supabase = createClient(SUPABASE_URL, SERVICE_KEY)
```

**RPC Calls:**
```typescript
// Call database functions
await supabase.rpc('is_user_premium', { check_user_id: userId })
```

---

## Performance Considerations

### Frontend Optimization

**Code Splitting:**
- React.lazy for route-based splitting
- Vite automatic chunk splitting

**Caching:**
- Cloudflare edge caching (static assets)
- Service worker (future enhancement)

**Bundle Size:**
- Production build: ~150KB gzipped
- Tailwind purges unused CSS

---

### Database Optimization

**Indexes:**
```sql
-- Portfolio lookups
CREATE INDEX idx_portfolio_user ON portfolio_items(user_id);

-- Price history queries
CREATE INDEX idx_price_history_item_time ON price_history(item_id, timestamp DESC);

-- Alert lookups (worker)
CREATE INDEX idx_user_alerts_active ON user_alerts(active, item_id) WHERE active = TRUE;
```

**Query Optimization:**
- Worker uses batching (1000 rows)
- Prepared statements via Supabase
- Connection pooling (Supabase handles)

---

### Scaling Considerations

**Current Limits:**
- Supabase Free Tier: 500MB database, 2GB bandwidth/month
- Cloudflare Pages: Unlimited requests
- Worker: 100,000 requests/day (free tier)

**Scaling Path:**
1. Upgrade Supabase to Pro ($25/month)
2. Upgrade Cloudflare Workers ($5/10M requests)
3. Implement read replicas (Supabase)
4. Add Redis caching layer
5. Horizontal scaling (Cloudflare auto-scales)

---

## Monitoring & Observability

**Current Monitoring:**
- Cloudflare Analytics (traffic)
- Worker logs (via `wrangler tail`)
- Supabase dashboard (database metrics)

**Future Enhancements:**
- Sentry for error tracking
- LogRocket for session replay
- Custom metrics dashboard
- Uptime monitoring (UptimeRobot)

---

## Additional Resources

- [API Documentation](./API.md) - Complete API reference
- [Deployment Guide](./DEPLOYMENT.md) - Deployment procedures
- [Development Guide](./DEVELOPMENT.md) - Local development setup
- [Troubleshooting](./TROUBLESHOOTING.md) - Common issues

---

**Last Updated:** January 2025
**Architecture Version:** 1.0
