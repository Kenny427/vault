# Development Guide

Complete guide for local development and contributing to GE Vault.

## Table of Contents

- [Getting Started](#getting-started)
- [Project Structure](#project-structure)
- [Local Development Setup](#local-development-setup)
- [Development Workflow](#development-workflow)
- [Testing](#testing)
- [Coding Standards](#coding-standards)
- [Common Development Tasks](#common-development-tasks)
- [Debugging](#debugging)
- [Performance Optimization](#performance-optimization)

---

## Getting Started

### Prerequisites

- **Node.js** v20 or higher
- **npm** v10 or higher
- **Git**
- Code editor (VS Code recommended)

### Quick Start

```bash
# Clone repository
git clone https://github.com/GEVault/ge-vault.git
cd ge-vault/app

# Install dependencies
npm install

# Copy environment template
cp .env.example .env

# Edit .env with your credentials
# (See Environment Setup section below)

# Start development server
npm run dev
```

Visit `http://localhost:5173`

---

## Project Structure

```
app/
├── src/                          # React application source
│   ├── main.tsx                  # Entry point
│   ├── App.tsx                   # Root component with router
│   ├── index.css                 # Global styles
│   │
│   ├── pages/                    # Page components
│   │   ├── Landing.tsx           # Public homepage
│   │   ├── Auth.tsx              # Login/signup page
│   │   ├── Dashboard.tsx         # Portfolio management
│   │   └── Alerts.tsx            # Price alerts (premium)
│   │
│   ├── components/               # Reusable components
│   │   ├── ProtectedRoute.tsx    # Auth guard wrapper
│   │   ├── ErrorBoundary.tsx     # Error handling boundary
│   │   ├── PremiumModal.tsx      # Subscription modal
│   │   ├── PortfolioSummary.tsx  # Portfolio stats display
│   │   ├── PortfolioList.tsx     # Portfolio items grid
│   │   ├── AddItemModal.tsx      # Add item to portfolio
│   │   ├── ItemSearch.tsx        # Item autocomplete search
│   │   ├── PriceHistoryChart.tsx # Historical price chart
│   │   │
│   │   ├── alerts/               # Alert-specific components
│   │   │   ├── AlertForm.tsx     # Create/edit alert form
│   │   │   ├── AlertCard.tsx     # Individual alert display
│   │   │   ├── AlertHistory.tsx  # Alert trigger history
│   │   │   └── DiscordConnect.tsx # Discord OAuth button
│   │   │
│   │   └── __tests__/            # Component tests
│   │       ├── ErrorBoundary.test.tsx
│   │       ├── PortfolioSummary.test.tsx
│   │       └── alerts/
│   │           ├── AlertForm.test.tsx
│   │           └── AlertCard.test.tsx
│   │
│   ├── lib/                      # Utility libraries
│   │   ├── supabase.ts           # Supabase client setup
│   │   ├── premium.ts            # Subscription helpers
│   │   ├── discord.ts            # Discord OAuth helpers
│   │   ├── geTax.ts              # GE tax calculation
│   │   ├── priceHistory.ts       # Price history utilities
│   │   ├── priceParser.ts        # Price string parsing
│   │   │
│   │   └── __tests__/            # Utility tests
│   │       ├── geTax.test.ts
│   │       └── priceParser.test.ts
│   │
│   ├── types/                    # TypeScript type definitions
│   │   └── alerts.ts             # Alert-related types
│   │
│   ├── data/                     # Static data
│   │   └── alert-templates.ts    # Pre-configured alert templates
│   │
│   └── assets/                   # Static assets (images, etc.)
│
├── functions/                    # Cloudflare Pages Functions (API)
│   └── api/
│       ├── alerts/
│       │   └── [[route]].ts      # Alert CRUD endpoints
│       ├── create-checkout-session.ts
│       ├── create-portal-session.ts
│       ├── stripe-webhook.ts
│       ├── discord/
│       │   └── [[route]].ts      # Discord OAuth endpoints
│       ├── test.ts
│       └── debug-env.ts
│
├── worker/                       # Cloudflare Worker (cron job)
│   ├── src/
│   │   └── index.ts              # Price updater logic
│   ├── wrangler.toml             # Worker configuration
│   ├── package.json              # Worker dependencies
│   └── *.sql                     # Database migration files
│
├── scripts/                      # Utility scripts
│   ├── build-functions.js        # Build API functions
│   ├── seed-items.ts             # Seed items database
│   ├── seed-prices.ts            # Seed initial prices
│   ├── test-alert.ts             # Test alert system
│   ├── check-price-history.ts    # Debug price history
│   └── cleanup-old-data.ts       # Manual cleanup script
│
├── public/                       # Static files
│
├── package.json                  # Project dependencies
├── tsconfig.json                 # TypeScript config (base)
├── tsconfig.app.json             # App TypeScript config
├── tsconfig.node.json            # Node scripts TypeScript config
├── vite.config.ts                # Vite configuration
├── vitest.config.ts              # Test configuration
├── tailwind.config.js            # Tailwind CSS config
├── wrangler.toml                 # Cloudflare Pages config
├── .env.example                  # Environment template
└── .env                          # Local environment (git-ignored)
```

---

## Local Development Setup

### 1. Environment Variables

Create `.env` file in `app/` directory:

```bash
# Supabase (Database + Auth)
VITE_SUPABASE_URL=https://your-project.supabase.co
VITE_SUPABASE_ANON_KEY=your_anon_key
SUPABASE_SERVICE_KEY=your_service_role_key

# Discord OAuth
DISCORD_CLIENT_ID=your_client_id
DISCORD_CLIENT_SECRET=your_client_secret
DISCORD_BOT_TOKEN=your_bot_token
DISCORD_REDIRECT_URI=http://localhost:5173/api/discord/callback

# Stripe
STRIPE_SECRET_KEY=sk_test_your_test_key
STRIPE_WEBHOOK_SECRET=whsec_your_webhook_secret
```

**For testing:** Use Stripe test mode keys (`sk_test_*`)

---

### 2. Database Setup

**Option A: Use Existing Supabase Project**
- Update `.env` with existing project credentials

**Option B: Create New Supabase Project**
```bash
# 1. Create project at https://app.supabase.com
# 2. Run migrations (see DEPLOYMENT.md)
# 3. Seed items data
cd scripts
npx tsx seed-items.ts
```

---

### 3. Start Development Server

```bash
npm run dev
```

**Available at:**
- Frontend: `http://localhost:5173`
- API Functions: `http://localhost:5173/api/*`

**Dev server features:**
- Hot Module Replacement (HMR)
- Instant page reloads on save
- TypeScript error checking
- Tailwind CSS compilation

---

### 4. Development Tools Setup

**VS Code Extensions (Recommended):**
- ESLint
- Tailwind CSS IntelliSense
- TypeScript Vue Plugin (Volar)
- Prettier

**VS Code Settings (`.vscode/settings.json`):**
```json
{
  "editor.formatOnSave": true,
  "editor.defaultFormatter": "esbenp.prettier-vscode",
  "eslint.validate": ["javascript", "typescript", "typescriptreact"],
  "typescript.tsdk": "node_modules/typescript/lib"
}
```

---

## Development Workflow

### Branch Strategy

```
main                    # Production branch
  │
  ├── feature/alerts    # Feature branches
  ├── fix/auth-bug      # Bug fix branches
  └── docs/api          # Documentation branches
```

**Create Feature Branch:**
```bash
git checkout -b feature/your-feature-name
```

---

### Making Changes

**1. Write Tests First (TDD)**
```bash
# Create test file
touch src/components/__tests__/YourComponent.test.tsx

# Write failing test
# Then implement component to pass test
```

**2. Implement Feature**
```typescript
// src/components/YourComponent.tsx
export const YourComponent = () => {
  // Implementation
}
```

**3. Run Tests**
```bash
npm run test
```

**4. Fix Linting Issues**
```bash
npm run lint
```

**5. Build to Check for Errors**
```bash
npm run build
```

---

### Commit Guidelines

**Commit Message Format:**
```
<type>: <short description>

<optional detailed description>

<optional footer>
```

**Types:**
- `feat:` New feature
- `fix:` Bug fix
- `docs:` Documentation changes
- `style:` Code style changes (formatting)
- `refactor:` Code refactoring
- `test:` Test changes
- `chore:` Build/tooling changes

**Examples:**
```bash
git commit -m "feat: add Discord webhook notification support"
git commit -m "fix: resolve race condition in alert checking"
git commit -m "docs: update API documentation for alerts endpoint"
```

---

### Pull Request Process

**1. Push Branch:**
```bash
git push origin feature/your-feature-name
```

**2. Create PR on GitHub:**
- Title: Clear description of changes
- Description: What, why, how
- Link related issues

**3. PR Checklist:**
- [ ] Tests pass (`npm run test`)
- [ ] Linting passes (`npm run lint`)
- [ ] Build succeeds (`npm run build`)
- [ ] Documentation updated
- [ ] No console errors/warnings
- [ ] Tested locally

**4. Code Review:**
- Address reviewer feedback
- Push additional commits
- Request re-review

**5. Merge:**
- Squash and merge (recommended)
- Delete branch after merge

---

## Testing

### Running Tests

**Run All Tests:**
```bash
npm run test
```

**Run Tests in Watch Mode:**
```bash
npm run test:watch
```

**Run Tests with UI:**
```bash
npm run test:ui
```

**Run Tests with Coverage:**
```bash
npm run test:coverage
```

**Run Specific Test File:**
```bash
npm run test src/components/__tests__/AlertForm.test.tsx
```

---

### Writing Tests

#### Component Tests

**Example: Testing a Component**
```typescript
// src/components/__tests__/PortfolioSummary.test.tsx
import { render, screen } from '@testing-library/react'
import { describe, it, expect, vi } from 'vitest'
import { PortfolioSummary } from '../PortfolioSummary'

describe('PortfolioSummary', () => {
  it('displays total invested amount', async () => {
    // Mock Supabase
    vi.mock('../lib/supabase', () => ({
      supabase: {
        from: vi.fn(() => ({
          select: vi.fn(() => ({
            data: [
              { quantity: 100, buy_price: 1000 },
              { quantity: 50, buy_price: 2000 }
            ],
            error: null
          }))
        }))
      }
    }))

    render(<PortfolioSummary refreshTrigger={0} />)

    // Wait for data to load
    const totalInvested = await screen.findByText(/Total Invested/)
    expect(totalInvested).toBeInTheDocument()
    expect(screen.getByText('200,000 gp')).toBeInTheDocument()
  })
})
```

---

#### Utility Function Tests

**Example: Testing a Utility**
```typescript
// src/lib/__tests__/geTax.test.ts
import { describe, it, expect } from 'vitest'
import { calculateGETax } from '../geTax'

describe('calculateGETax', () => {
  it('calculates 1% tax for items >= 100 gp', () => {
    expect(calculateGETax(1000)).toBe(10)
    expect(calculateGETax(10000)).toBe(100)
  })

  it('returns 0 for items < 100 gp', () => {
    expect(calculateGETax(50)).toBe(0)
    expect(calculateGETax(99)).toBe(0)
  })

  it('rounds down to nearest integer', () => {
    expect(calculateGETax(155)).toBe(1)  // 1.55 -> 1
  })
})
```

---

### Test Coverage

**Coverage Targets:**
- Overall: 60-80%
- Critical paths: 90%+
- Utilities: 100%

**View Coverage Report:**
```bash
npm run test:coverage
# Opens coverage/index.html in browser
```

---

### Mocking External Services

**Mock Supabase:**
```typescript
import { vi } from 'vitest'

vi.mock('./lib/supabase', () => ({
  supabase: {
    from: vi.fn(() => ({
      select: vi.fn(() => Promise.resolve({ data: [], error: null })),
      insert: vi.fn(() => Promise.resolve({ data: {}, error: null }))
    })),
    auth: {
      getUser: vi.fn(() => Promise.resolve({
        data: { user: { id: 'test-user-id' } },
        error: null
      }))
    }
  }
}))
```

**Mock API Responses (MSW):**
```typescript
import { setupServer } from 'msw/node'
import { http, HttpResponse } from 'msw'

const server = setupServer(
  http.get('/api/alerts/list', () => {
    return HttpResponse.json([
      { id: 1, item_name: 'Dragon bones', active: true }
    ])
  })
)

beforeAll(() => server.listen())
afterEach(() => server.resetHandlers())
afterAll(() => server.close())
```

---

## Coding Standards

### TypeScript

**Strict Mode Enabled:**
```json
// tsconfig.json
{
  "compilerOptions": {
    "strict": true,
    "noUnusedLocals": true,
    "noUnusedParameters": true,
    "noImplicitReturns": true
  }
}
```

**Type Everything:**
```typescript
// ❌ Bad
const addItem = (item) => {
  // ...
}

// ✅ Good
interface Item {
  id: string
  name: string
  quantity: number
}

const addItem = (item: Item): Promise<void> => {
  // ...
}
```

**Use Type Imports:**
```typescript
import type { User } from '@supabase/supabase-js'
```

---

### React Component Patterns

**Functional Components with TypeScript:**
```typescript
interface Props {
  userId: string
  onUpdate?: () => void
}

export const MyComponent: React.FC<Props> = ({ userId, onUpdate }) => {
  const [loading, setLoading] = useState(false)

  // Component logic

  return <div>{/* JSX */}</div>
}
```

**Custom Hooks:**
```typescript
export const usePortfolio = (userId: string) => {
  const [items, setItems] = useState<PortfolioItem[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchPortfolio(userId)
      .then(setItems)
      .finally(() => setLoading(false))
  }, [userId])

  return { items, loading }
}
```

---

### Code Organization

**Import Order:**
```typescript
// 1. External libraries
import React, { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'

// 2. Internal utilities
import { supabase } from '../lib/supabase'
import { calculateGETax } from '../lib/geTax'

// 3. Components
import { ItemSearch } from './ItemSearch'
import { PriceChart } from './PriceChart'

// 4. Types
import type { PortfolioItem, Alert } from '../types'

// 5. Styles (if any)
import './MyComponent.css'
```

---

### Naming Conventions

**Files:**
- Components: `PascalCase.tsx` (e.g., `AlertForm.tsx`)
- Utilities: `camelCase.ts` (e.g., `geTax.ts`)
- Tests: `*.test.tsx` or `*.test.ts`

**Variables:**
- Constants: `UPPER_SNAKE_CASE`
- Functions: `camelCase`
- Components: `PascalCase`
- Types/Interfaces: `PascalCase`

**Examples:**
```typescript
const MAX_ITEMS = 50
const calculateTotal = () => {}
const AlertForm = () => {}
interface UserAlert {}
```

---

### ESLint Rules

**Key Rules:**
- No unused variables
- No console.log (use console.error for errors)
- Prefer const over let
- No var
- Require type annotations

**Run Linter:**
```bash
npm run lint

# Auto-fix issues
npm run lint -- --fix
```

---

## Common Development Tasks

### Adding a New API Endpoint

**1. Create Function File:**
```bash
touch app/functions/api/my-endpoint.ts
```

**2. Implement Handler:**
```typescript
// app/functions/api/my-endpoint.ts
import { supabase } from '../lib/supabase'

export const onRequestPost = async (context) => {
  const { request, env } = context

  // Authenticate
  const authHeader = request.headers.get('Authorization')
  const token = authHeader?.replace('Bearer ', '')
  const { data: { user }, error } = await supabase.auth.getUser(token)

  if (error || !user) {
    return new Response(JSON.stringify({ error: 'Unauthorized' }), {
      status: 401,
      headers: { 'Content-Type': 'application/json' }
    })
  }

  // Handle request
  const body = await request.json()

  // Process...

  return new Response(JSON.stringify({ success: true }), {
    status: 200,
    headers: { 'Content-Type': 'application/json' }
  })
}
```

**3. Test Locally:**
```bash
curl -X POST http://localhost:5173/api/my-endpoint \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"data":"value"}'
```

---

### Adding a New React Component

**1. Create Component File:**
```bash
touch app/src/components/MyComponent.tsx
```

**2. Implement Component:**
```typescript
// app/src/components/MyComponent.tsx
import { useState } from 'react'

interface Props {
  title: string
  onAction?: () => void
}

export const MyComponent: React.FC<Props> = ({ title, onAction }) => {
  const [value, setValue] = useState('')

  return (
    <div className="p-4 bg-white rounded shadow">
      <h2 className="text-xl font-bold">{title}</h2>
      <input
        type="text"
        value={value}
        onChange={(e) => setValue(e.target.value)}
        className="mt-2 px-3 py-2 border rounded"
      />
      <button
        onClick={onAction}
        className="mt-2 px-4 py-2 bg-blue-500 text-white rounded"
      >
        Action
      </button>
    </div>
  )
}
```

**3. Create Test:**
```typescript
// app/src/components/__tests__/MyComponent.test.tsx
import { render, screen, fireEvent } from '@testing-library/react'
import { describe, it, expect, vi } from 'vitest'
import { MyComponent } from '../MyComponent'

describe('MyComponent', () => {
  it('renders with title', () => {
    render(<MyComponent title="Test Title" />)
    expect(screen.getByText('Test Title')).toBeInTheDocument()
  })

  it('calls onAction when button clicked', () => {
    const mockAction = vi.fn()
    render(<MyComponent title="Test" onAction={mockAction} />)

    fireEvent.click(screen.getByText('Action'))
    expect(mockAction).toHaveBeenCalled()
  })
})
```

**4. Import and Use:**
```typescript
import { MyComponent } from './components/MyComponent'

<MyComponent title="Hello" onAction={() => console.log('Clicked')} />
```

---

### Adding a New Database Table

**1. Create Migration File:**
```sql
-- app/worker/my_new_table_migration.sql
CREATE TABLE my_new_table (
  id BIGSERIAL PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  value INTEGER,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Indexes
CREATE INDEX idx_my_new_table_user ON my_new_table(user_id);

-- RLS Policies
ALTER TABLE my_new_table ENABLE ROW LEVEL SECURITY;

CREATE POLICY my_new_table_user_policy ON my_new_table
  FOR ALL USING (auth.uid() = user_id);
```

**2. Run Migration:**
- Copy SQL to Supabase SQL Editor
- Click "Run"

**3. Create TypeScript Type:**
```typescript
// app/src/types/myNewTable.ts
export interface MyNewTable {
  id: number
  user_id: string
  name: string
  value: number | null
  created_at: string
}
```

**4. Use in Code:**
```typescript
const { data, error } = await supabase
  .from('my_new_table')
  .select('*')
  .eq('user_id', userId)
```

---

### Running Scripts

**Seed Items:**
```bash
cd app/scripts
npx tsx seed-items.ts
```

**Test Alerts:**
```bash
npx tsx test-alert.ts
```

**Check Price History:**
```bash
npx tsx check-price-history.ts
```

---

## Debugging

### Browser DevTools

**React DevTools:**
- Install React DevTools extension
- Inspect component props and state
- Profile component renders

**Network Tab:**
- Monitor API requests
- Check request/response payloads
- Verify authentication headers

**Console:**
- Check for errors
- Use `console.log` for debugging (remove before commit)

---

### Debugging API Functions

**Add Logging:**
```typescript
export const onRequestPost = async (context) => {
  console.log('Request received:', {
    method: context.request.method,
    url: context.request.url,
    headers: Object.fromEntries(context.request.headers)
  })

  // ... rest of handler
}
```

**View Logs:**
```bash
# In terminal running npm run dev
# Logs appear in console
```

---

### Debugging Worker

**Local Testing:**
```bash
cd app/worker

# Run worker locally
wrangler dev

# Trigger manually
curl -X POST http://localhost:8787
```

**Production Logs:**
```bash
wrangler tail
```

---

### Common Issues

**Issue: Module not found**
```bash
# Clear cache and reinstall
rm -rf node_modules package-lock.json
npm install
```

**Issue: TypeScript errors in tests**
```bash
# Check tsconfig.app.json excludes test files
"exclude": ["src/**/*.test.tsx", "src/**/*.test.ts"]
```

**Issue: Supabase connection fails**
```bash
# Verify environment variables
npm run dev
# Check console for VITE_SUPABASE_URL
```

---

## Performance Optimization

### React Performance

**Use React.memo for Expensive Components:**
```typescript
export const ExpensiveComponent = React.memo(({ data }) => {
  // Complex rendering
  return <div>{/* ... */}</div>
})
```

**Use useMemo for Expensive Calculations:**
```typescript
const sortedItems = useMemo(() => {
  return items.sort((a, b) => b.value - a.value)
}, [items])
```

**Use useCallback for Event Handlers:**
```typescript
const handleClick = useCallback(() => {
  // Handler logic
}, [dependencies])
```

---

### Database Query Optimization

**Use Select Specific Columns:**
```typescript
// ❌ Bad: Select everything
const { data } = await supabase.from('items').select('*')

// ✅ Good: Select only needed columns
const { data } = await supabase.from('items').select('id, name, price')
```

**Use Indexes:**
```sql
CREATE INDEX idx_portfolio_user ON portfolio_items(user_id);
```

**Batch Operations:**
```typescript
// Insert multiple items at once
const { data } = await supabase
  .from('portfolio_items')
  .insert([item1, item2, item3])
```

---

### Bundle Size Optimization

**Code Splitting:**
```typescript
// Lazy load routes
const Dashboard = lazy(() => import('./pages/Dashboard'))
const Alerts = lazy(() => import('./pages/Alerts'))

<Suspense fallback={<Loading />}>
  <Routes>
    <Route path="/dashboard" element={<Dashboard />} />
    <Route path="/alerts" element={<Alerts />} />
  </Routes>
</Suspense>
```

**Analyze Bundle:**
```bash
npm run build
npx vite-bundle-visualizer
```

---

## Additional Resources

- [React Documentation](https://react.dev)
- [TypeScript Handbook](https://www.typescriptlang.org/docs/)
- [Vite Guide](https://vitejs.dev/guide/)
- [Vitest Documentation](https://vitest.dev)
- [Tailwind CSS Docs](https://tailwindcss.com/docs)
- [Supabase JavaScript Client](https://supabase.com/docs/reference/javascript)

---

**Last Updated:** January 2025
**Development Guide Version:** 1.0
