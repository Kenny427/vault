# API Documentation

Complete reference for all GE Vault API endpoints.

## Table of Contents

- [Authentication](#authentication)
- [Alert Endpoints](#alert-endpoints)
- [Stripe Endpoints](#stripe-endpoints)
- [Discord OAuth Endpoints](#discord-oauth-endpoints)
- [Error Codes](#error-codes)

---

## Authentication

Most endpoints require authentication using Supabase session tokens.

**Authentication Header:**
```
Authorization: Bearer <supabase_jwt_token>
```

**Getting the Token:**
```javascript
const { data: { session } } = await supabase.auth.getSession()
const token = session.access_token
```

**Unauthenticated Response (401):**
```json
{
  "error": "Unauthorized"
}
```

---

## Alert Endpoints

Base path: `/api/alerts`

### POST /api/alerts/create

Creates a new price alert for the authenticated user.

**Authentication:** Required (Bearer token)

**Premium:** Required (active subscription)

**Request Body:**
```json
{
  "item_id": "536",
  "item_name": "Dragon bones",
  "alert_type": "absolute",
  "price_direction": "down",
  "target_price": 5000,
  "notification_type": "bot_dm",
  "behavior": "one_shot",
  "notes": "Buy when cheap"
}
```

**Request Fields:**

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `item_id` | string | Yes | OSRS item ID |
| `item_name` | string | Yes | Item display name |
| `alert_type` | string | Yes | `"absolute"` or `"percentage_change"` |
| `price_direction` | string | Yes | `"up"`, `"down"`, or `"either"` |
| `target_price` | number | Conditional | Required for `absolute` alerts (must be > 0) |
| `percentage_threshold` | number | Conditional | Required for `percentage_change` alerts (must be > 0) |
| `baseline_price` | number | Conditional | Required for `percentage_change` alerts (must be > 0) |
| `notification_type` | string | Yes | `"bot_dm"` or `"webhook"` |
| `discord_webhook_url` | string | Conditional | Required for `webhook` type (must be valid Discord webhook URL) |
| `behavior` | string | Yes | `"one_shot"`, `"recurring"`, or `"cooldown"` |
| `cooldown_hours` | number | Conditional | Required for `cooldown` behavior (1-168 hours) |
| `notes` | string | No | Optional user notes |

**Alert Types Explained:**

- **Absolute:** Triggers when item price reaches exact threshold
  - Example: Alert when Dragon bones drop below 5,000 gp
  - Required fields: `target_price`

- **Percentage Change:** Triggers when price changes by percentage from baseline
  - Example: Alert when Dragon bones drop 10% from 5,500 gp baseline
  - Required fields: `percentage_threshold`, `baseline_price`

**Behaviors Explained:**

- **one_shot:** Alert triggers once, then automatically deactivates
- **recurring:** Alert triggers every time condition is met (hourly checks)
- **cooldown:** Alert triggers, then waits X hours before allowing next trigger

**Notification Types:**

- **bot_dm:** Discord bot sends direct message to user
  - Requires: User has connected Discord account
  - Validated at creation time

- **webhook:** Posts to custom Discord webhook URL
  - Requires: Valid Discord webhook URL
  - Must contain `discord.com` and `/api/webhooks/`

**Success Response (200):**
```json
{
  "id": 123,
  "user_id": "550e8400-e29b-41d4-a716-446655440000",
  "item_id": "536",
  "item_name": "Dragon bones",
  "alert_type": "absolute",
  "target_price": 5000,
  "percentage_threshold": null,
  "baseline_price": null,
  "price_direction": "down",
  "notification_type": "bot_dm",
  "discord_user_id": "123456789",
  "discord_webhook_url": null,
  "behavior": "one_shot",
  "cooldown_hours": 24,
  "notes": "Buy when cheap",
  "active": true,
  "created_at": "2025-01-15T12:00:00Z",
  "last_triggered_at": null,
  "trigger_count": 0
}
```

**Error Responses:**

**400 - Validation Failed:**
```json
{
  "error": "Validation failed",
  "details": [
    "Item is required",
    "Target price must be greater than 0"
  ]
}
```

**401 - Not Authenticated:**
```json
{
  "error": "Unauthorized"
}
```

**403 - Not Premium:**
```json
{
  "error": "Premium subscription required",
  "message": "Upgrade to premium to create price alerts"
}
```

**409 - Discord Not Connected:**
```json
{
  "error": "Discord not connected",
  "message": "Please connect your Discord account to use bot DM notifications"
}
```

**Example cURL:**
```bash
curl -X POST https://gevault.com/api/alerts/create \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "item_id": "536",
    "item_name": "Dragon bones",
    "alert_type": "absolute",
    "price_direction": "down",
    "target_price": 5000,
    "notification_type": "bot_dm",
    "behavior": "one_shot"
  }'
```

---

### GET /api/alerts/list

Retrieves all price alerts for the authenticated user.

**Authentication:** Required (Bearer token)

**Query Parameters:** None

**Success Response (200):**
```json
[
  {
    "id": 123,
    "user_id": "550e8400-e29b-41d4-a716-446655440000",
    "item_id": "536",
    "item_name": "Dragon bones",
    "alert_type": "absolute",
    "target_price": 5000,
    "price_direction": "down",
    "notification_type": "bot_dm",
    "behavior": "one_shot",
    "active": true,
    "created_at": "2025-01-15T12:00:00Z",
    "last_triggered_at": null,
    "trigger_count": 0,
    "discord_connections": {
      "discord_user_id": "123456789",
      "discord_username": "username#0000"
    }
  },
  {
    "id": 124,
    "item_id": "4151",
    "item_name": "Abyssal whip",
    "alert_type": "percentage_change",
    "percentage_threshold": 10,
    "baseline_price": 2000000,
    "price_direction": "either",
    "notification_type": "webhook",
    "discord_webhook_url": "https://discord.com/api/webhooks/...",
    "behavior": "recurring",
    "active": true,
    "created_at": "2025-01-15T13:00:00Z",
    "trigger_count": 3
  }
]
```

**Empty Response (200):**
```json
[]
```

**Example cURL:**
```bash
curl https://gevault.com/api/alerts/list \
  -H "Authorization: Bearer $TOKEN"
```

---

### PATCH /api/alerts/update

Updates an existing alert.

**Authentication:** Required (Bearer token)

**Authorization:** Can only update own alerts

**Request Body:**
```json
{
  "id": 123,
  "active": false,
  "target_price": 4500,
  "notes": "Updated notes"
}
```

**Required Field:**
- `id` (number) - Alert ID to update

**Updatable Fields:**
- All fields from alert creation
- `active` (boolean) - Enable/disable alert

**Success Response (200):**
```json
{
  "id": 123,
  "user_id": "550e8400-e29b-41d4-a716-446655440000",
  "item_id": "536",
  "item_name": "Dragon bones",
  "active": false,
  "target_price": 4500,
  "notes": "Updated notes",
  ...
}
```

**Error Responses:**

**400 - Missing ID:**
```json
{
  "error": "Alert ID is required"
}
```

**404 - Alert Not Found:**
```json
{
  "error": "Alert not found"
}
```

**Example cURL:**
```bash
curl -X PATCH https://gevault.com/api/alerts/update \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "id": 123,
    "active": false
  }'
```

---

### DELETE /api/alerts/delete

Deletes an alert.

**Authentication:** Required (Bearer token)

**Authorization:** Can only delete own alerts

**Request Body:**
```json
{
  "id": 123
}
```

**Success Response (200):**
```json
{
  "success": true
}
```

**Error Responses:**

**400 - Missing ID:**
```json
{
  "error": "Alert ID is required"
}
```

**404 - Alert Not Found:**
```json
{
  "error": "Alert not found"
}
```

**Example cURL:**
```bash
curl -X DELETE https://gevault.com/api/alerts/delete \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"id": 123}'
```

---

## Stripe Endpoints

Stripe integration for premium subscriptions.

### POST /api/create-checkout-session

Creates a Stripe checkout session for subscription purchase.

**Authentication:** None (validates internally)

**Request Body:**
```json
{
  "tier": "standard",
  "billing": "monthly",
  "userId": "550e8400-e29b-41d4-a716-446655440000",
  "email": "user@example.com"
}
```

**Request Fields:**

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `tier` | string | Yes | `"coffee"`, `"standard"`, `"super"`, or `"custom"` |
| `billing` | string | Yes | `"monthly"` or `"annual"` |
| `userId` | string | Yes | Supabase user UUID |
| `email` | string | Yes | User email address |
| `customAmount` | number | Conditional | Required for `custom` tier ($2-$999) |

**Pricing Tiers:**

| Tier | Monthly | Annual |
|------|---------|--------|
| Coffee ☕ | $2.00 | $20.00 |
| Standard ⭐ | $5.00 | $50.00 |
| Super 🚀 | $10.00 | $100.00 |
| Custom 💖 | $2-$999 | Same × 10 |

**Success Response (200):**
```json
{
  "url": "https://checkout.stripe.com/c/pay/cs_test_..."
}
```

**Error Responses:**

**400 - Invalid Amount:**
```json
{
  "error": "Custom amount must be between $2 and $999"
}
```

**400 - Missing Fields:**
```json
{
  "error": "Missing required field: tier"
}
```

**500 - Stripe Error:**
```json
{
  "error": "Failed to create checkout session",
  "details": "Stripe error message"
}
```

**Workflow:**
1. Server gets or creates Stripe customer
2. Creates checkout session with dynamic pricing
3. Stores `stripe_customer_id` in database
4. Returns checkout URL
5. User completes payment on Stripe
6. Webhook creates subscription record

**Example cURL:**
```bash
curl -X POST https://gevault.com/api/create-checkout-session \
  -H "Content-Type: application/json" \
  -d '{
    "tier": "standard",
    "billing": "monthly",
    "userId": "550e8400-e29b-41d4-a716-446655440000",
    "email": "user@example.com"
  }'
```

---

### POST /api/create-portal-session

Creates a Stripe Customer Portal session for subscription management.

**Authentication:** None (customer ID validates ownership)

**Request Body:**
```json
{
  "customerId": "cus_Abc123XyZ"
}
```

**Success Response (200):**
```json
{
  "url": "https://billing.stripe.com/p/session/test_..."
}
```

**Error Responses:**

**400 - Missing Customer ID:**
```json
{
  "error": "Customer ID is required"
}
```

**500 - Stripe Error:**
```json
{
  "error": "Failed to create portal session"
}
```

**Portal Features:**
- Update payment method
- View invoices
- Update billing address
- Cancel subscription
- Resume canceled subscription

**Example cURL:**
```bash
curl -X POST https://gevault.com/api/create-portal-session \
  -H "Content-Type: application/json" \
  -d '{"customerId": "cus_Abc123XyZ"}'
```

---

### POST /api/stripe-webhook

Handles Stripe webhook events (server-to-server).

**Authentication:** Stripe signature verification

**Headers:**
```
stripe-signature: t=timestamp,v1=signature
```

**Events Handled:**

#### 1. checkout.session.completed
Payment successful, creates subscription record.

**Webhook Payload (relevant fields):**
```json
{
  "type": "checkout.session.completed",
  "data": {
    "object": {
      "customer": "cus_Abc123XyZ",
      "subscription": "sub_XyZ789",
      "metadata": {
        "user_id": "550e8400-e29b-41d4-a716-446655440000",
        "tier": "standard",
        "billing": "monthly"
      }
    }
  }
}
```

**Database Action:**
Inserts/updates `user_subscriptions` table:
```sql
{
  user_id: metadata.user_id,
  stripe_customer_id: customer,
  stripe_subscription_id: subscription,
  status: 'active',
  plan_type: metadata.billing,
  current_period_start: NOW(),
  current_period_end: NOW() + INTERVAL
}
```

---

#### 2. customer.subscription.updated
Subscription details changed.

**Database Action:**
Updates subscription record with:
- `current_period_start/end`
- `cancel_at_period_end`
- `canceled_at`
- `status`

---

#### 3. customer.subscription.deleted
Subscription canceled immediately.

**Database Action:**
```sql
UPDATE user_subscriptions SET
  status = 'canceled',
  canceled_at = NOW()
WHERE stripe_subscription_id = subscription_id
```

---

#### 4. invoice.payment_failed
Payment declined or failed.

**Database Action:**
```sql
UPDATE user_subscriptions SET
  status = 'past_due'
WHERE stripe_customer_id = customer_id
```

---

#### 5. invoice.payment_succeeded
Payment processed successfully.

**Database Action:**
```sql
UPDATE user_subscriptions SET
  status = 'active',
  current_period_start = period_start,
  current_period_end = period_end
WHERE stripe_customer_id = customer_id
```

---

**Success Response (200):**
```json
{
  "received": true
}
```

**Error Responses:**

**400 - Invalid Signature:**
```json
{
  "error": "Invalid signature"
}
```

**500 - Processing Error:**
```json
{
  "error": "Webhook processing failed",
  "type": "checkout.session.completed"
}
```

---

## Discord OAuth Endpoints

Discord account connection for bot DM notifications.

### GET /api/discord/connect

Initiates Discord OAuth flow.

**Authentication:** Required (query parameter)

**Query Parameters:**
```
?token=<supabase_jwt_token>
```

**Process:**
1. Validates Supabase token
2. Generates random OAuth state (UUID)
3. Stores state in `oauth_states` table with 10-minute expiry
4. Redirects to Discord authorization

**Response:** HTTP 302 Redirect
```
Location: https://discord.com/api/oauth2/authorize?
  client_id=YOUR_CLIENT_ID&
  redirect_uri=https://gevault.com/api/discord/callback&
  response_type=code&
  scope=identify&
  state=550e8400-e29b-41d4-a716-446655440000
```

**OAuth Scope:**
- `identify` - Read Discord user ID and username only

**Example:**
```html
<a href="/api/discord/connect?token=<jwt>">
  Connect Discord
</a>
```

---

### GET /api/discord/callback

Handles Discord OAuth callback.

**Authentication:** None (validates state)

**Query Parameters:**
```
?code=<auth_code>&state=<uuid>
```

**Process:**
1. Verifies state exists in `oauth_states` table
2. Checks state not used and not expired
3. Exchanges code for access token
4. Fetches Discord user info
5. Stores connection in `discord_connections` table
6. Marks state as used
7. Redirects to `/alerts` page

**Discord Connection Record:**
```json
{
  "user_id": "550e8400-e29b-41d4-a716-446655440000",
  "discord_user_id": "123456789012345678",
  "discord_username": "username#0000",
  "access_token": "OAuth2AccessToken",
  "refresh_token": "OAuth2RefreshToken",
  "token_expires_at": "2025-01-22T12:00:00Z",
  "connected_at": "2025-01-15T12:00:00Z"
}
```

**Token Expiry:** 7 days (604,800 seconds)

**Response:** HTTP 302 Redirect
```
Location: https://gevault.com/alerts?discord=connected
```

**Error Responses:**

**400 - Invalid State:**
```json
{
  "error": "Invalid or expired OAuth state"
}
```

**500 - Discord Error:**
```json
{
  "error": "Failed to exchange code for token"
}
```

---

### POST /api/discord/refresh

Refreshes expired Discord access token.

**Authentication:** Required (Bearer token)

**Request Body:** None (uses stored refresh token)

**Process:**
1. Fetches user's Discord connection
2. Uses `refresh_token` to get new access token
3. Updates `discord_connections` with new tokens
4. Returns new expiry time

**Success Response (200):**
```json
{
  "success": true,
  "expires_at": "2025-01-22T12:00:00Z"
}
```

**Error Responses:**

**404 - Not Connected:**
```json
{
  "error": "Discord not connected"
}
```

**500 - Refresh Failed:**
```json
{
  "error": "Failed to refresh token",
  "details": "Discord API error"
}
```

**Example cURL:**
```bash
curl -X POST https://gevault.com/api/discord/refresh \
  -H "Authorization: Bearer $TOKEN"
```

---

### DELETE /api/discord/disconnect

Removes Discord connection.

**Authentication:** Required (Bearer token)

**Request Body:** None

**Process:**
1. Deletes `discord_connections` record for user
2. User can no longer create `bot_dm` alerts
3. Existing `bot_dm` alerts will fail to send

**Success Response (200):**
```json
{
  "success": true
}
```

**Error Responses:**

**404 - Not Connected:**
```json
{
  "error": "Discord not connected"
}
```

**Example cURL:**
```bash
curl -X DELETE https://gevault.com/api/discord/disconnect \
  -H "Authorization: Bearer $TOKEN"
```

---

## Error Codes

Standard HTTP status codes used across all endpoints.

| Code | Meaning | Common Causes |
|------|---------|---------------|
| 200 | OK | Request successful |
| 201 | Created | Resource created successfully |
| 400 | Bad Request | Validation failed, missing fields |
| 401 | Unauthorized | Missing or invalid auth token |
| 403 | Forbidden | Not premium, insufficient permissions |
| 404 | Not Found | Resource doesn't exist |
| 409 | Conflict | Discord not connected, duplicate resource |
| 500 | Internal Server Error | Server error, external API failure |

**Error Response Format:**
```json
{
  "error": "Human-readable error message",
  "details": "Additional context (optional)"
}
```

**Validation Error Format:**
```json
{
  "error": "Validation failed",
  "details": [
    "Field 'item_id' is required",
    "Field 'target_price' must be greater than 0"
  ]
}
```

---

## Rate Limiting

**Worker Notifications:**
- Maximum 50 notifications per second (Discord API limit)
- Applies to both bot DM and webhook notifications

**API Endpoints:**
- No explicit rate limits currently enforced
- Cloudflare provides DDoS protection
- Future: May implement per-user rate limits

---

## Testing Endpoints

Development/debugging endpoints (may not be available in production).

### GET /api/test

Simple connectivity test.

**Response (200):**
```json
{
  "message": "Test endpoint working!",
  "timestamp": "2025-01-15T12:00:00.000Z"
}
```

### GET /api/debug-env

Check environment variable configuration.

**Response (200):**
```json
{
  "env_keys": [
    "STRIPE_SECRET_KEY",
    "SUPABASE_URL",
    "SUPABASE_SERVICE_KEY",
    "DISCORD_CLIENT_ID"
  ],
  "has_stripe": true,
  "has_supabase_url": true,
  "has_supabase_key": true
}
```

---

## Additional Resources

- [Architecture Documentation](./ARCHITECTURE.md) - System design and data flows
- [Development Guide](./DEVELOPMENT.md) - Local development setup
- [Troubleshooting](./TROUBLESHOOTING.md) - Common issues and solutions

---

**Last Updated:** January 2025
**API Version:** 1.0
