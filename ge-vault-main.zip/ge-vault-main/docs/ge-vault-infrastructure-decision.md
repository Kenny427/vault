# GE Vault - Infrastructure Stack Decision

**Date:** November 8, 2025 (Late Evening)  
**Status:** Finalized

---

## Final Architecture

```
┌──────────────────────────────────────────────────────────┐
│                   CLOUDFLARE ECOSYSTEM                   │
│                                                          │
│  ┌─────────────────────┐  ┌──────────────────────────┐  │
│  │  Pages              │  │  Workers                 │  │
│  │  (Static Hosting)   │  │  - API routes            │  │
│  │                     │  │  - /api/refresh-prices   │  │
│  │  gevault.com        │  │  - Cron jobs (daily)     │  │
│  │  React + Vite       │  │  - Edge compute          │  │
│  └─────────────────────┘  └──────────────────────────┘  │
│                                                          │
│  ┌────────────────────────────────────────────────────┐  │
│  │  DNS & Domain Management                           │  │
│  │  gevault.com (already purchased)                   │  │
│  └────────────────────────────────────────────────────┘  │
└──────────────────────────┬───────────────────────────────┘
                           │
                           │ HTTPS API calls
                           ▼
                  ┌─────────────────┐
                  │   SUPABASE      │
                  │                 │
                  │  - PostgreSQL   │
                  │  - Auth         │
                  │  - RLS          │
                  └─────────────────┘
```

---

## Decision: Cloudflare Pages (Not Vercel)

### Why Cloudflare Pages Won

✅ **Domain Integration**
- Domain already on Cloudflare (gevault.com)
- One-click DNS configuration
- No external DNS management

✅ **Unified Ecosystem**
- Pages + Workers + Cron in one dashboard
- No context switching between services
- Consistent deployment experience

✅ **Better Worker Integration**
- Workers naturally extend Pages
- /functions directory → automatic API routes
- Shared environment variables

✅ **Cost & Performance**
- Free tier: Unlimited builds, CDN, SSL
- Edge CDN performance
- No cold starts (Workers are fast)

### Vercel Comparison

| Feature | Cloudflare Pages | Vercel |
|---------|------------------|--------|
| Free builds | ✅ Unlimited | ✅ Unlimited |
| Custom domain | ✅ Same registrar | ⚠️ External DNS |
| API routes | ✅ Workers | ✅ Serverless Functions |
| Cron jobs | ✅ Built-in | ❌ Need external service |
| Edge performance | ✅ Excellent | ✅ Excellent |
| Ecosystem fit | ✅ Domain + Workers | ⚠️ Separate service |

**Conclusion:** Cloudflare Pages wins for ecosystem integration and domain management simplicity.

---

## Decision: Supabase (Not Cloudflare D1)

### Why Supabase Won

✅ **Built-in Authentication**
- Email/password auth ready out-of-box
- Magic link authentication
- OAuth providers (Google, GitHub, etc.)
- Session management handled
- JWT tokens generated automatically
- **Saves 10-15 hours of development time**

✅ **Row Level Security (RLS)**
- PostgreSQL RLS policies
- Database-enforced multi-tenancy
- Can't accidentally leak data
- Proven security model

✅ **Auto-Generated API**
- REST API auto-generated from schema
- Real-time subscriptions available
- No need to write CRUD endpoints

✅ **Free Tier Clarity**
- **Unlimited projects per account** ✨
- 500MB storage **per project**
- 50k MAU **per project**
- Projects are isolated (don't share quotas)

✅ **Mature Ecosystem**
- Battle-tested PostgreSQL
- Excellent documentation
- Point-in-time recovery
- Automatic backups

### D1 Comparison

| Feature | Supabase (PostgreSQL) | Cloudflare D1 (SQLite) |
|---------|----------------------|------------------------|
| Built-in auth | ✅ Full-featured | ❌ Need external (Clerk, etc.) |
| Row Level Security | ✅ Native PostgreSQL RLS | ❌ Manual in Workers |
| Auto API | ✅ REST + Realtime | ❌ Raw SQL only |
| Maturity | ✅ Production-ready | ⚠️ Recently GA'd |
| Free tier | ✅ 500MB, 50k MAU | ✅ 1GB, 100k reads/day |
| Multi-tenancy | ✅ Database-enforced | ⚠️ App-level only |
| Dev time | ✅ Low (auth included) | ⚠️ Medium (build auth) |

### The Auth Problem with D1

**What you'd need to build:**

```typescript
// 1. User registration
- Password hashing (bcrypt)
- Email verification system
- Password reset flow
- JWT token generation
- Token refresh logic
- Session management

// 2. Per-request authentication
- Verify JWT on every request
- Extract user ID from token
- Handle token expiration

// 3. Data isolation (CRITICAL)
// Every single query must manually filter by user_id
export async function getUserPortfolio(context, userId) {
  // If you forget this WHERE clause even once, data leak!
  return await context.env.DB
    .prepare('SELECT * FROM portfolio_items WHERE user_id = ?')
    .bind(userId)
    .all()
}
```

**Estimated dev time:** 10-15 hours to replicate Supabase auth  
**Risk:** Manual security = higher chance of bugs/leaks

### With Supabase Auth

```typescript
// 1. User registration (1 line)
await supabase.auth.signUp({ email, password })

// 2. Authentication (automatic)
// Supabase client handles JWT automatically

// 3. Data isolation (automatic)
// RLS policies enforce at database level
await supabase
  .from('portfolio_items')
  .select('*')
// Postgres automatically adds: WHERE user_id = auth.uid()
```

**Estimated dev time:** 1 hour for auth setup  
**Risk:** Database-enforced = can't forget to filter

**Conclusion:** Supabase wins because auth complexity isn't worth the "all-Cloudflare" aesthetic.

---

## Decision: Cloudflare Workers (API + Cron)

### API Routes

**Structure:**
```
/functions/api/refresh-prices.ts → /api/refresh-prices
```

Workers automatically map /functions to API endpoints.

**Benefits:**
- No separate API deployment
- Edge compute (fast everywhere)
- Free tier: 100k requests/day
- Access to Supabase via service key

### Cron Jobs

**Daily price update:**
```javascript
// wrangler.toml
[triggers]
crons = ["0 0 * * *"] // Daily at midnight UTC

// Runs updatePrices() automatically
```

**Benefits:**
- Built into Workers (no external service)
- Free tier: Included
- Same code as manual refresh endpoint

---

## The "Multiple Supabase Projects" Myth

**Question:** Can you have multiple Supabase projects on free tier?

**Answer:** **YES! Unlimited projects.** ✨

### How It Actually Works

```
Your Supabase Account (Free)
├─ Project 1: [Your existing project]
│  └─ 500MB storage, 50k MAU
├─ Project 2: [Your other project]
│  └─ 500MB storage, 50k MAU
└─ Project 3: GE Vault
   └─ 500MB storage, 50k MAU

Total cost: $0/month
```

**Each project has its own quota** - they don't share limits.

### Upgrade Only When Needed

You upgrade **per project**, not account-wide:

```
Project 1: Free tier (under limits)
Project 2: Free tier (under limits)
Project 3: Pro ($25/mo) - hit 500MB storage

Cost: $25/month for just GE Vault
```

**For GE Vault specifically:**
- ~10-20 MB at MVP scale
- ~50-100 MB with thousands of users
- Won't hit 500MB for years

---

## Cost Breakdown

### Free Tier Limits

| Service | Free Tier | GE Vault Usage (MVP) | Headroom |
|---------|-----------|---------------------|----------|
| Cloudflare Pages | Unlimited builds | ~10 builds/week | ∞ |
| Cloudflare Workers | 100k req/day | ~1-2k/day | 50x |
| Supabase Storage | 500MB | ~10MB | 50x |
| Supabase MAU | 50k users | ~100-1000 | 50-500x |

### Monthly Costs

```
Phase 1 (MVP):
- Cloudflare Pages: $0
- Cloudflare Workers: $0
- Supabase: $0
- Domain: ~$1 (annual $10.46 ÷ 12)
Total: ~$1/month

Phase 2 (Growing - 5k users):
- Everything still free
Total: ~$1/month

Phase 3 (Scale - 50k+ users):
- Might need Supabase Pro: $25/mo
- Still under Workers free tier
Total: ~$26/month
```

### When You'd Upgrade

**Cloudflare Workers Paid ($5/mo):**
- If you exceed 100k requests/day
- At 5k DAU, unlikely to hit this
- Would need ~20 requests per user per day

**Supabase Pro ($25/mo):**
- If storage exceeds 500MB
- If users exceed 50k MAU
- At MVP scale, years away from this

**Realistic timeline:** 12-24 months on all free tiers.

---

## Alternative Considered: Full Cloudflare Stack

### Cloudflare D1 + Clerk Auth Option

```
Architecture: Pages + Workers + D1 + Clerk
```

**Why we didn't choose it:**

❌ **More complex:**
- D1 requires manual security in Workers
- Clerk adds another external service
- More moving parts to maintain

❌ **Higher development cost:**
- Wire Clerk to D1
- Implement security filters in every Worker
- Test multi-tenant data isolation
- Estimated +10 hours dev time

❌ **Questionable cost savings:**
- Supabase: Free → $25/mo upgrade (years away)
- Clerk: Free up to 10k MAU, then $25/mo
- D1: Free → $5/mo if needed
- **Same cost at scale, worse DX**

✅ **Only advantage:**
- Everything except auth in Cloudflare
- Not worth the complexity trade-off

### Migration Path (If Needed)

If we later decide Supabase is too much:

```
1. Export data from Supabase (PostgreSQL dump)
2. Create D1 database
3. Import data to D1
4. Add Clerk auth
5. Update Workers to use D1
6. Switch DNS
```

This migration is straightforward and gives us an exit path.

**But realistically:** Supabase will work fine for years.

---

## Deployment Workflow

### Development
```bash
# Run locally
npm run dev

# Test with local Supabase (optional)
npx supabase start
```

### Production Deployment

```bash
# Build React app
npm run build

# Deploy to Cloudflare Pages
npx wrangler pages deploy dist --project-name=ge-vault

# Deploy Workers (if updated)
npx wrangler deploy

# Set environment variables in Cloudflare dashboard
SUPABASE_URL=https://xxxxx.supabase.co
SUPABASE_SERVICE_KEY=xxxxx
```

**Automatic:**
- SSL certificate (Cloudflare)
- CDN distribution (global edge)
- DNS configuration (same service)

---

## Final Stack Summary

```
Frontend:     Cloudflare Pages
API:          Cloudflare Workers  
Cron Jobs:    Cloudflare Workers (built-in triggers)
Database:     Supabase (PostgreSQL)
Auth:         Supabase Auth (built-in)
Domain:       Cloudflare Registrar (already purchased)
Analytics:    Plausible (privacy-friendly)
Monitoring:   UptimeRobot + Sentry
```

**Why this stack is optimal:**
- ✅ 95% in Cloudflare ecosystem (hosting, API, domain, cron)
- ✅ Supabase handles hard parts (auth, security, database)
- ✅ All free tier services at MVP scale
- ✅ Best-in-class for each component
- ✅ Simple to maintain and deploy
- ✅ Clear upgrade path if needed

**Total monthly cost:** ~$1 until thousands of users

---

## Key Takeaways

1. **Use Cloudflare Pages** (not Vercel) - better ecosystem integration
2. **Use Supabase** (not D1) - auth saves 10+ hours, RLS is critical
3. **Use Cloudflare Workers** for API + Cron - natural fit with Pages
4. **Supabase has unlimited free projects** - no 2-project limit myth
5. **Stack costs ~$1/month** until significant scale (thousands of users)

---

## Next Steps

1. ✅ Domain secured (gevault.com)
2. ✅ Infrastructure decided (Cloudflare + Supabase)
3. ⏭️ Create Supabase project
4. ⏭️ Deploy database schema
5. ⏭️ Build React app
6. ⏭️ Deploy to Cloudflare Pages

**Ready to build!** 🚀
