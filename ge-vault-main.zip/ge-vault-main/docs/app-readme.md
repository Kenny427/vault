# GE Vault - OSRS Portfolio Tracker

A modern web application for tracking Old School RuneScape Grand Exchange investments and portfolio performance with real-time price data and accurate GE tax calculations.

**Live Site:** https://gevault.com

## Features

### Core Features (Free)
- **Portfolio Management**: Track your OSRS item investments with purchase prices and quantities
- **Lot-Based Tracking**: Multiple purchases of same item grouped with weighted average pricing
- **Real-Time Pricing**: Integrated with OSRS Wiki API for current item prices (4,500+ items)
- **GE Tax Calculations**: Automatic 2% tax calculation with 40+ exempt items
- **Profit/Loss Tracking**: Accurate profit/loss with tax-adjusted calculations
- **User Authentication**: Secure auth via Supabase with email/password
- **Item Search**: Fast search across all tradeable OSRS items with autocomplete
- **Automated Price Updates**: Daily price updates via Cloudflare Worker (midnight UTC)
- **Price History**: Historical price tracking for trend analysis
- **Modern UI**: Clean, responsive design with Tailwind CSS

### Premium Features (Pay What You Want)

**Support the developer and unlock premium features:**
- ☕ **Coffee Supporter**: $2/month or $20/year
- ⭐ **Standard Supporter**: $5/month or $50/year (recommended)
- 🚀 **Super Supporter**: $10/month or $100/year
- 💎 **Custom Amount**: Choose your own ($2-999)

**All tiers include the same features:**
- **Price Alerts**: ✅ Get notified via Discord when items hit target prices
  - One-click Discord connection (join server + OAuth)
  - Bot DM notifications or custom webhooks
  - Absolute price targets or percentage-based alerts
  - One-shot, recurring, or cooldown alert behaviors
  - Alert history and analytics
- **CSV Export**: ✅ Download portfolio data with tax calculations and weighted averages
- **Manual Price Refresh**: ✅ Refresh prices on-demand (15-minute cooldown)
- **Account Management**: ✅ Self-service subscription control via Stripe portal
- **Advanced Analytics**: Detailed profit tracking and performance insights
- **Historical Charts**: Full price history and trend visualization
- **Unlimited Portfolio Items**: No limits on tracking
- **Priority Support**: Faster response to issues

See [STRIPE_SETUP.md](STRIPE_SETUP.md) for premium setup instructions.

## Tech Stack

### Frontend
- **React 18** - UI framework
- **TypeScript** - Type safety
- **Vite 7** - Build tool and dev server
- **React Router 7** - Client-side routing
- **Tailwind CSS 3** - Styling
- **Stripe** - Payment processing

### Backend & Infrastructure
- **Supabase** - PostgreSQL database + authentication
- **Cloudflare Pages** - Hosting and CDN (with Functions for API)
- **Cloudflare Workers** - Automated price updates (daily cron)
- **GitHub Actions** - CI/CD pipeline
- **OSRS Wiki API** - Price and item data
- **Stripe** - Subscription management

## Getting Started

### Prerequisites

- Node.js 20+
- npm
- Supabase account
- Cloudflare account (for deployment)
- Stripe account (for premium features, optional)

### Local Development

1. **Clone the repository**
   ```bash
   git clone https://github.com/GEVault/ge-vault.git
   cd ge-vault
   ```

2. **Install dependencies**
   ```bash
   cd app
   npm install
   ```

3. **Set up environment variables**

   Copy `.env.example` to `.env.local` and fill in your values:
   ```env
   # Supabase
   VITE_SUPABASE_URL=your_supabase_url
   VITE_SUPABASE_ANON_KEY=your_supabase_anon_key
   SUPABASE_SERVICE_KEY=your_service_key  # For backend only

   # Discord (optional for price alerts)
   DISCORD_CLIENT_ID=your_discord_client_id
   DISCORD_CLIENT_SECRET=your_discord_client_secret
   DISCORD_BOT_TOKEN=your_discord_bot_token
   DISCORD_REDIRECT_URI=http://localhost:5173/api/discord/callback
   VITE_DISCORD_SERVER_INVITE=https://discord.gg/your_invite_code

   # Stripe (optional for premium features)
   VITE_STRIPE_PUBLISHABLE_KEY=pk_test_your_key
   STRIPE_SECRET_KEY=sk_test_your_key
   STRIPE_WEBHOOK_SECRET=whsec_xxx
   ```

4. **Set up the database**

   Run these migrations in your Supabase SQL editor:
   - Core tables (items, portfolio, prices)
   - [price_history_migration.sql](worker/price_history_migration.sql)
   - [subscriptions_migration.sql](worker/subscriptions_migration.sql) (for premium)
   - [discord_alerts_migration.sql](worker/discord_alerts_migration.sql) (for Discord alerts)
   - [refresh_prices_function.sql](worker/refresh_prices_function.sql) (for manual price refresh)

5. **Seed the database**
   ```bash
   npm run seed:items   # Load 4,500 OSRS items
   npm run seed:prices  # Load current prices
   ```

6. **Start the dev server**
   ```bash
   npm run dev
   ```

   Open http://localhost:5173

### Available Scripts

- `npm run dev` - Start development server
- `npm run build` - Build for production
- `npm run preview` - Preview production build
- `npm run lint` - Run ESLint
- `npm run seed:items` - Seed items table from OSRS Wiki API
- `npm run seed:prices` - Seed prices from OSRS Wiki API

## Project Structure

```
app/
├── src/
│   ├── components/      # React components
│   │   ├── alerts/                    # Price alerts system
│   │   │   ├── DiscordConnect.tsx    # One-click Discord OAuth
│   │   │   ├── AlertForm.tsx         # Create/edit alerts
│   │   │   ├── AlertCard.tsx         # Display active alerts
│   │   │   └── AlertHistory.tsx      # Alert trigger history
│   │   ├── PremiumModal.tsx          # Stripe subscription UI
│   │   ├── PortfolioList.tsx         # Grouped portfolio view
│   │   └── PortfolioSummary.tsx      # Tax-aware summary
│   ├── lib/
│   │   ├── csvExport.ts         # CSV export utilities
│   │   ├── geTax.ts             # GE tax calculations
│   │   ├── premium.ts           # Premium feature utilities
│   │   └── supabase.ts          # Supabase client
│   └── pages/
│       ├── Account.tsx          # Account & subscription management
│       ├── Alerts.tsx           # Price alerts page (premium)
│       └── ...                  # Other route pages
├── functions/
│   └── api/            # Cloudflare Functions
│       ├── discord/[[route]].ts        # Discord OAuth endpoints
│       ├── create-checkout-session.ts  # Stripe checkout
│       └── stripe-webhook.ts           # Subscription webhooks
├── worker/             # Cloudflare Worker
│   ├── src/index.ts   # Hourly cron: price updates + alert checking
│   └── *.sql          # Database migrations
└── scripts/           # Utilities
    ├── seed-*.ts      # Database seeding
    ├── test-*-alert.ts     # Alert testing scripts
    └── check-*.ts     # Debugging utilities
```

## Deployment

The app is automatically deployed to Cloudflare Pages via GitHub Actions on every push to `main`.

**Production URL:** https://gevault.com

See [DEPLOYMENT.md](../.github/DEPLOYMENT.md) for detailed deployment instructions.

## Documentation

- [DEPLOYMENT.md](../.github/DEPLOYMENT.md) - Deployment guide
- [STRIPE_SETUP.md](STRIPE_SETUP.md) - Stripe integration setup
- [STATUS.md](STATUS.md) - Project status and roadmap
- [worker/README.md](worker/README.md) - Cloudflare Worker documentation

## License

MIT
