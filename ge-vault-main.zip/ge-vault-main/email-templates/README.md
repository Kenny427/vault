# GE Vault Email Templates

## Supabase Auth Templates

These templates go in your Supabase Dashboard under **Authentication → Email Templates**.

### How to use:

1. Go to [Supabase Dashboard](https://supabase.com/dashboard)
2. Select your project
3. Navigate to **Authentication → Email Templates**
4. For each email type, paste the corresponding HTML template

### Template files:

| Template | Supabase Email Type | File |
|----------|---------------------|------|
| Signup confirmation | Confirm signup | `confirm-signup.html` |
| Password reset | Reset password | `reset-password.html` |
| Magic link login | Magic Link | `magic-link.html` |
| Email change | Change Email Address | `change-email.html` |

### Supabase variables:

These templates use Supabase's template variables:
- `{{ .ConfirmationURL }}` - The confirmation/action link
- `{{ .Email }}` - The user's email address
- `{{ .Token }}` - The confirmation token (if needed separately)

---

## Price Alert Template

The `price-alert.html` template is for implementing email notifications for price alerts.

### Variables to replace:

| Variable | Description | Example |
|----------|-------------|---------|
| `{{item_name}}` | Name of the item | `Bandos chestplate` |
| `{{current_price}}` | Current GE price | `14,523,456` |
| `{{target_price}}` | User's target price | `14,000,000` |
| `{{alert_message}}` | Description of the alert | `Price dropped below your target of 14M` |
| `{{alerts_url}}` | Link to alerts page | `https://gevault.com/alerts` |
| `{{unsubscribe_url}}` | Manage preferences link | `https://gevault.com/settings` |

### Implementation notes:

To add email notifications to the alert system, you'll need to:

1. Add an email notification option to the alert creation form
2. Store user email preferences in the database
3. Use Resend's API to send emails when alerts trigger
4. The worker at `packages/worker/src/index.ts` already handles alert checking - add email sending alongside Discord notifications

Example Resend integration:
```typescript
import { Resend } from 'resend';

const resend = new Resend(env.RESEND_API_KEY);

await resend.emails.send({
  from: 'GE Vault <noreply@gevault.com>',
  to: user.email,
  subject: `Price Alert: ${alert.item_name}`,
  html: compiledTemplate
});
```

---

## Brand Colors

- Primary Gold: `#d4a843`
- Background: `#0a0a0a`
- Card Background: `#1a1a1a`
- Border: `#2a2a2a`
- Text Primary: `#ffffff`
- Text Secondary: `#b3b3b3`
- Text Muted: `#808080`
- Success: `#22c55e`
