// api/test.ts
var onRequestGet = async () => {
  console.log("TEST: Function was called");
  return new Response(JSON.stringify({
    message: "Test endpoint working!",
    timestamp: (/* @__PURE__ */ new Date()).toISOString()
  }), {
    status: 200,
    headers: { "Content-Type": "application/json" }
  });
};
export {
  onRequestGet
};
