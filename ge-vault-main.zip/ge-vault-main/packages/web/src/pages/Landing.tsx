import { Link } from 'react-router-dom'

export function Landing() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-ge-blue to-gray-900 text-white">
      <div className="max-w-6xl mx-auto px-4 sm:px-8 py-8 sm:py-16">
        {/* Header */}
        <nav className="flex justify-between items-center mb-12 sm:mb-20">
          <h1 className="text-xl sm:text-2xl font-bold text-ge-gold">GE Vault</h1>
          <Link
            to="/auth"
            className="px-4 py-2 bg-white text-ge-blue rounded-lg font-semibold hover:bg-gray-100 transition text-sm sm:text-base"
          >
            Sign In
          </Link>
        </nav>

        {/* Hero Section */}
        <div className="text-center max-w-4xl mx-auto">
          <h2 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold mb-6 leading-tight">
            Track Your OSRS Investments
          </h2>
          <p className="text-lg sm:text-xl md:text-2xl text-gray-300 mb-8 sm:mb-12 px-4">
            Stop manually checking prices on your long-term holds.
            <br className="hidden sm:block" />
            <span className="sm:hidden"> </span>
            Track your Grand Exchange portfolio like a real investment.
          </p>

          <Link
            to="/auth"
            className="inline-block w-full sm:w-auto px-6 sm:px-8 py-3 sm:py-4 bg-ge-gold text-ge-blue text-base sm:text-lg font-bold rounded-lg hover:bg-yellow-400 transition transform hover:scale-105"
          >
            Get Started - It's Free
          </Link>

          {/* Features Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 sm:gap-8 mt-12 sm:mt-20">
            <div className="bg-white/10 backdrop-blur rounded-lg p-4 sm:p-6">
              <div className="text-3xl sm:text-4xl mb-4">📊</div>
              <h3 className="text-lg sm:text-xl font-bold mb-2">Real-Time Prices</h3>
              <p className="text-gray-300 text-sm sm:text-base">
                Automatic daily price updates from OSRS Wiki API
              </p>
            </div>

            <div className="bg-white/10 backdrop-blur rounded-lg p-4 sm:p-6">
              <div className="text-3xl sm:text-4xl mb-4">💰</div>
              <h3 className="text-lg sm:text-xl font-bold mb-2">Profit Tracking</h3>
              <p className="text-gray-300 text-sm sm:text-base">
                See your total gains and losses at a glance
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
