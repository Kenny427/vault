// app/src/pages/Alerts.tsx
import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import type { UserAlert } from '@ge-vault/shared';
import { supabase } from '../lib/supabase';
import DiscordConnect from '../components/alerts/DiscordConnect';
import AlertForm from '../components/alerts/AlertForm';
import AlertCard from '../components/alerts/AlertCard';
import AlertHistory from '../components/alerts/AlertHistory';
import ErrorBoundary from '../components/ErrorBoundary';

const AlertsPageContent: React.FC = () => {
  const navigate = useNavigate();
  const [alerts, setAlerts] = useState<UserAlert[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editingAlert, setEditingAlert] = useState<UserAlert | null>(null);
  const [userId, setUserId] = useState<string | null>(null);
  const [itemPrices, setItemPrices] = useState<Record<string, number>>({});
  const [priceTimestamps, setPriceTimestamps] = useState<Record<string, string>>({});

  useEffect(() => {
    const fetchUser = async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (user) {
        setUserId(user.id);
      }
    };

    const fetchAlerts = async () => {
      const { data, error } = await supabase.from('user_alerts').select('*');
      if (error) {
        console.error('Error fetching alerts:', error);
        setLoading(false);
        return;
      }

      setAlerts(data || []);

      // Fetch current prices for all alert items
      if (data && data.length > 0) {
        const itemIds = [...new Set(data.map(alert => alert.item_id))];
        const { data: priceData } = await supabase
          .from('item_prices_current')
          .select('item_id, high_price, updated_at')
          .in('item_id', itemIds);

        if (priceData) {
          const priceMap: Record<string, number> = {};
          const timestampMap: Record<string, string> = {};
          priceData.forEach(item => {
            if (item.high_price) {
              priceMap[item.item_id] = item.high_price;
              timestampMap[item.item_id] = item.updated_at;
            }
          });
          setItemPrices(priceMap);
          setPriceTimestamps(timestampMap);
        }
      }

      setLoading(false);
    };

    fetchUser();
    fetchAlerts();
  }, []);

  const handleSaveAlert = (savedAlert: UserAlert) => {
    if (editingAlert) {
      // Update existing alert
      setAlerts(alerts.map(a => a.id === savedAlert.id ? savedAlert : a));
      setEditingAlert(null);
    } else {
      // Add new alert
      setAlerts([savedAlert, ...alerts]);
    }
    setShowForm(false);
  };

  const handleEdit = (alert: UserAlert) => {
    setEditingAlert(alert);
    setShowForm(true);
  };

  const handleCancelForm = () => {
    setShowForm(false);
    setEditingAlert(null);
  };

  const handleDelete = (id: number) => {
    setAlerts(alerts.filter(a => a.id !== id));
  };

  const handleUpdate = (updatedAlert: UserAlert) => {
    setAlerts(alerts.map(a => a.id === updatedAlert.id ? updatedAlert : a));
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-100 flex items-center justify-center">
        <div className="text-center">
          <div className="inline-block animate-spin rounded-full h-12 w-12 border-b-2 border-ge-gold"></div>
          <p className="mt-4 text-gray-600">Loading alerts...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-100">
      <nav className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <h1 className="text-lg sm:text-2xl font-bold text-ge-blue">
              <span className="hidden sm:inline">GE Vault - Price Alerts</span>
              <span className="sm:hidden">GE Vault Alerts</span>
            </h1>
            
            {/* Mobile Navigation */}
            <div className="flex items-center gap-2 sm:gap-4">
              <button
                onClick={() => navigate('/dashboard')}
                className="px-3 py-2 sm:px-4 text-gray-700 hover:text-ge-blue transition text-sm sm:text-base"
              >
                <span className="hidden sm:inline">← Dashboard</span>
                <span className="sm:hidden">← Back</span>
              </button>
              <a
                href="https://discord.gg/78c5TebFfK"
                target="_blank"
                rel="noopener noreferrer"
                className="px-3 py-2 sm:px-4 bg-[#5865F2] text-white font-semibold rounded-lg hover:bg-[#4752c4] transition text-sm sm:text-base"
              >
                <span className="hidden sm:inline">💬 Discord</span>
                <span className="sm:hidden">💬</span>
              </a>
            </div>
          </div>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto py-8 px-4 sm:px-6 lg:px-8">
        {/* Discord Connection Card */}
        <div className="mb-6">
          <DiscordConnect />
        </div>

        {/* Create Alert Button */}
        <div className="mb-6">
          <button
            onClick={() => setShowForm(true)}
            className="w-full sm:w-auto px-6 py-3 bg-ge-gold text-white font-bold rounded-lg hover:bg-yellow-600 transition transform hover:scale-105 shadow-md"
          >
            <span className="flex items-center justify-center gap-2">
              <span>➕</span>
              <span>Create New Alert</span>
            </span>
          </button>
        </div>

        {/* Alert Form Modal */}
        {showForm && (
          <AlertForm
            onSave={handleSaveAlert}
            onCancel={handleCancelForm}
            editAlert={editingAlert || undefined}
          />
        )}

        {/* Alerts List */}
        <div className="space-y-4 mb-8">
          {alerts.length === 0 ? (
            <div className="bg-white rounded-lg shadow-md p-8 text-center">
              <div className="text-6xl mb-4">📭</div>
              <p className="text-gray-600 text-lg">No alerts yet. Create one to get started!</p>
            </div>
          ) : (
            alerts.map(alert => (
              <AlertCard
                key={alert.id}
                alert={alert}
                currentPrice={itemPrices[alert.item_id]}
                priceUpdatedAt={priceTimestamps[alert.item_id]}
                onDelete={handleDelete}
                onUpdate={handleUpdate}
                onEdit={handleEdit}
              />
            ))
          )}
        </div>

        {/* Alert History */}
        {userId && <AlertHistory userId={userId} />}
      </div>
    </div>
  );
};

const AlertsPage: React.FC = () => {
  return (
    <ErrorBoundary>
      <AlertsPageContent />
    </ErrorBoundary>
  );
};

export default AlertsPage;
