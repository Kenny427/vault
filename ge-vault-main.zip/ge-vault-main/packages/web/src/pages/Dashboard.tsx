import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { supabase } from '../lib/supabase'
import { AddItemModal } from '../components/AddItemModal'
import { PortfolioList } from '../components/PortfolioList'
import { PortfolioSummary } from '../components/PortfolioSummary'
import { exportPortfolioToCSV, type PortfolioCSVRow } from '../lib/csvExport'
import { calculateProfitAfterTax } from '../lib/geTax'
import type { User } from '@supabase/supabase-js'

export function Dashboard() {
  const navigate = useNavigate()
  const [user, setUser] = useState<User | null>(null)
  const [loading, setLoading] = useState(true)
  const [showAddModal, setShowAddModal] = useState(false)
  const [refreshTrigger, setRefreshTrigger] = useState(0)
  const [refreshingPrices, setRefreshingPrices] = useState(false)
  const [lastPriceUpdate, setLastPriceUpdate] = useState<Date | null>(null)
  const [notification, setNotification] = useState<{ type: 'success' | 'error', message: string } | null>(null)
  const [exportingCSV, setExportingCSV] = useState(false)
  const [showMobileMenu, setShowMobileMenu] = useState(false)

  useEffect(() => {
    supabase.auth.getUser().then(({ data: { user } }) => {
      setUser(user)
      setLoading(false)
    })
  }, [])

  // Fetch last price update time
  useEffect(() => {
    const fetchLastUpdate = async () => {
      const { data } = await supabase
        .from('item_prices_current')
        .select('updated_at')
        .order('updated_at', { ascending: false })
        .limit(1)
        .single()

      if (data?.updated_at) {
        // Supabase returns timestamps without timezone suffix, causing JS to interpret as local time
        // Append 'Z' to force UTC interpretation if not already present
        const timestamp = data.updated_at.endsWith('Z') ? data.updated_at : data.updated_at + 'Z'
        const date = new Date(timestamp)
        setLastPriceUpdate(date)
      }
    }

    fetchLastUpdate()

    // Refetch every 5 minutes to catch automatic updates
    const interval = setInterval(fetchLastUpdate, 5 * 60 * 1000)
    return () => clearInterval(interval)
  }, [refreshTrigger])

  // Force re-render every minute to update "X minutes ago" display
  const [, setTick] = useState(0)
  useEffect(() => {
    const interval = setInterval(() => setTick(t => t + 1), 60000)
    return () => clearInterval(interval)
  }, [])

  // Auto-dismiss notifications after 5 seconds
  useEffect(() => {
    if (notification) {
      const timer = setTimeout(() => setNotification(null), 5000)
      return () => clearTimeout(timer)
    }
  }, [notification])

  const getTimeAgo = (date: Date | null) => {
    if (!date) return 'Unknown'

    const now = new Date()
    const seconds = Math.floor((now.getTime() - date.getTime()) / 1000)
    const minutes = Math.floor(seconds / 60)
    const hours = Math.floor(minutes / 60)

    if (minutes < 1) return 'Just now'
    if (minutes === 1) return '1 minute ago'
    if (minutes < 60) return `${minutes} minutes ago`
    if (hours === 1) return '1 hour ago'
    return `${hours} hours ago`
  }

  const handleLogout = async () => {
    await supabase.auth.signOut()
    navigate('/auth')
  }

  const handleItemAdded = () => {
    setRefreshTrigger(prev => prev + 1)
  }

  const handleRefreshPrices = async () => {
    setRefreshingPrices(true)
    try {
      // Check when prices were last updated
      const { data: lastUpdate, error: lastUpdateError } = await supabase
        .from('item_prices_current')
        .select('updated_at')
        .order('updated_at', { ascending: false })
        .limit(1)
        .single()

      if (lastUpdateError && lastUpdateError.code !== 'PGRST116') {
        // PGRST116 is "no rows returned", which is fine for empty table
        throw lastUpdateError
      }

      if (lastUpdate?.updated_at) {
        // Force UTC interpretation by appending 'Z' if not present
        const timestamp = lastUpdate.updated_at.endsWith('Z') ? lastUpdate.updated_at : lastUpdate.updated_at + 'Z'
        const lastUpdateTime = new Date(timestamp)
        const now = new Date()
        const minutesSinceUpdate = (now.getTime() - lastUpdateTime.getTime()) / (1000 * 60)

        const COOLDOWN_MINUTES = 10

        if (minutesSinceUpdate < COOLDOWN_MINUTES) {
          const remainingMinutes = Math.ceil(COOLDOWN_MINUTES - minutesSinceUpdate)
          alert(`Prices were updated ${Math.floor(minutesSinceUpdate)} minutes ago. Please wait ${remainingMinutes} more minute(s) before refreshing again.`)
          setRefreshingPrices(false)
          return
        }
      }

      // Get all valid item IDs from our database
      const { data: itemsData, error: itemsError } = await supabase
        .from('items')
        .select('id')

      if (itemsError) throw itemsError

      const validItemIds = new Set(itemsData?.map(item => item.id) || [])

      if (validItemIds.size === 0) {
        alert('No items found in database')
        return
      }

      // Fetch latest prices from OSRS Wiki API
      const response = await fetch('https://prices.runescape.wiki/api/v1/osrs/latest', {
        headers: {
          'User-Agent': 'GE Vault - OSRS Portfolio Tracker (gevault.com, discord: Mreedon, admin@gevault.com)'
        }
      })

      if (!response.ok) {
        throw new Error('Failed to fetch prices from OSRS Wiki')
      }

      const priceData = await response.json()
      const prices = priceData.data

      // Prepare updates for ALL items in our database that have prices
      const priceUpdates = Object.entries(prices)
        .filter(([itemId, priceInfo]: [string, any]) => {
          const id = parseInt(itemId)
          return validItemIds.has(id) && (priceInfo.high !== null || priceInfo.low !== null)
        })
        .map(([itemId, priceInfo]: [string, any]) => ({
          item_id: parseInt(itemId),
          high_price: priceInfo.high,
          low_price: priceInfo.low,
          updated_at: new Date().toISOString()
        }))

      if (priceUpdates.length === 0) {
        alert('No price updates available')
        return
      }

      // Update prices in database using the PostgreSQL function
      const { data: updateCount, error: updateError } = await supabase
        .rpc('refresh_item_prices', { price_updates: priceUpdates })

      if (updateError) throw updateError

      // Check alerts after price update
      const { data: { session } } = await supabase.auth.getSession()
      if (session) {
        try {
          const alertResponse = await fetch('/api/alerts/check', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${session.access_token}`
            }
          })
          if (alertResponse.ok) {
            const alertResult = await alertResponse.json()
            if (alertResult.triggered > 0) {
              console.log(`Triggered ${alertResult.triggered} price alerts`)
            }
          }
        } catch (alertError) {
          console.error('Failed to check alerts:', alertError)
        }
      }

      // Trigger portfolio refresh to show new prices
      setRefreshTrigger(prev => prev + 1)
      setLastPriceUpdate(new Date())

      const count = updateCount || priceUpdates.length
      alert(`Successfully refreshed prices for ${count.toLocaleString()} items!`)
    } catch (error: any) {
      console.error('Error refreshing prices:', error)
      alert('Failed to refresh prices: ' + error.message)
    } finally {
      setRefreshingPrices(false)
    }
  }

  const handleExportCSV = async () => {
    setExportingCSV(true)
    try {
      const { data: { user } } = await supabase.auth.getUser()
      if (!user) {
        throw new Error('Not authenticated')
      }

      // Fetch portfolio items with item details
      const { data: portfolioData, error: fetchError } = await supabase
        .from('portfolio_items')
        .select(`
          id,
          item_id,
          quantity,
          buy_price,
          items (
            name
          )
        `)
        .eq('user_id', user.id)
        .order('created_at', { ascending: false })

      if (fetchError) throw fetchError

      if (!portfolioData || portfolioData.length === 0) {
        setNotification({
          type: 'error',
          message: 'No items in portfolio to export'
        })
        setExportingCSV(false)
        return
      }

      // Get unique item IDs to fetch prices
      const itemIds = portfolioData.map((item: any) => item.item_id)
      const uniqueItemIds = [...new Set(itemIds)]

      // Fetch current prices for these items
      const { data: pricesData } = await supabase
        .from('item_prices_current')
        .select('item_id, high_price')
        .in('item_id', uniqueItemIds)

      // Create a map of prices by item_id
      const pricesMap = new Map(
        pricesData?.map((p: any) => [p.item_id, p.high_price]) || []
      )

      // Group items by item_id and calculate weighted averages
      interface GroupedItem {
        item_id: number
        item_name: string
        total_quantity: number
        weighted_avg_price: number
        lots: Array<{ quantity: number; buy_price: number }>
      }

      const grouped = portfolioData.reduce((acc: GroupedItem[], item: any) => {
        const existing = acc.find((g: GroupedItem) => g.item_id === item.item_id)

        if (existing) {
          existing.lots.push({ quantity: item.quantity, buy_price: item.buy_price })
          existing.total_quantity += item.quantity
          // Recalculate weighted average
          const totalCost = existing.lots.reduce((sum, lot) => sum + (lot.buy_price * lot.quantity), 0)
          const totalQty = existing.lots.reduce((sum, lot) => sum + lot.quantity, 0)
          existing.weighted_avg_price = totalCost / totalQty
        } else {
          acc.push({
            item_id: item.item_id,
            item_name: item.items.name,
            total_quantity: item.quantity,
            weighted_avg_price: item.buy_price,
            lots: [{ quantity: item.quantity, buy_price: item.buy_price }]
          })
        }

        return acc
      }, [])

      // Transform to CSV format
      const csvData: PortfolioCSVRow[] = grouped.map((group: GroupedItem) => {
        const currentPrice = pricesMap.get(group.item_id) || 0

        if (currentPrice === 0) {
          // No price available, use buy price as estimate
          return {
            itemName: group.item_name,
            quantity: group.total_quantity,
            avgPurchasePrice: group.weighted_avg_price,
            currentPrice: group.weighted_avg_price,
            totalCost: group.weighted_avg_price * group.total_quantity,
            currentValue: group.weighted_avg_price * group.total_quantity,
            geTax: 0,
            profitLossBeforeTax: 0,
            netProfitLoss: 0,
            taxExempt: false
          }
        }

        const profitCalc = calculateProfitAfterTax(
          group.weighted_avg_price,
          currentPrice,
          group.total_quantity,
          group.item_id
        )

        return {
          itemName: group.item_name,
          quantity: group.total_quantity,
          avgPurchasePrice: group.weighted_avg_price,
          currentPrice: currentPrice,
          totalCost: profitCalc.totalCost,
          currentValue: profitCalc.grossValue,
          geTax: profitCalc.tax,
          profitLossBeforeTax: profitCalc.grossValue - profitCalc.totalCost,
          netProfitLoss: profitCalc.profit,
          taxExempt: profitCalc.isTaxExempt
        }
      })

      // Export to CSV
      exportPortfolioToCSV(csvData)

      setNotification({
        type: 'success',
        message: 'Portfolio exported successfully!'
      })
    } catch (error: any) {
      console.error('Error exporting CSV:', error)
      setNotification({
        type: 'error',
        message: 'Failed to export portfolio: ' + error.message
      })
    } finally {
      setExportingCSV(false)
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-100 flex items-center justify-center">
        <div className="text-center">
          <div className="inline-block animate-spin rounded-full h-12 w-12 border-b-2 border-ge-gold"></div>
          <p className="mt-4 text-gray-600">Loading dashboard...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Header */}
      <nav className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <h1 className="text-2xl font-bold text-ge-blue">GE Vault</h1>
            
            {/* Mobile Menu Button */}
            <div className="md:hidden">
              <button
                onClick={() => setShowMobileMenu(!showMobileMenu)}
                className="p-2 rounded-md text-gray-600 hover:text-gray-900 hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-ge-blue focus:ring-inset"
              >
                <span className="sr-only">Open main menu</span>
                <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  {showMobileMenu ? (
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                  ) : (
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
                  )}
                </svg>
              </button>
            </div>

            {/* Desktop Navigation */}
            <div className="hidden md:flex items-center gap-4">
              <button
                onClick={() => navigate('/alerts')}
                className="px-4 py-2 bg-ge-blue text-white font-semibold rounded-lg hover:bg-blue-700 transition"
              >
                🔔 Alerts
              </button>
              <a
                href="https://discord.gg/78c5TebFfK"
                target="_blank"
                rel="noopener noreferrer"
                className="px-4 py-2 bg-[#5865F2] text-white font-semibold rounded-lg hover:bg-[#4752c4] transition"
              >
                💬 Discord
              </a>
              <a
                href="https://ko-fi.com/mreedon"
                target="_blank"
                rel="noopener noreferrer"
                className="px-4 py-2 bg-[#FF5E5B] text-white font-semibold rounded-lg hover:bg-[#e54543] transition"
              >
                ☕ Support
              </a>
              <button
                onClick={() => navigate('/account')}
                className="px-4 py-2 bg-gray-100 text-gray-700 font-semibold rounded-lg hover:bg-gray-200 transition"
              >
                ⚙️ Account
              </button>
              <span className="text-gray-600 hidden lg:inline">{user?.email}</span>
              <button
                onClick={handleLogout}
                className="px-4 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 transition"
              >
                Logout
              </button>
            </div>
          </div>

          {/* Mobile Navigation Menu */}
          {showMobileMenu && (
            <div className="md:hidden border-t border-gray-200 py-4">
              <div className="flex flex-col space-y-3">
                <button
                  onClick={() => {
                    navigate('/alerts')
                    setShowMobileMenu(false)
                  }}
                  className="flex items-center justify-center w-full px-4 py-3 bg-ge-blue text-white font-semibold rounded-lg hover:bg-blue-700 transition"
                >
                  🔔 Alerts
                </button>
                <a
                  href="https://discord.gg/78c5TebFfK"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center justify-center w-full px-4 py-3 bg-[#5865F2] text-white font-semibold rounded-lg hover:bg-[#4752c4] transition"
                  onClick={() => setShowMobileMenu(false)}
                >
                  💬 Discord
                </a>
                <a
                  href="https://ko-fi.com/mreedon"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center justify-center w-full px-4 py-3 bg-[#FF5E5B] text-white font-semibold rounded-lg hover:bg-[#e54543] transition"
                  onClick={() => setShowMobileMenu(false)}
                >
                  ☕ Support
                </a>
                <button
                  onClick={() => {
                    navigate('/account')
                    setShowMobileMenu(false)
                  }}
                  className="flex items-center justify-center w-full px-4 py-3 bg-gray-100 text-gray-700 font-semibold rounded-lg hover:bg-gray-200 transition"
                >
                  ⚙️ Account
                </button>
                <div className="px-4 py-2 text-center text-gray-600 text-sm">{user?.email}</div>
                <button
                  onClick={() => {
                    handleLogout()
                    setShowMobileMenu(false)
                  }}
                  className="flex items-center justify-center w-full px-4 py-3 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 transition"
                >
                  Logout
                </button>
              </div>
            </div>
          )}
        </div>
      </nav>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Page Header */}
        <div className="mb-8">
          <div className="flex flex-col sm:flex-row sm:justify-between sm:items-start gap-4">
            <div>
              <h2 className="text-2xl sm:text-3xl font-bold text-gray-900">My Portfolio</h2>
              <p className="text-gray-600 mt-1">Track your OSRS investments</p>
              <p className="text-sm text-gray-500 mt-1">
                Prices last updated: <span className="font-medium text-gray-600">{getTimeAgo(lastPriceUpdate)}</span>
              </p>
              <p className="text-xs text-gray-400 mt-1">
                Auto-refreshes every 30 min • Manual refresh available after 10 min
              </p>
            </div>
            
            {/* Action Buttons */}
            <div className="flex flex-col sm:flex-row gap-3 w-full sm:w-auto">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 sm:flex sm:gap-3">
                <button
                  onClick={handleExportCSV}
                  disabled={exportingCSV}
                  title="Export portfolio to CSV"
                  className="w-full sm:w-auto px-4 sm:px-6 py-3 font-bold rounded-lg transition transform hover:scale-105 shadow-md disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none bg-purple-600 text-white hover:bg-purple-700"
                >
                  {exportingCSV ? (
                    <span className="flex items-center justify-center gap-2">
                      <span className="inline-block animate-spin rounded-full h-4 w-4 border-b-2 border-white"></span>
                      <span className="hidden sm:inline">Exporting...</span>
                      <span className="sm:hidden">Export...</span>
                    </span>
                  ) : (
                    <span className="flex items-center justify-center gap-2">
                      <span>📥</span>
                      <span className="hidden sm:inline">Export CSV</span>
                      <span className="sm:hidden">Export</span>
                    </span>
                  )}
                </button>
                <button
                  onClick={handleRefreshPrices}
                  disabled={refreshingPrices}
                  title="Refresh all item prices from OSRS Wiki"
                  className="w-full sm:w-auto px-4 sm:px-6 py-3 font-bold rounded-lg transition transform hover:scale-105 shadow-md disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none bg-ge-blue text-white hover:bg-blue-700"
                >
                  {refreshingPrices ? (
                    <span className="flex items-center justify-center gap-2">
                      <span className="inline-block animate-spin rounded-full h-4 w-4 border-b-2 border-white"></span>
                      <span className="hidden sm:inline">Refreshing...</span>
                      <span className="sm:hidden">Refresh...</span>
                    </span>
                  ) : (
                    <span className="flex items-center justify-center gap-2">
                      <span>🔄</span>
                      <span className="hidden sm:inline">Refresh Prices</span>
                      <span className="sm:hidden">Refresh</span>
                    </span>
                  )}
                </button>
                <button
                  onClick={() => setShowAddModal(true)}
                  className="w-full sm:w-auto px-4 sm:px-6 py-3 bg-ge-gold text-ge-blue font-bold rounded-lg hover:bg-yellow-400 transition transform hover:scale-105 shadow-md"
                >
                  <span className="flex items-center justify-center gap-2">
                    <span>+</span>
                    <span>Add Item</span>
                  </span>
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Portfolio Summary */}
        <PortfolioSummary refreshTrigger={refreshTrigger} />

        {/* Portfolio List */}
        <PortfolioList
          refreshTrigger={refreshTrigger}
          onDelete={handleItemAdded}
        />
      </div>

      {/* Add Item Modal */}
      <AddItemModal
        isOpen={showAddModal}
        onClose={() => setShowAddModal(false)}
        onSuccess={handleItemAdded}
      />

      {/* Notification Toast */}
      {notification && (
        <div className="fixed bottom-4 right-4 z-50 animate-fade-in">
          <div className={`px-6 py-4 rounded-lg shadow-lg flex items-center gap-3 ${
            notification.type === 'success'
              ? 'bg-green-500 text-white'
              : 'bg-red-500 text-white'
          }`}>
            <span className="text-xl">
              {notification.type === 'success' ? '✓' : '✕'}
            </span>
            <span className="font-medium">{notification.message}</span>
            <button
              onClick={() => setNotification(null)}
              className="ml-4 text-white hover:text-gray-200 transition"
            >
              ✕
            </button>
          </div>
        </div>
      )}
    </div>
  )
}
