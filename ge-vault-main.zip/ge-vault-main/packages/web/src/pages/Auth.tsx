import { useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { Auth as SupabaseAuth } from '@supabase/auth-ui-react'
import { ThemeSupa } from '@supabase/auth-ui-shared'
import { supabase } from '../lib/supabase'

export function Auth() {
  const navigate = useNavigate()

  useEffect(() => {
    // Check if user is already logged in
    supabase.auth.getSession().then(({ data: { session } }) => {
      if (session) {
        navigate('/dashboard')
      }
    })

    // Listen for auth changes
    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((_event, session) => {
      if (session) {
        navigate('/dashboard')
      }
    })

    return () => subscription.unsubscribe()
  }, [navigate])

  return (
    <div className="min-h-screen bg-gradient-to-br from-ge-blue to-gray-900 flex items-center justify-center px-4">
      <div className="w-full max-w-md">
        <div className="bg-white rounded-lg shadow-xl p-8">
          <h1 className="text-3xl font-bold text-ge-blue text-center mb-2">
            GE Vault
          </h1>
          <p className="text-gray-600 text-center mb-8">
            Sign in to track your OSRS portfolio
          </p>

          <SupabaseAuth
            supabaseClient={supabase}
            appearance={{
              theme: ThemeSupa,
              variables: {
                default: {
                  colors: {
                    brand: '#D4AF37',
                    brandAccent: '#B8941F',
                  },
                },
              },
            }}
            providers={[]}
            redirectTo={window.location.origin + '/dashboard'}
          />
        </div>

        <p className="text-center text-gray-400 mt-6">
          <a href="/" className="hover:text-white transition">
            ← Back to home
          </a>
        </p>
      </div>
    </div>
  )
}
