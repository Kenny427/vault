import { useEffect, useState } from 'react'
import { supabase } from '../lib/supabase'

export function ItemsTableCheck() {
  const [status, setStatus] = useState<'checking' | 'seeded' | 'empty' | 'error'>('checking')
  const [itemCount, setItemCount] = useState(0)
  const [sampleItems, setSampleItems] = useState<any[]>([])

  useEffect(() => {
    async function checkItems() {
      try {
        // Count total items
        const { count, error: countError } = await supabase
          .from('items')
          .select('*', { count: 'exact', head: true })

        if (countError) throw countError

        // Get a few sample items
        const { data: items, error: itemsError } = await supabase
          .from('items')
          .select('id, name, icon_url')
          .limit(5)

        if (itemsError) throw itemsError

        setItemCount(count || 0)
        setSampleItems(items || [])
        setStatus(count && count > 0 ? 'seeded' : 'empty')
      } catch (error: any) {
        setStatus('error')
        console.error('Error checking items:', error)
      }
    }

    checkItems()
  }, [])

  return (
    <div className="mt-6">
      <h2 className="text-2xl font-bold mb-4">Items Table Status</h2>

      {status === 'checking' && (
        <div className="p-4 bg-yellow-100 text-yellow-800 rounded">
          <p>⏳ Checking items table...</p>
        </div>
      )}

      {status === 'empty' && (
        <div className="p-4 bg-orange-100 text-orange-800 rounded">
          <p className="font-semibold">⚠️ Items table is empty</p>
          <p className="mt-2">You need to seed the items table with OSRS Wiki data.</p>
        </div>
      )}

      {status === 'seeded' && (
        <div className="p-4 bg-green-100 text-green-800 rounded">
          <p className="font-semibold">✅ Items table has {itemCount.toLocaleString()} items</p>
          {sampleItems.length > 0 && (
            <div className="mt-4">
              <p className="font-medium mb-2">Sample items:</p>
              <ul className="space-y-1">
                {sampleItems.map(item => (
                  <li key={item.id} className="flex items-center gap-2">
                    {item.icon_url && (
                      <img src={item.icon_url} alt={item.name} className="w-8 h-8" />
                    )}
                    <span>{item.name} (ID: {item.id})</span>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>
      )}

      {status === 'error' && (
        <div className="p-4 bg-red-100 text-red-800 rounded">
          <p className="font-semibold">❌ Error checking items table</p>
          <p className="mt-2">Check the browser console for details.</p>
        </div>
      )}
    </div>
  )
}
