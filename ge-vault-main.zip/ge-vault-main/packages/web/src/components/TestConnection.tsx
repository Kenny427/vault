import { useEffect, useState } from 'react'
import { supabase } from '../lib/supabase'

export function TestConnection() {
  const [status, setStatus] = useState<'testing' | 'success' | 'error'>('testing')
  const [message, setMessage] = useState('Testing connection...')

  useEffect(() => {
    async function testConnection() {
      try {
        // Try to query the items table (it might not exist yet)
        const { error } = await supabase.from('items').select('count')

        if (error) {
          // If table doesn't exist, that's ok - connection still works
          if (error.message.includes('relation "public.items" does not exist')) {
            setStatus('success')
            setMessage('✅ Connected to Supabase! (Database schema not created yet)')
          } else {
            throw error
          }
        } else {
          setStatus('success')
          setMessage('✅ Connected to Supabase! Database is ready.')
        }
      } catch (error: any) {
        setStatus('error')
        setMessage(`❌ Connection failed: ${error.message}`)
      }
    }

    testConnection()
  }, [])

  return (
    <div className={`p-4 rounded ${
      status === 'success' ? 'bg-green-100 text-green-800' :
      status === 'error' ? 'bg-red-100 text-red-800' :
      'bg-yellow-100 text-yellow-800'
    }`}>
      <p className="font-semibold">{message}</p>
    </div>
  )
}
