import { describe, it, expect, vi, beforeEach } from 'vitest'
import { render, screen, waitFor } from '@testing-library/react'
import { PortfolioSummary } from '../PortfolioSummary'
import * as supabaseModule from '../../lib/supabase'

// Mock Supabase
vi.mock('../../lib/supabase', () => ({
  supabase: {
    auth: {
      getUser: vi.fn()
    },
    from: vi.fn()
  }
}))

describe('PortfolioSummary', () => {
  beforeEach(() => {
    vi.clearAllMocks()
  })

  it('should render loading state initially', () => {
    // Mock auth to return a user
    vi.spyOn(supabaseModule.supabase.auth, 'getUser').mockResolvedValue({
      data: { user: { id: 'user-123' } as any },
      error: null
    })

    render(<PortfolioSummary refreshTrigger={0} />)

    // Loading state should be visible (skeleton)
    expect(document.querySelector('.animate-pulse')).toBeInTheDocument()
  })

  it('should render null when no stats are available', async () => {
    // Mock auth to return a user
    vi.spyOn(supabaseModule.supabase.auth, 'getUser').mockResolvedValue({
      data: { user: { id: 'user-123' } as any },
      error: null
    })

    // Mock empty portfolio
    vi.spyOn(supabaseModule.supabase, 'from').mockReturnValue({
      select: vi.fn().mockReturnValue({
        eq: vi.fn().mockResolvedValue({
          data: [],
          error: null
        })
      })
    } as any)

    const { container } = render(<PortfolioSummary refreshTrigger={0} />)

    await waitFor(() => {
      expect(container.firstChild).toBeNull()
    })
  })

  it('should display portfolio summary with profit', async () => {
    // Mock auth to return a user
    vi.spyOn(supabaseModule.supabase.auth, 'getUser').mockResolvedValue({
      data: { user: { id: 'user-123' } as any },
      error: null
    })

    // Mock portfolio data
    const mockPortfolioData = [
      { item_id: 1, quantity: 100, buy_price: 1000 }
    ]

    const mockPricesData = [
      { item_id: 1, high_price: 1500 }
    ]

    let callCount = 0
    vi.spyOn(supabaseModule.supabase, 'from').mockImplementation((table: string) => {
      if (table === 'portfolio_items') {
        return {
          select: vi.fn().mockReturnValue({
            eq: vi.fn().mockResolvedValue({
              data: mockPortfolioData,
              error: null
            })
          })
        } as any
      } else if (table === 'item_prices_current') {
        return {
          select: vi.fn().mockReturnValue({
            in: vi.fn().mockResolvedValue({
              data: mockPricesData,
              error: null
            })
          })
        } as any
      }
      return {} as any
    })

    render(<PortfolioSummary refreshTrigger={0} />)

    await waitFor(() => {
      expect(screen.getByText('Portfolio Summary')).toBeInTheDocument()
    })

    // Check for profit indicators
    expect(screen.getByText(/Total Invested/i)).toBeInTheDocument()
    expect(screen.getByText(/Current Value/i)).toBeInTheDocument()
    expect(screen.getByText(/Total Profit\/Loss/i)).toBeInTheDocument()
  })

  it('should display total invested amount', async () => {
    // Mock auth
    vi.spyOn(supabaseModule.supabase.auth, 'getUser').mockResolvedValue({
      data: { user: { id: 'user-123' } as any },
      error: null
    })

    // Mock data with known values
    const mockPortfolioData = [
      { item_id: 1, quantity: 100, buy_price: 1000 } // 100,000 GP invested
    ]

    const mockPricesData = [
      { item_id: 1, high_price: 1000 } // Same price (no profit/loss)
    ]

    vi.spyOn(supabaseModule.supabase, 'from').mockImplementation((table: string) => {
      if (table === 'portfolio_items') {
        return {
          select: vi.fn().mockReturnValue({
            eq: vi.fn().mockResolvedValue({
              data: mockPortfolioData,
              error: null
            })
          })
        } as any
      } else if (table === 'item_prices_current') {
        return {
          select: vi.fn().mockReturnValue({
            in: vi.fn().mockResolvedValue({
              data: mockPricesData,
              error: null
            })
          })
        } as any
      }
      return {} as any
    })

    render(<PortfolioSummary refreshTrigger={0} />)

    await waitFor(() => {
      expect(screen.getByText('100,000')).toBeInTheDocument()
    })
  })

  it('should show tax information when applicable', async () => {
    // Mock auth
    vi.spyOn(supabaseModule.supabase.auth, 'getUser').mockResolvedValue({
      data: { user: { id: 'user-123' } as any },
      error: null
    })

    // Mock data with profit
    const mockPortfolioData = [
      { item_id: 1, quantity: 1, buy_price: 1000000 } // 1M invested
    ]

    const mockPricesData = [
      { item_id: 1, high_price: 2000000 } // 2M current (1M profit, should have tax)
    ]

    vi.spyOn(supabaseModule.supabase, 'from').mockImplementation((table: string) => {
      if (table === 'portfolio_items') {
        return {
          select: vi.fn().mockReturnValue({
            eq: vi.fn().mockResolvedValue({
              data: mockPortfolioData,
              error: null
            })
          })
        } as any
      } else if (table === 'item_prices_current') {
        return {
          select: vi.fn().mockReturnValue({
            in: vi.fn().mockResolvedValue({
              data: mockPricesData,
              error: null
            })
          })
        } as any
      }
      return {} as any
    })

    render(<PortfolioSummary refreshTrigger={0} />)

    await waitFor(() => {
      expect(screen.getByText(/Est. GE Tax/i)).toBeInTheDocument()
    })
  })

  it('should re-fetch stats when refreshTrigger changes', async () => {
    const getUserSpy = vi.spyOn(supabaseModule.supabase.auth, 'getUser').mockResolvedValue({
      data: { user: { id: 'user-123' } as any },
      error: null
    })

    vi.spyOn(supabaseModule.supabase, 'from').mockReturnValue({
      select: vi.fn().mockReturnValue({
        eq: vi.fn().mockResolvedValue({ data: [], error: null })
      })
    } as any)

    const { rerender } = render(<PortfolioSummary refreshTrigger={0} />)

    await waitFor(() => {
      expect(getUserSpy).toHaveBeenCalledTimes(1)
    })

    // Change refresh trigger
    rerender(<PortfolioSummary refreshTrigger={1} />)

    await waitFor(() => {
      expect(getUserSpy).toHaveBeenCalledTimes(2)
    })
  })
})
