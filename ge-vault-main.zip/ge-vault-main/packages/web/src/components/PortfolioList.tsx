import { useState, useEffect } from 'react'
import { supabase } from '../lib/supabase'
import { calculateProfitAfterTax } from '../lib/geTax'

interface PortfolioItem {
  id: number
  item_id: number
  quantity: number
  buy_price: number
  date_purchased: string
  notes: string | null
  item_name: string
  item_icon: string | null
  current_price: number | null
  price_updated_at: string | null
}

interface GroupedPortfolioItem {
  item_id: number
  item_name: string
  item_icon: string | null
  total_quantity: number
  weighted_avg_price: number
  current_price: number | null
  price_updated_at: string | null
  lots: PortfolioItem[]
}

interface PortfolioListProps {
  refreshTrigger: number
  onDelete: () => void
}

export function PortfolioList({ refreshTrigger, onDelete }: PortfolioListProps) {
  const [groupedItems, setGroupedItems] = useState<GroupedPortfolioItem[]>([])
  const [expandedItems, setExpandedItems] = useState<Set<number>>(new Set())
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')

  useEffect(() => {
    fetchPortfolio()
  }, [refreshTrigger])

  const fetchPortfolio = async () => {
    setLoading(true)
    setError('')

    try {
      const { data: { user } } = await supabase.auth.getUser()
      if (!user) return

      // Fetch portfolio items with item details
      const { data: portfolioData, error: fetchError } = await supabase
        .from('portfolio_items')
        .select(`
          id,
          item_id,
          quantity,
          buy_price,
          date_purchased,
          notes,
          items (
            name,
            icon_url
          )
        `)
        .eq('user_id', user.id)
        .order('created_at', { ascending: false })

      if (fetchError) throw fetchError

      // Get unique item IDs to fetch prices
      const itemIds = portfolioData?.map(item => item.item_id) || []

      // Fetch current prices for these items
      const { data: pricesData } = await supabase
        .from('item_prices_current')
        .select('item_id, high_price, updated_at')
        .in('item_id', itemIds)

      // Create a map of prices by item_id
      const pricesMap = new Map(
        pricesData?.map(p => [p.item_id, { high_price: p.high_price, updated_at: p.updated_at }]) || []
      )

      // Transform the data
      const transformedItems: PortfolioItem[] = (portfolioData || []).map((item: any) => {
        const price = pricesMap.get(item.item_id)
        return {
          id: item.id,
          item_id: item.item_id,
          quantity: item.quantity,
          buy_price: item.buy_price,
          date_purchased: item.date_purchased,
          notes: item.notes,
          item_name: item.items.name,
          item_icon: item.items.icon_url,
          current_price: price?.high_price || null,
          price_updated_at: price?.updated_at || null,
        }
      })

      // Group items by item_id
      const grouped = transformedItems.reduce((acc, item) => {
        const existing = acc.find(g => g.item_id === item.item_id)

        if (existing) {
          existing.lots.push(item)
          existing.total_quantity += item.quantity
          // Recalculate weighted average price
          const totalCost = existing.lots.reduce((sum, lot) => sum + (lot.buy_price * lot.quantity), 0)
          const totalQty = existing.lots.reduce((sum, lot) => sum + lot.quantity, 0)
          existing.weighted_avg_price = totalCost / totalQty
        } else {
          acc.push({
            item_id: item.item_id,
            item_name: item.item_name,
            item_icon: item.item_icon,
            total_quantity: item.quantity,
            weighted_avg_price: item.buy_price,
            current_price: item.current_price,
            price_updated_at: item.price_updated_at,
            lots: [item]
          })
        }

        return acc
      }, [] as GroupedPortfolioItem[])

      setGroupedItems(grouped)
    } catch (err: any) {
      setError(err.message || 'Failed to load portfolio')
    } finally {
      setLoading(false)
    }
  }

  const toggleExpanded = (itemId: number) => {
    setExpandedItems(prev => {
      const newSet = new Set(prev)
      if (newSet.has(itemId)) {
        newSet.delete(itemId)
      } else {
        newSet.add(itemId)
      }
      return newSet
    })
  }

  const handleDelete = async (id: number) => {
    if (!confirm('Are you sure you want to remove this lot from your portfolio?')) {
      return
    }

    try {
      const { error } = await supabase
        .from('portfolio_items')
        .delete()
        .eq('id', id)

      if (error) throw error

      // Refresh the portfolio
      fetchPortfolio()
      onDelete()
    } catch (err: any) {
      alert('Failed to delete item: ' + err.message)
    }
  }

  const handleDeleteAllLots = async (lots: PortfolioItem[]) => {
    const lotCount = lots.length
    if (!confirm(`Are you sure you want to remove all ${lotCount} lot(s) of this item from your portfolio?`)) {
      return
    }

    try {
      const lotIds = lots.map(lot => lot.id)
      const { error } = await supabase
        .from('portfolio_items')
        .delete()
        .in('id', lotIds)

      if (error) throw error

      // Refresh the portfolio
      fetchPortfolio()
      onDelete()
    } catch (err: any) {
      alert('Failed to delete items: ' + err.message)
    }
  }

  const calculateGroupedProfit = (group: GroupedPortfolioItem) => {
    if (!group.current_price) return null

    return calculateProfitAfterTax(
      group.weighted_avg_price,
      group.current_price,
      group.total_quantity,
      group.item_id
    )
  }

  const calculateLotProfit = (lot: PortfolioItem) => {
    if (!lot.current_price) return null

    return calculateProfitAfterTax(
      lot.buy_price,
      lot.current_price,
      lot.quantity,
      lot.item_id
    )
  }

  if (loading) {
    return (
      <div className="text-center py-8">
        <div className="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-ge-gold"></div>
        <p className="mt-2 text-gray-600">Loading portfolio...</p>
      </div>
    )
  }

  if (error) {
    return (
      <div className="p-4 bg-red-50 border border-red-200 rounded-lg text-red-800">
        {error}
      </div>
    )
  }

  if (groupedItems.length === 0) {
    return (
      <div className="text-center py-12">
        <div className="text-6xl mb-4">📦</div>
        <h3 className="text-xl font-bold text-gray-900 mb-2">Your portfolio is empty</h3>
        <p className="text-gray-600 mb-6">Add your first OSRS item to start tracking!</p>
      </div>
    )
  }

  return (
    <div className="space-y-4">
      {groupedItems.map((group) => {
        const stats = calculateGroupedProfit(group)
        const isExpanded = expandedItems.has(group.item_id)
        const hasMultipleLots = group.lots.length > 1

        return (
          <div
            key={group.item_id}
            className="bg-white border border-gray-200 rounded-lg overflow-hidden hover:shadow-md transition"
          >
            {/* Main Grouped View */}
            <div className="p-4">
              <div className="flex flex-col sm:flex-row items-start gap-4">
                {/* Item Icon & Title (Mobile) */}
                <div className="flex items-center gap-3 w-full sm:w-auto">
                  {group.item_icon && (
                    <img
                      src={group.item_icon}
                      alt={group.item_name}
                      className="w-12 h-12 sm:w-16 sm:h-16 flex-shrink-0"
                    />
                  )}
                  <div className="flex-1 sm:hidden">
                    <h3 className="text-lg font-bold text-gray-900 mb-1">
                      {group.item_name}
                    </h3>
                  </div>
                </div>

                {/* Item Details */}
                <div className="flex-1 min-w-0">
                  {/* Desktop Title */}
                  <h3 className="hidden sm:block text-lg font-bold text-gray-900 mb-2">
                    {group.item_name}
                  </h3>
                  
                  {/* Stats Grid */}
                  <div className="grid grid-cols-2 sm:flex sm:flex-wrap gap-2 sm:gap-4 text-sm text-gray-600">
                    <div className="bg-gray-50 rounded-lg p-2 sm:bg-transparent sm:p-0">
                      <div className="font-medium text-xs text-gray-500 uppercase sm:hidden">Quantity</div>
                      <div className="sm:inline">
                        <span className="font-medium hidden sm:inline">Total Quantity:</span> 
                        <span className="font-bold sm:font-normal">{group.total_quantity.toLocaleString()}</span>
                      </div>
                    </div>
                    <div className="bg-gray-50 rounded-lg p-2 sm:bg-transparent sm:p-0">
                      <div className="font-medium text-xs text-gray-500 uppercase sm:hidden">Avg Buy</div>
                      <div className="sm:inline">
                        <span className="font-medium hidden sm:inline">Avg Buy Price:</span> 
                        <span className="font-bold sm:font-normal">{Math.round(group.weighted_avg_price).toLocaleString()} GP</span>
                      </div>
                    </div>
                    {hasMultipleLots && (
                      <div className="bg-gray-50 rounded-lg p-2 sm:bg-transparent sm:p-0 col-span-2 sm:col-span-1">
                        <div className="font-medium text-xs text-gray-500 uppercase sm:hidden">Lots</div>
                        <div className="sm:inline">
                          <span className="font-medium hidden sm:inline">Lots:</span> 
                          <span className="font-bold sm:font-normal">{group.lots.length}</span>
                        </div>
                      </div>
                    )}
                  </div>
                </div>

                {/* Profit/Loss Stats */}
                <div className="w-full sm:w-auto sm:text-right">
                  {stats ? (
                    <div className="bg-gray-50 rounded-lg p-3 sm:bg-transparent sm:p-0">
                      <div className="flex justify-between sm:block mb-2 sm:mb-1">
                        <span className="text-sm text-gray-600 sm:hidden">Current Price:</span>
                        <div className="text-sm text-gray-600 font-medium sm:mb-1">
                          <span className="hidden sm:inline">Current: </span>{group.current_price?.toLocaleString()} GP
                        </div>
                      </div>
                      
                      {stats.tax > 0 && (
                        <div className="flex justify-between sm:block mb-1">
                          <span className="text-xs text-gray-500 sm:hidden">GE Tax:</span>
                          <div className="text-xs text-gray-500">
                            <span className="hidden sm:inline">GE Tax: -</span>
                            <span className="sm:hidden">-</span>{stats.tax.toLocaleString()} GP
                          </div>
                        </div>
                      )}
                      
                      {stats.isTaxExempt && (
                        <div className="text-xs text-blue-600 mb-2 sm:mb-1">
                          ✓ Tax exempt
                        </div>
                      )}
                      
                      <div className="flex justify-between items-center sm:block">
                        <span className="text-sm text-gray-600 sm:hidden">Profit/Loss:</span>
                        <div className="text-right">
                          <div className={`text-xl sm:text-2xl font-bold ${
                            stats.profit >= 0 ? 'text-green-600' : 'text-red-600'
                          }`}>
                            {stats.profit >= 0 ? '+' : ''}{stats.profit.toLocaleString()} GP
                          </div>
                          <div className={`text-sm font-medium ${
                            stats.profitPercentage >= 0 ? 'text-green-600' : 'text-red-600'
                          }`}>
                            {stats.profitPercentage >= 0 ? '+' : ''}{stats.profitPercentage.toFixed(2)}%
                          </div>
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="text-sm text-gray-500 text-center sm:text-right p-3 sm:p-0">Price unavailable</div>
                  )}
                </div>
              </div>

              {/* Action Buttons - Mobile Optimized */}
              <div className="mt-4 flex flex-col sm:flex-row gap-2 sm:gap-3 sm:justify-end">
                {hasMultipleLots ? (
                  <div className="flex gap-2">
                    <button
                      onClick={() => toggleExpanded(group.item_id)}
                      className="flex-1 sm:flex-none px-4 py-2 text-sm text-ge-blue hover:text-ge-gold font-medium bg-blue-50 hover:bg-blue-100 rounded-lg transition sm:bg-transparent sm:hover:bg-blue-50"
                    >
                      {isExpanded ? '▲ Hide lots' : '▼ Show lots'}
                    </button>
                    {!isExpanded && (
                      <button
                        onClick={() => handleDeleteAllLots(group.lots)}
                        className="flex-1 sm:flex-none px-4 py-2 text-sm text-red-600 hover:text-red-800 font-medium bg-red-50 hover:bg-red-100 rounded-lg transition sm:bg-transparent sm:hover:bg-red-50"
                      >
                        Remove All
                      </button>
                    )}
                  </div>
                ) : (
                  <button
                    onClick={() => handleDelete(group.lots[0].id)}
                    className="w-full sm:w-auto px-4 py-2 text-sm text-red-600 hover:text-red-800 font-medium bg-red-50 hover:bg-red-100 rounded-lg transition sm:bg-transparent sm:hover:bg-red-50"
                  >
                    Remove
                  </button>
                )}
              </div>
            </div>

            {/* Expanded Lots View */}
            {isExpanded && hasMultipleLots && (
              <div className="border-t border-gray-200 bg-gray-50 px-4 py-3">
                <div className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-3">
                  Individual Purchase Lots
                </div>
                <div className="space-y-2">
                  {group.lots.map((lot) => {
                    const lotStats = calculateLotProfit(lot)
                    return (
                      <div
                        key={lot.id}
                        className="bg-white rounded-lg p-3 border border-gray-200 text-sm"
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex gap-4 text-gray-700">
                            <div>
                              <span className="font-medium">{lot.quantity.toLocaleString()}</span>
                              <span className="text-gray-500"> @ </span>
                              <span className="font-medium">{lot.buy_price.toLocaleString()} GP</span>
                            </div>
                            <div className="text-gray-500">
                              {new Date(lot.date_purchased).toLocaleDateString()}
                            </div>
                            {lot.notes && (
                              <div className="text-gray-500 italic">"{lot.notes}"</div>
                            )}
                          </div>
                          <div className="flex items-center gap-3">
                            {lotStats && (
                              <div className={`text-sm font-medium ${
                                lotStats.profit >= 0 ? 'text-green-600' : 'text-red-600'
                              }`}>
                                {lotStats.profit >= 0 ? '+' : ''}{lotStats.profit.toLocaleString()} GP
                                <span className="ml-1 text-xs">
                                  ({lotStats.profitPercentage >= 0 ? '+' : ''}{lotStats.profitPercentage.toFixed(1)}%)
                                </span>
                              </div>
                            )}
                            <button
                              onClick={() => handleDelete(lot.id)}
                              className="text-xs text-red-600 hover:text-red-800"
                            >
                              Remove
                            </button>
                          </div>
                        </div>
                      </div>
                    )
                  })}
                </div>
              </div>
            )}
          </div>
        )
      })}
    </div>
  )
}
