import { useState } from 'react'
import { supabase } from '../lib/supabase'
import { ItemSearch } from './ItemSearch'
import { parsePrice, formatPrice } from '../lib/priceParser'

interface Item {
  id: number
  name: string
  icon_url: string | null
  members: boolean
}

interface AddItemModalProps {
  isOpen: boolean
  onClose: () => void
  onSuccess: () => void
}

export function AddItemModal({ isOpen, onClose, onSuccess }: AddItemModalProps) {
  const [selectedItem, setSelectedItem] = useState<Item | null>(null)
  const [quantity, setQuantity] = useState('')
  const [buyPrice, setBuyPrice] = useState('')
  const [datePurchased, setDatePurchased] = useState(
    new Date().toISOString().split('T')[0]
  )
  const [notes, setNotes] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  if (!isOpen) return null

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError('')

    if (!selectedItem) {
      setError('Please select an item')
      return
    }

    if (!quantity || parseInt(quantity) <= 0) {
      setError('Please enter a valid quantity')
      return
    }

    const parsedPrice = parsePrice(buyPrice)
    if (!parsedPrice || parsedPrice <= 0) {
      setError('Please enter a valid buy price (e.g., 1000, 1k, 1.5m, 5b)')
      return
    }

    setLoading(true)

    try {
      const { data: { user } } = await supabase.auth.getUser()

      if (!user) {
        setError('You must be logged in')
        return
      }

      const { error: insertError } = await supabase
        .from('portfolio_items')
        .insert({
          user_id: user.id,
          item_id: selectedItem.id,
          quantity: parseInt(quantity),
          buy_price: parsedPrice,
          date_purchased: datePurchased,
          notes: notes || null,
        })

      if (insertError) throw insertError

      // Reset form
      setSelectedItem(null)
      setQuantity('')
      setBuyPrice('')
      setDatePurchased(new Date().toISOString().split('T')[0])
      setNotes('')

      onSuccess()
      onClose()
    } catch (err: any) {
      setError(err.message || 'Failed to add item')
    } finally {
      setLoading(false)
    }
  }

  const handleClose = () => {
    if (!loading) {
      onClose()
    }
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        <div className="p-6">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold text-gray-900">Add Item to Portfolio</h2>
            <button
              onClick={handleClose}
              className="text-gray-400 hover:text-gray-600"
              disabled={loading}
            >
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            {error && (
              <div className="p-3 bg-red-50 border border-red-200 rounded-lg text-red-800 text-sm">
                {error}
              </div>
            )}

            {/* Selected Item Display */}
            {selectedItem && (
              <div className="p-4 bg-green-50 border border-green-200 rounded-lg flex items-center gap-3">
                {selectedItem.icon_url && (
                  <img src={selectedItem.icon_url} alt={selectedItem.name} className="w-12 h-12" />
                )}
                <div className="flex-1">
                  <div className="font-bold text-gray-900">{selectedItem.name}</div>
                  <div className="text-sm text-gray-600">ID: {selectedItem.id}</div>
                </div>
                <button
                  type="button"
                  onClick={() => setSelectedItem(null)}
                  className="text-sm text-red-600 hover:text-red-800"
                >
                  Change
                </button>
              </div>
            )}

            {/* Item Search */}
            {!selectedItem && (
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Search for Item *
                </label>
                <ItemSearch
                  onSelect={setSelectedItem}
                  placeholder="Type item name (e.g., Twisted bow, Abyssal whip)"
                />
              </div>
            )}

            {/* Quantity */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Quantity *
              </label>
              <input
                type="number"
                value={quantity}
                onChange={(e) => setQuantity(e.target.value)}
                min="1"
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-ge-gold focus:border-transparent"
                placeholder="How many do you have?"
              />
            </div>

            {/* Buy Price */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Buy Price (per item) *
              </label>
              <input
                type="text"
                value={buyPrice}
                onChange={(e) => setBuyPrice(e.target.value)}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-ge-gold focus:border-transparent"
                placeholder="e.g., 1000, 1k, 1.5m, 5b"
              />
              {buyPrice && (() => {
                const parsed = parsePrice(buyPrice)
                const qty = parseInt(quantity)
                return (
                  <div className="mt-1 space-y-1">
                    {parsed && parsed > 0 ? (
                      <>
                        <p className="text-sm text-green-600">
                          ✓ Parsed: {parsed.toLocaleString()} GP ({formatPrice(parsed)})
                        </p>
                        {qty > 0 && (
                          <p className="text-sm text-gray-600">
                            Total cost: {(parsed * qty).toLocaleString()} GP
                          </p>
                        )}
                      </>
                    ) : (
                      <p className="text-sm text-red-600">
                        Invalid format. Examples: 1000, 1k, 1.5m, 5b
                      </p>
                    )}
                  </div>
                )
              })()}
            </div>

            {/* Date Purchased */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Date Purchased *
              </label>
              <input
                type="date"
                value={datePurchased}
                onChange={(e) => setDatePurchased(e.target.value)}
                max={new Date().toISOString().split('T')[0]}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-ge-gold focus:border-transparent"
              />
            </div>

            {/* Notes */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Notes (optional)
              </label>
              <textarea
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                rows={3}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-ge-gold focus:border-transparent"
                placeholder="Any notes about this investment..."
              />
            </div>

            {/* Actions */}
            <div className="flex gap-3 pt-4">
              <button
                type="button"
                onClick={handleClose}
                disabled={loading}
                className="flex-1 px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 disabled:opacity-50"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={loading || !selectedItem}
                className="flex-1 px-4 py-2 bg-ge-gold text-ge-blue rounded-lg font-semibold hover:bg-yellow-400 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {loading ? 'Adding...' : 'Add to Portfolio'}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  )
}
