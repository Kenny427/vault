import { useState, useEffect } from 'react'
import { supabase } from '../lib/supabase'
import { calculateProfitAfterTax } from '../lib/geTax'

interface SummaryStats {
  totalInvested: number
  currentValue: number
  totalProfit: number
  profitPercentage: number
  totalTax: number
  itemCount: number
}

interface PortfolioSummaryProps {
  refreshTrigger: number
}

export function PortfolioSummary({ refreshTrigger }: PortfolioSummaryProps) {
  const [stats, setStats] = useState<SummaryStats | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchStats()
  }, [refreshTrigger])

  const fetchStats = async () => {
    setLoading(true)

    try {
      const { data: { user } } = await supabase.auth.getUser()
      if (!user) return

      // Fetch portfolio items with prices
      const { data: portfolioData, error: portfolioError } = await supabase
        .from('portfolio_items')
        .select(`
          quantity,
          buy_price,
          item_id
        `)
        .eq('user_id', user.id)

      if (portfolioError) throw portfolioError

      if (!portfolioData || portfolioData.length === 0) {
        setStats(null)
        setLoading(false)
        return
      }

      // Get prices for all items
      const itemIds = portfolioData.map(item => item.item_id)
      const { data: pricesData } = await supabase
        .from('item_prices_current')
        .select('item_id, high_price')
        .in('item_id', itemIds)

      const pricesMap = new Map(
        pricesData?.map(p => [p.item_id, p.high_price]) || []
      )

      // Calculate totals with tax
      let totalInvested = 0
      let currentValue = 0
      let totalTax = 0

      portfolioData.forEach(item => {
        const invested = item.buy_price * item.quantity
        totalInvested += invested

        const highPrice = pricesMap.get(item.item_id)
        if (highPrice) {
          // Calculate profit after tax for this item
          const profitCalc = calculateProfitAfterTax(
            item.buy_price,
            highPrice,
            item.quantity,
            item.item_id
          )

          currentValue += profitCalc.netValue
          totalTax += profitCalc.tax
        } else {
          // If no price, use buy price as current value (no tax)
          currentValue += invested
        }
      })

      const totalProfit = currentValue - totalInvested
      const profitPercentage = totalInvested > 0 ? (totalProfit / totalInvested) * 100 : 0

      // Count unique items instead of total lots
      const uniqueItems = new Set(portfolioData.map(item => item.item_id)).size

      setStats({
        totalInvested,
        currentValue,
        totalProfit,
        profitPercentage,
        totalTax,
        itemCount: uniqueItems
      })
    } catch (err) {
      console.error('Error fetching portfolio stats:', err)
    } finally {
      setLoading(false)
    }
  }

  if (loading) {
    return (
      <div className="bg-gradient-to-br from-white to-gray-50 rounded-2xl shadow-xl p-8 mb-8 border border-gray-200">
        <div className="animate-pulse">
          <div className="h-8 bg-gray-200 rounded w-64 mb-6"></div>
          <div className="grid md:grid-cols-3 gap-6">
            <div className="h-32 bg-gray-200 rounded-xl"></div>
            <div className="h-32 bg-gray-200 rounded-xl"></div>
            <div className="h-32 bg-gray-200 rounded-xl"></div>
          </div>
        </div>
      </div>
    )
  }

  if (!stats) {
    return null
  }

  const isProfit = stats.totalProfit >= 0

  return (
    <div className="bg-gradient-to-br from-white via-gray-50 to-white rounded-2xl shadow-xl p-8 mb-8 border-2 border-gray-200 hover:border-ge-gold/50 transition-all">
      <div className="flex items-center gap-3 mb-6">
        <span className="text-4xl">💰</span>
        <h3 className="text-3xl font-bold bg-gradient-to-r from-ge-blue to-gray-800 bg-clip-text text-transparent">
          Portfolio Summary
        </h3>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
        {/* Total Invested */}
        <div className="bg-white rounded-xl p-4 sm:p-6 border-2 border-blue-100 hover:border-blue-300 hover:shadow-lg transition-all">
          <div className="flex items-center justify-between mb-3">
            <div className="text-xs font-bold text-blue-600 uppercase tracking-wider">Total Invested</div>
            <span className="text-xl sm:text-2xl">📊</span>
          </div>
          <div className="text-2xl sm:text-3xl font-black text-gray-900">
            {stats.totalInvested.toLocaleString()}
            <span className="text-lg sm:text-xl font-bold text-ge-gold ml-1 sm:ml-2">GP</span>
          </div>
        </div>

        {/* Current Value */}
        <div className="bg-white rounded-xl p-4 sm:p-6 border-2 border-purple-100 hover:border-purple-300 hover:shadow-lg transition-all">
          <div className="flex items-center justify-between mb-3">
            <div className="text-xs font-bold text-purple-600 uppercase tracking-wider">Current Value</div>
            <span className="text-xl sm:text-2xl">💎</span>
          </div>
          <div className="text-2xl sm:text-3xl font-black text-gray-900">
            {stats.currentValue.toLocaleString()}
            <span className="text-lg sm:text-xl font-bold text-ge-gold ml-1 sm:ml-2">GP</span>
          </div>
        </div>

        {/* Total Profit/Loss */}
        <div className={`rounded-xl p-4 sm:p-6 border-2 hover:shadow-lg transition-all sm:col-span-2 lg:col-span-1 ${
          isProfit
            ? 'bg-gradient-to-br from-green-50 to-emerald-50 border-green-300 hover:border-green-400'
            : 'bg-gradient-to-br from-red-50 to-rose-50 border-red-300 hover:border-red-400'
        }`}>
          <div className="flex items-center justify-between mb-3">
            <div className={`text-xs font-bold uppercase tracking-wider ${isProfit ? 'text-green-700' : 'text-red-700'}`}>
              Total Profit/Loss
            </div>
            <span className="text-xl sm:text-2xl">{isProfit ? '📈' : '📉'}</span>
          </div>
          <div className={`text-2xl sm:text-3xl font-black ${isProfit ? 'text-green-700' : 'text-red-700'}`}>
            {isProfit ? '+' : ''}{stats.totalProfit.toLocaleString()}
            <span className="text-lg sm:text-xl font-bold text-ge-gold ml-1 sm:ml-2">GP</span>
          </div>
          <div className={`text-lg sm:text-xl font-bold mt-2 ${isProfit ? 'text-green-600' : 'text-red-600'}`}>
            {isProfit ? '↗' : '↘'} {isProfit ? '+' : ''}{Math.abs(stats.profitPercentage).toFixed(2)}%
          </div>
        </div>
      </div>

      {/* Footer Info */}
      <div className="mt-6 pt-6 border-t-2 border-gray-200 flex flex-wrap justify-between gap-4 text-sm">
        <div className="flex items-center gap-2 bg-ge-gold/10 px-4 py-2 rounded-lg border border-ge-gold/30">
          <span className="text-lg">📦</span>
          <span className="font-semibold text-gray-700">Items Tracked:</span>
          <span className="font-black text-ge-blue text-lg">{stats.itemCount}</span>
        </div>
        {stats.totalTax > 0 && (
          <div className="flex items-center gap-2 bg-orange-50 px-4 py-2 rounded-lg border border-orange-200">
            <span className="text-lg">💸</span>
            <span className="font-semibold text-gray-700">Est. GE Tax (2%):</span>
            <span className="font-bold text-orange-700">{stats.totalTax.toLocaleString()} GP</span>
          </div>
        )}
      </div>
    </div>
  )
}
