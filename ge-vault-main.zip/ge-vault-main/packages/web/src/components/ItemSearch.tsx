import { useState, useEffect } from 'react'
import { supabase } from '../lib/supabase'

interface Item {
  id: number
  name: string
  icon_url: string | null
  members: boolean
}

interface ItemSearchProps {
  onSelect: (item: Item) => void
  placeholder?: string
}

export function ItemSearch({ onSelect, placeholder = 'Search for an item...' }: ItemSearchProps) {
  const [query, setQuery] = useState('')
  const [results, setResults] = useState<Item[]>([])
  const [loading, setLoading] = useState(false)
  const [showResults, setShowResults] = useState(false)

  useEffect(() => {
    if (query.length < 2) {
      setResults([])
      return
    }

    const searchItems = async () => {
      setLoading(true)

      // Search items and join with prices to only show tradeable items
      const { data, error } = await supabase
        .from('items')
        .select(`
          id,
          name,
          icon_url,
          members,
          item_prices_current!inner (
            item_id
          )
        `)
        .ilike('name', `%${query}%`)
        .order('name')
        .limit(10)

      if (error) {
        console.error('Error searching items:', error)
      } else {
        // Transform data to remove the nested price object
        const items = (data || []).map(item => ({
          id: item.id,
          name: item.name,
          icon_url: item.icon_url,
          members: item.members
        }))
        setResults(items)
      }

      setLoading(false)
    }

    const debounce = setTimeout(searchItems, 300)
    return () => clearTimeout(debounce)
  }, [query])

  const handleSelect = (item: Item) => {
    onSelect(item)
    setQuery('')
    setResults([])
    setShowResults(false)
  }

  return (
    <div className="relative">
      <input
        type="text"
        value={query}
        onChange={(e) => {
          setQuery(e.target.value)
          setShowResults(true)
        }}
        onFocus={() => setShowResults(true)}
        onBlur={() => setTimeout(() => setShowResults(false), 200)}
        placeholder={placeholder}
        className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-ge-gold focus:border-transparent"
      />

      {showResults && query.length >= 2 && (
        <div className="absolute z-10 w-full mt-1 bg-white border border-gray-200 rounded-lg shadow-lg max-h-80 overflow-y-auto">
          {loading && (
            <div className="px-4 py-3 text-gray-500">Searching...</div>
          )}

          {!loading && results.length === 0 && (
            <div className="px-4 py-3 text-gray-500">No items found</div>
          )}

          {!loading && results.map((item) => (
            <button
              key={item.id}
              onClick={() => handleSelect(item)}
              className="w-full px-4 py-2 text-left hover:bg-gray-50 flex items-center gap-3 border-b border-gray-100 last:border-b-0"
            >
              {item.icon_url && (
                <img src={item.icon_url} alt={item.name} className="w-8 h-8" />
              )}
              <div className="flex-1">
                <div className="font-medium text-gray-900">{item.name}</div>
                <div className="text-xs text-gray-500">
                  ID: {item.id} {item.members ? '• Members' : '• F2P'}
                </div>
              </div>
            </button>
          ))}
        </div>
      )}
    </div>
  )
}
