// app/src/components/alerts/AlertCard.tsx
import React from 'react';
import type { UserAlert } from '@ge-vault/shared';
import { supabase } from '../../lib/supabase';

interface AlertCardProps {
  alert: UserAlert;
  currentPrice?: number;
  priceUpdatedAt?: string;
  onDelete: (id: number) => void;
  onUpdate: (alert: UserAlert) => void;
  onEdit: (alert: UserAlert) => void;
}

const AlertCard: React.FC<AlertCardProps> = ({ alert, currentPrice, priceUpdatedAt, onDelete, onUpdate, onEdit }) => {

  const handleDelete = async () => {
    if (window.confirm('Are you sure you want to delete this alert?')) {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        window.alert('Not authenticated');
        return;
      }

      const response = await fetch('/api/alerts/delete', {
        method: 'DELETE',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${session.access_token}`,
        },
        body: JSON.stringify({ id: alert.id }),
      });

      if (!response.ok) {
        window.alert('Failed to delete alert.');
      } else {
        onDelete(alert.id);
      }
    }
  };

  const handleToggleActive = async () => {
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) {
      window.alert('Not authenticated');
      return;
    }

    const response = await fetch('/api/alerts/update', {
      method: 'PATCH',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${session.access_token}`,
      },
      body: JSON.stringify({ id: alert.id, active: !alert.active }),
    });

    if (!response.ok) {
      window.alert('Failed to update alert.');
    } else {
      const data = await response.json();
      onUpdate(data as UserAlert);
    }
  };

  const getDirectionIcon = () => {
    if (alert.price_direction === 'up') return '📈';
    if (alert.price_direction === 'down') return '📉';
    return '↕️';
  };

  const getDirectionText = () => {
    if (alert.price_direction === 'up') return 'rises to';
    if (alert.price_direction === 'down') return 'falls to';
    return 'changes by';
  };

  const getTimeAgo = (timestamp: string) => {
    // Handle Supabase timestamp format - add Z if not present for UTC interpretation
    const formattedTimestamp = timestamp.endsWith('Z') ? timestamp : timestamp + 'Z';
    const date = new Date(formattedTimestamp);
    const now = new Date();
    const seconds = Math.floor((now.getTime() - date.getTime()) / 1000);
    const minutes = Math.floor(seconds / 60);
    const hours = Math.floor(minutes / 60);

    if (minutes < 1) return 'Just now';
    if (minutes === 1) return '1 minute ago';
    if (minutes < 60) return `${minutes} minutes ago`;
    if (hours === 1) return '1 hour ago';
    return `${hours} hours ago`;
  };

  return (
    <div className={`bg-white rounded-lg shadow-md p-6 border-l-4 ${alert.active ? 'border-green-500' : 'border-gray-400'}`}>
      <div className="flex items-start justify-between mb-4">
        <div className="flex-1">
          <h3 className="text-xl font-bold text-ge-blue flex items-center gap-2">
            {getDirectionIcon()}
            {alert.item_name}
          </h3>
          <p className="text-gray-600 mt-1">
            Alert when price {getDirectionText()}{' '}
            <span className="font-semibold text-ge-gold">
              {alert.alert_type === 'absolute'
                ? `${alert.target_price?.toLocaleString()} gp`
                : `${alert.percentage_threshold}%`}
            </span>
          </p>
          {currentPrice && (
            <p className="text-gray-600 mt-1">
              Current: <span className="font-semibold">{currentPrice.toLocaleString()} gp</span>
              {priceUpdatedAt && (
                <span className="text-gray-500 text-sm ml-2">
                  (updated {getTimeAgo(priceUpdatedAt)})
                </span>
              )}
            </p>
          )}
        </div>
        <div className="flex items-center gap-2">
          {alert.active ? (
            <span className="px-3 py-1 bg-green-100 text-green-700 rounded-full text-sm font-semibold">
              Active
            </span>
          ) : (
            <span className="px-3 py-1 bg-gray-100 text-gray-600 rounded-full text-sm font-semibold">
              Inactive
            </span>
          )}
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4 mb-4 text-sm">
        <div>
          <p className="text-gray-500">Behavior</p>
          <p className="text-gray-700 font-semibold capitalize">{alert.behavior.replace('_', ' ')}</p>
        </div>
        <div>
          <p className="text-gray-500">Notification</p>
          <p className="text-gray-700 font-semibold">{alert.notification_type === 'bot_dm' ? 'Discord DM' : 'Webhook'}</p>
        </div>
        <div>
          <p className="text-gray-500">Last Triggered</p>
          <p className="text-gray-700 font-semibold">
            {alert.last_triggered_at ? new Date(alert.last_triggered_at).toLocaleDateString() : 'Never'}
          </p>
        </div>
        <div>
          <p className="text-gray-500">Trigger Count</p>
          <p className="text-gray-700 font-semibold">{alert.trigger_count}</p>
        </div>
      </div>

      {alert.notes && (
        <div className="mb-4">
          <p className="text-gray-500 text-sm">Notes</p>
          <p className="text-gray-700">{alert.notes}</p>
        </div>
      )}

      <div className="flex gap-2">
        <button
          onClick={handleToggleActive}
          className={`px-4 py-2 font-semibold rounded-lg transition ${
            alert.active
              ? 'bg-gray-200 text-gray-700 hover:bg-gray-300'
              : 'bg-green-500 text-white hover:bg-green-600'
          }`}
        >
          {alert.active ? 'Disable' : 'Enable'}
        </button>
        <button
          onClick={() => onEdit(alert)}
          className="px-4 py-2 bg-ge-blue text-white font-semibold rounded-lg hover:bg-blue-700 transition"
        >
          Edit
        </button>
        <button
          onClick={handleDelete}
          className="px-4 py-2 bg-red-500 text-white font-semibold rounded-lg hover:bg-red-600 transition"
        >
          Delete
        </button>
      </div>
    </div>
  );
};

export default AlertCard;
