// app/src/components/alerts/AlertHistory.tsx
import React, { useEffect, useState } from 'react';
import type { AlertHistory as AlertHistoryType } from '@ge-vault/shared';
import { supabase } from '../../lib/supabase';

interface AlertHistoryProps {
  userId?: string;
  alertId?: number;
}

const AlertHistory: React.FC<AlertHistoryProps> = ({ userId, alertId }) => {
  const [history, setHistory] = useState<AlertHistoryType[]>([]);
  const [filteredHistory, setFilteredHistory] = useState<AlertHistoryType[]>([]);
  const [loading, setLoading] = useState(true);

  // Filters
  const [itemFilter, setItemFilter] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'success' | 'failed'>('all');
  const [dateFrom, setDateFrom] = useState('');
  const [dateTo, setDateTo] = useState('');

  // Pagination
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 15;

  useEffect(() => {
    const fetchHistory = async () => {
      let query = supabase
        .from('alert_history')
        .select('*')
        .order('triggered_at', { ascending: false });

      if (alertId) {
        query = query.eq('alert_id', alertId);
      } else if (userId) {
        query = query.eq('user_id', userId);
      }

      const { data, error } = await query;

      if (error) {
        console.error('Error fetching alert history:', error);
      } else {
        setHistory(data || []);
        setFilteredHistory(data || []);
      }
      setLoading(false);
    };

    fetchHistory();
  }, [alertId, userId]);

  // Apply filters whenever filter values change
  useEffect(() => {
    let filtered = [...history];

    // Item name filter
    if (itemFilter) {
      filtered = filtered.filter(entry =>
        entry.item_name.toLowerCase().includes(itemFilter.toLowerCase())
      );
    }

    // Status filter
    if (statusFilter === 'success') {
      filtered = filtered.filter(entry => entry.notification_sent);
    } else if (statusFilter === 'failed') {
      filtered = filtered.filter(entry => !entry.notification_sent);
    }

    // Date range filter
    if (dateFrom) {
      const fromDate = new Date(dateFrom);
      filtered = filtered.filter(entry => new Date(entry.triggered_at) >= fromDate);
    }
    if (dateTo) {
      const toDate = new Date(dateTo);
      toDate.setHours(23, 59, 59, 999); // Include the entire day
      filtered = filtered.filter(entry => new Date(entry.triggered_at) <= toDate);
    }

    setFilteredHistory(filtered);
    setCurrentPage(1); // Reset to first page when filters change
  }, [itemFilter, statusFilter, dateFrom, dateTo, history]);

  // Pagination
  const totalPages = Math.ceil(filteredHistory.length / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const endIndex = startIndex + itemsPerPage;
  const currentHistory = filteredHistory.slice(startIndex, endIndex);

  // TODO: Implement retry notification functionality
  // const handleRetryNotification = async (entry: AlertHistoryType) => {
  //   // Retry logic will be implemented in future update
  //   console.log('Retry notification for entry:', entry.id);
  // };

  const handleClearFilters = () => {
    setItemFilter('');
    setStatusFilter('all');
    setDateFrom('');
    setDateTo('');
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">
        <div className="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-ge-gold"></div>
        <p className="ml-4 text-gray-600">Loading history...</p>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-lg shadow-md">
      <div className="p-6 border-b border-gray-200">
        <h3 className="text-2xl font-bold text-ge-blue mb-4">Alert History</h3>

        {/* Filters */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-4">
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-1">
              Item Name
            </label>
            <input
              type="text"
              value={itemFilter}
              onChange={(e) => setItemFilter(e.target.value)}
              placeholder="Filter by item..."
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-ge-blue focus:border-transparent text-sm"
            />
          </div>

          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-1">
              Status
            </label>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value as 'all' | 'success' | 'failed')}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-ge-blue focus:border-transparent text-sm"
            >
              <option value="all">All</option>
              <option value="success">Success Only</option>
              <option value="failed">Failed Only</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-1">
              Date From
            </label>
            <input
              type="date"
              value={dateFrom}
              onChange={(e) => setDateFrom(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-ge-blue focus:border-transparent text-sm"
            />
          </div>

          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-1">
              Date To
            </label>
            <input
              type="date"
              value={dateTo}
              onChange={(e) => setDateTo(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-ge-blue focus:border-transparent text-sm"
            />
          </div>
        </div>

        <div className="flex justify-between items-center">
          <p className="text-sm text-gray-600">
            Showing {currentHistory.length} of {filteredHistory.length} entries
            {filteredHistory.length !== history.length && ` (filtered from ${history.length} total)`}
          </p>
          {(itemFilter || statusFilter !== 'all' || dateFrom || dateTo) && (
            <button
              onClick={handleClearFilters}
              className="text-sm text-ge-blue hover:text-blue-700 font-semibold"
            >
              Clear Filters
            </button>
          )}
        </div>
      </div>

      {/* History Table */}
      <div className="overflow-x-auto">
        {currentHistory.length === 0 ? (
          <div className="p-8 text-center">
            <div className="text-6xl mb-4">📜</div>
            <p className="text-gray-600 text-lg">
              {history.length === 0 ? 'No alert history yet' : 'No results match your filters'}
            </p>
          </div>
        ) : (
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">
                  Date & Time
                </th>
                <th className="px-6 py-3 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">
                  Item
                </th>
                <th className="px-6 py-3 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">
                  Trigger Price
                </th>
                <th className="px-6 py-3 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">
                  Target Price
                </th>
                <th className="px-6 py-3 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">
                  Type
                </th>
                <th className="px-6 py-3 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">
                  Status
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {currentHistory.map((entry) => (
                <tr key={entry.id} className="hover:bg-gray-50 transition">
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-700">
                    {new Date(entry.triggered_at).toLocaleString('en-US', {
                      month: 'short',
                      day: 'numeric',
                      year: 'numeric',
                      hour: '2-digit',
                      minute: '2-digit'
                    })}
                  </td>
                  <td className="px-6 py-4 text-sm font-semibold text-ge-blue">
                    {entry.item_name}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-700 font-semibold">
                    {entry.trigger_price.toLocaleString()} gp
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                    {entry.target_price.toLocaleString()} gp
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                    <span className="capitalize">{entry.alert_type.replace('_', ' ')}</span>
                    <br />
                    <span className="text-xs text-gray-500">{entry.notification_type === 'bot_dm' ? 'Discord DM' : 'Webhook'}</span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    {entry.notification_sent ? (
                      <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold bg-green-100 text-green-700">
                        ✓ Sent
                      </span>
                    ) : (
                      <div>
                        <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold bg-red-100 text-red-700">
                          ✗ Failed
                        </span>
                        {entry.notification_error && (
                          <p className="text-xs text-red-600 mt-1 max-w-xs" title={entry.notification_error}>
                            {entry.notification_error.length > 50
                              ? entry.notification_error.substring(0, 50) + '...'
                              : entry.notification_error}
                          </p>
                        )}
                      </div>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="px-6 py-4 border-t border-gray-200 flex items-center justify-between">
          <button
            onClick={() => setCurrentPage(prev => Math.max(1, prev - 1))}
            disabled={currentPage === 1}
            className={`px-4 py-2 rounded-lg font-semibold transition ${
              currentPage === 1
                ? 'bg-gray-100 text-gray-400 cursor-not-allowed'
                : 'bg-ge-blue text-white hover:bg-blue-700'
            }`}
          >
            Previous
          </button>

          <div className="flex items-center gap-2">
            <span className="text-sm text-gray-600">
              Page {currentPage} of {totalPages}
            </span>
            {totalPages <= 7 ? (
              // Show all pages if 7 or fewer
              <div className="flex gap-1">
                {Array.from({ length: totalPages }, (_, i) => i + 1).map(page => (
                  <button
                    key={page}
                    onClick={() => setCurrentPage(page)}
                    className={`px-3 py-1 rounded-lg font-semibold transition ${
                      page === currentPage
                        ? 'bg-ge-gold text-white'
                        : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                    }`}
                  >
                    {page}
                  </button>
                ))}
              </div>
            ) : (
              // Show abbreviated pagination for many pages
              <div className="flex gap-1">
                <button
                  onClick={() => setCurrentPage(1)}
                  className={`px-3 py-1 rounded-lg font-semibold transition ${
                    currentPage === 1 ? 'bg-ge-gold text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  1
                </button>
                {currentPage > 3 && <span className="px-2 py-1 text-gray-500">...</span>}
                {currentPage > 2 && currentPage < totalPages - 1 && (
                  <button
                    onClick={() => setCurrentPage(currentPage)}
                    className="px-3 py-1 rounded-lg font-semibold bg-ge-gold text-white"
                  >
                    {currentPage}
                  </button>
                )}
                {currentPage < totalPages - 2 && <span className="px-2 py-1 text-gray-500">...</span>}
                <button
                  onClick={() => setCurrentPage(totalPages)}
                  className={`px-3 py-1 rounded-lg font-semibold transition ${
                    currentPage === totalPages ? 'bg-ge-gold text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  {totalPages}
                </button>
              </div>
            )}
          </div>

          <button
            onClick={() => setCurrentPage(prev => Math.min(totalPages, prev + 1))}
            disabled={currentPage === totalPages}
            className={`px-4 py-2 rounded-lg font-semibold transition ${
              currentPage === totalPages
                ? 'bg-gray-100 text-gray-400 cursor-not-allowed'
                : 'bg-ge-blue text-white hover:bg-blue-700'
            }`}
          >
            Next
          </button>
        </div>
      )}
    </div>
  );
};

export default AlertHistory;
