// app/src/components/alerts/DiscordConnect.tsx
import React, { useEffect, useState } from 'react';
import { supabase } from '../../lib/supabase';
import type { DiscordConnection } from '@ge-vault/shared';

const DiscordConnect: React.FC = () => {
  const [connection, setConnection] = useState<DiscordConnection | null>(null);
  const [loading, setLoading] = useState(true);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [joiningServer, setJoiningServer] = useState(false);

  useEffect(() => {
    // Check for OAuth error in URL
    const params = new URLSearchParams(window.location.search);
    const discordError = params.get('discord_error');

    if (discordError === 'cancelled') {
      setErrorMessage('Discord connection cancelled. Click "Connect Discord" to try again.');
      // Clear the error param from URL
      window.history.replaceState({}, '', window.location.pathname);
    } else if (discordError === 'invalid') {
      setErrorMessage('Discord connection failed. Please try again.');
      window.history.replaceState({}, '', window.location.pathname);
    }

    const fetchConnection = async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (user) {
        const { data, error } = await supabase
          .from('discord_connections')
          .select('*')
          .eq('user_id', user.id);

        if (error) {
          console.error('Error fetching discord connection:', error);
        } else {
          // Get first result if exists (array instead of .single())
          setConnection(data && data.length > 0 ? data[0] : null);
        }
      }
      setLoading(false);
    };

    fetchConnection();
  }, []);

  const handleConnect = async () => {
    setJoiningServer(true);
    setErrorMessage(null);

    // Open Discord server invite in new tab
    const serverInvite = import.meta.env.VITE_DISCORD_SERVER_INVITE || 'https://discord.gg/78c5TebFfK';
    window.open(serverInvite, '_blank');

    // Wait 4 seconds for user to join, then proceed to OAuth
    setTimeout(async () => {
      const { data: { session } } = await supabase.auth.getSession();
      if (session?.access_token) {
        window.location.href = `${window.location.origin}/api/discord/connect?token=${session.access_token}`;
      } else {
        setErrorMessage('Please log in to connect Discord');
        setJoiningServer(false);
      }
    }, 4000);
  };

  const handleDisconnect = async () => {
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) {
      window.alert('Not authenticated');
      return;
    }

    const response = await fetch('/api/discord/disconnect', {
      method: 'DELETE',
      headers: {
        'Authorization': `Bearer ${session.access_token}`,
      },
    });

    if (!response.ok) {
      window.alert('Failed to disconnect Discord.');
    } else {
      setConnection(null);
    }
  };

  if (loading) {
    return (
      <div className="bg-white rounded-lg shadow-md p-6">
        <div className="flex items-center gap-3">
          <div className="inline-block animate-spin rounded-full h-5 w-5 border-b-2 border-ge-blue"></div>
          <p className="text-gray-600">Loading Discord connection status...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <h2 className="text-xl font-bold text-ge-blue mb-4 flex items-center gap-2">
        <span className="text-2xl">💬</span>
        Discord Connection
      </h2>
      {errorMessage && (
        <div className="mb-4 bg-yellow-50 border border-yellow-200 text-yellow-800 px-4 py-3 rounded-lg flex items-start gap-2">
          <span className="text-xl">⚠️</span>
          <div>
            <p className="font-medium">{errorMessage}</p>
          </div>
        </div>
      )}
      {connection ? (
        <div className="flex items-center justify-between flex-wrap gap-4">
          <div className="flex items-center gap-3">
            <span className="text-green-500 text-2xl">✓</span>
            <div>
              <p className="text-gray-700">
                Connected as <span className="font-semibold text-ge-blue">{connection.discord_username}</span>
              </p>
              <p className="text-sm text-gray-500">You'll receive alerts via Discord DM</p>
            </div>
          </div>
          <button
            onClick={handleDisconnect}
            className="px-4 py-2 bg-red-500 text-white font-semibold rounded-lg hover:bg-red-600 transition"
          >
            Disconnect
          </button>
        </div>
      ) : (
        <div className="space-y-4">
          <div>
            <p className="text-gray-700 mb-2 font-medium">Choose your notification method:</p>
          </div>

          {joiningServer && (
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-4">
              <div className="flex items-center gap-3">
                <div className="inline-block animate-spin rounded-full h-5 w-5 border-b-2 border-blue-600"></div>
                <div>
                  <p className="text-blue-900 font-medium">Connecting to Discord...</p>
                  <p className="text-sm text-blue-700">Join the server in the new tab, then you'll be redirected automatically</p>
                </div>
              </div>
            </div>
          )}

          {/* Bot DM Option */}
          <div className="border border-gray-200 rounded-lg p-4 bg-gray-50">
            <div className="flex items-start gap-3 mb-3">
              <span className="text-2xl">💬</span>
              <div className="flex-1">
                <h3 className="font-semibold text-gray-900 mb-1">Discord Direct Messages</h3>
                <p className="text-sm text-gray-600 mb-3">Get alerts sent directly to your Discord DMs</p>

                <div className="bg-blue-50 border border-blue-200 rounded p-3 mb-3 text-sm">
                  <p className="text-blue-900 font-medium mb-1">One-Click Setup</p>
                  <p className="text-blue-700">Click below to join our Discord server and connect your account automatically</p>
                </div>

                <button
                  onClick={handleConnect}
                  disabled={joiningServer}
                  className="px-6 py-3 bg-[#5865F2] text-white font-bold rounded-lg hover:bg-[#4752C4] transition transform hover:scale-105 shadow-md flex items-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none"
                >
                  <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515a.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0a12.64 12.64 0 0 0-.617-1.25a.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057a.082.082 0 0 0 .031.057a19.9 19.9 0 0 0 5.993 3.03a.078.078 0 0 0 .084-.028a14.09 14.09 0 0 0 1.226-1.994a.076.076 0 0 0-.041-.106a13.107 13.107 0 0 1-1.872-.892a.077.077 0 0 1-.008-.128a10.2 10.2 0 0 0 .372-.292a.074.074 0 0 1 .077-.01c3.928 1.793 8.18 1.793 12.062 0a.074.074 0 0 1 .078.01c.12.098.246.198.373.292a.077.077 0 0 1-.006.127a12.299 12.299 0 0 1-1.873.892a.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028a19.839 19.839 0 0 0 6.002-3.03a.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.03zM8.02 15.33c-1.183 0-2.157-1.085-2.157-2.419c0-1.333.956-2.419 2.157-2.419c1.21 0 2.176 1.096 2.157 2.42c0 1.333-.956 2.418-2.157 2.418zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419c0-1.333.955-2.419 2.157-2.419c1.21 0 2.176 1.096 2.157 2.42c0 1.333-.946 2.418-2.157 2.418z"/>
                  </svg>
                  {joiningServer ? 'Connecting...' : 'Connect Discord'}
                </button>
              </div>
            </div>
          </div>

          {/* Webhook Option */}
          <div className="border border-gray-200 rounded-lg p-4">
            <div className="flex items-start gap-3">
              <span className="text-2xl">🔗</span>
              <div className="flex-1">
                <h3 className="font-semibold text-gray-900 mb-1">Discord Webhook</h3>
                <p className="text-sm text-gray-600 mb-2">Send alerts to any Discord channel you control</p>
                <p className="text-xs text-gray-500">No server join required • You create a webhook in your own server • Full privacy</p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default DiscordConnect;
