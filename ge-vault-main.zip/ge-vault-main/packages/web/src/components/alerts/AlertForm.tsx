// app/src/components/alerts/AlertForm.tsx
import React, { useState, useEffect } from 'react';
import type { UserAlert, NotificationType, AlertBehavior } from '@ge-vault/shared';
import { supabase } from '../../lib/supabase';

// Parse price strings like "1k", "1m", "1b" into numbers
const parsePrice = (input: string): number => {
  const cleaned = input.toLowerCase().trim();
  const match = cleaned.match(/^([\d.]+)\s*([kmb])?$/);
  if (!match) return parseInt(input) || 0;

  const num = parseFloat(match[1]);
  const suffix = match[2];

  switch (suffix) {
    case 'k': return num * 1000;
    case 'm': return num * 1000000;
    case 'b': return num * 1000000000;
    default: return num;
  }
};

// Format number to shorthand
const formatPrice = (price: number): string => {
  if (price >= 1000000000) return `${(price / 1000000000).toFixed(1).replace(/\.0$/, '')}b`;
  if (price >= 1000000) return `${(price / 1000000).toFixed(1).replace(/\.0$/, '')}m`;
  if (price >= 1000) return `${(price / 1000).toFixed(1).replace(/\.0$/, '')}k`;
  return price.toString();
};

interface AlertFormProps {
  onSave: (alert: UserAlert) => void;
  onCancel: () => void;
  editAlert?: UserAlert;
}

const AlertForm: React.FC<AlertFormProps> = ({ onSave, onCancel, editAlert }) => {
  const [itemSearch, setItemSearch] = useState(editAlert?.item_name || '');
  const [itemName, setItemName] = useState(editAlert?.item_name || '');
  const [itemId, setItemId] = useState(editAlert?.item_id || '');
  const [itemSearchResults, setItemSearchResults] = useState<Array<{ id: string; name: string }>>([]);
  const [currentPrice, setCurrentPrice] = useState<number | null>(null);
  const [condition, setCondition] = useState<'above' | 'below'>(
    editAlert?.price_direction === 'down' ? 'below' : 'above'
  );
  const [priceInput, setPriceInput] = useState(editAlert?.target_price ? formatPrice(editAlert.target_price) : '');
  const [notificationType, setNotificationType] = useState<NotificationType>(editAlert?.notification_type || 'bot_dm');
  const [webhookUrl, setWebhookUrl] = useState(editAlert?.discord_webhook_url || '');
  const [behavior, setBehavior] = useState<AlertBehavior>(editAlert?.behavior || 'one_shot');
  const [cooldownHours, setCooldownHours] = useState(editAlert?.cooldown_hours || 24);

  // Fetch current price when editing
  useEffect(() => {
    if (editAlert?.item_id) {
      supabase
        .from('item_prices_current')
        .select('high_price')
        .eq('item_id', editAlert.item_id)
        .single()
        .then(({ data }) => {
          if (data?.high_price) {
            setCurrentPrice(data.high_price);
          }
        });
    }
  }, [editAlert?.item_id]);

  const handleItemSearch = async (query: string) => {
    setItemSearch(query);
    if (query.length < 2) {
      setItemSearchResults([]);
      return;
    }

    const { data, error } = await supabase
      .from('items')
      .select('id, name')
      .ilike('name', `%${query}%`)
      .limit(10);

    if (!error && data) {
      setItemSearchResults(data.map(item => ({ id: String(item.id), name: item.name })));
    }
  };

  const handleSelectItem = async (item: { id: string; name: string }) => {
    setItemId(item.id);
    setItemName(item.name);
    setItemSearch(item.name);
    setItemSearchResults([]);

    // Fetch current price
    const { data } = await supabase
      .from('item_prices_current')
      .select('high_price')
      .eq('item_id', item.id)
      .single();

    if (data?.high_price) {
      setCurrentPrice(data.high_price);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!itemId) {
      window.alert('Please select an item');
      return;
    }

    const targetPrice = parsePrice(priceInput);
    if (!targetPrice || targetPrice <= 0) {
      window.alert('Please enter a valid target price');
      return;
    }

    const newAlert: Partial<UserAlert> = {
      item_name: itemName,
      item_id: itemId,
      alert_type: 'absolute',
      price_direction: condition === 'above' ? 'up' : 'down',
      target_price: targetPrice,
      notification_type: notificationType,
      behavior: behavior,
    };

    if (notificationType === 'webhook') {
      newAlert.discord_webhook_url = webhookUrl;
    }

    if (behavior === 'cooldown') {
      newAlert.cooldown_hours = cooldownHours;
    }

    const { data: { session } } = await supabase.auth.getSession();
    if (!session) {
      window.alert('Not authenticated. Please log in and try again.');
      return;
    }

    const isEditing = !!editAlert;
    const endpoint = isEditing ? '/api/alerts/update' : '/api/alerts/create';
    const method = isEditing ? 'PATCH' : 'POST';
    const body = isEditing ? { id: editAlert.id, ...newAlert } : newAlert;

    const response = await fetch(endpoint, {
      method,
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${session.access_token}`,
      },
      body: JSON.stringify(body),
    });

    if (!response.ok) {
      try {
        const errorData = await response.json();
        if (errorData.details && Array.isArray(errorData.details)) {
          const errorMessage = errorData.details.join('\n• ');
          window.alert(`${errorData.error || 'Validation Error'}:\n\n• ${errorMessage}`);
        } else {
          window.alert(errorData.error || `Failed to ${isEditing ? 'update' : 'create'} alert. Please try again.`);
        }
      } catch {
        const errorText = await response.text();
        window.alert(`Error ${isEditing ? 'updating' : 'creating'} alert: ` + errorText);
      }
    } else {
      const data = await response.json();
      onSave(data as UserAlert);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg shadow-xl max-w-md w-full">
        <div className="border-b border-gray-200 px-6 py-4">
          <h2 className="text-2xl font-bold text-ge-blue">{editAlert ? 'Edit Alert' : 'Create Alert'}</h2>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {/* Item Search */}
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">
              Item
            </label>
            <input
              type="text"
              value={itemSearch}
              onChange={(e) => handleItemSearch(e.target.value)}
              placeholder="Search for an item..."
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-ge-blue focus:border-transparent"
              required
            />
            {itemSearchResults.length > 0 && (
              <ul className="mt-2 border border-gray-300 rounded-lg max-h-48 overflow-y-auto">
                {itemSearchResults.map((item) => (
                  <li
                    key={item.id}
                    onClick={() => handleSelectItem(item)}
                    className="px-4 py-2 hover:bg-ge-blue hover:text-white cursor-pointer transition"
                  >
                    {item.name}
                  </li>
                ))}
              </ul>
            )}
            {itemId && (
              <div className="mt-2">
                <p className="text-sm text-green-600 font-semibold">
                  ✓ {itemName}
                </p>
                {currentPrice && (
                  <p className="text-sm text-gray-600">
                    Current price: <span className="font-semibold text-ge-gold">{currentPrice.toLocaleString()} gp</span>
                  </p>
                )}
              </div>
            )}
          </div>

          {/* Price Condition */}
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">
              Alert when price is
            </label>
            <div className="flex gap-2">
              <select
                value={condition}
                onChange={e => setCondition(e.target.value as 'above' | 'below')}
                className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-ge-blue focus:border-transparent"
              >
                <option value="above">greater than</option>
                <option value="below">less than</option>
              </select>
              <input
                type="text"
                value={priceInput}
                onChange={e => setPriceInput(e.target.value)}
                placeholder="e.g. 1m, 500k"
                className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-ge-blue focus:border-transparent"
                required
              />
            </div>
            {priceInput && parsePrice(priceInput) > 0 && (
              <p className="mt-1 text-xs text-gray-500">
                = {parsePrice(priceInput).toLocaleString()} gp
              </p>
            )}
          </div>

          {/* Notification Type */}
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">
              Notify via
            </label>
            <select
              value={notificationType}
              onChange={e => setNotificationType(e.target.value as NotificationType)}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-ge-blue focus:border-transparent"
            >
              <option value="bot_dm">Discord DM</option>
              <option value="webhook">Discord Webhook</option>
            </select>
            {notificationType === 'webhook' && (
              <input
                type="url"
                value={webhookUrl}
                onChange={e => setWebhookUrl(e.target.value)}
                placeholder="https://discord.com/api/webhooks/..."
                className="mt-2 w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-ge-blue focus:border-transparent"
                required
              />
            )}
          </div>

          {/* Behavior */}
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">
              Trigger
            </label>
            <select
              value={behavior}
              onChange={e => setBehavior(e.target.value as AlertBehavior)}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-ge-blue focus:border-transparent"
            >
              <option value="one_shot">Once (then disable)</option>
              <option value="recurring">Every time</option>
              <option value="cooldown">Custom cooldown</option>
            </select>
            {behavior === 'cooldown' && (
              <div className="mt-2 flex items-center gap-2">
                <input
                  type="number"
                  value={cooldownHours}
                  onChange={e => setCooldownHours(Number(e.target.value))}
                  min="1"
                  className="w-20 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-ge-blue focus:border-transparent"
                />
                <span className="text-sm text-gray-600">hours between alerts</span>
              </div>
            )}
          </div>

          {/* Buttons */}
          <div className="flex gap-3 pt-4">
            <button
              type="submit"
              className="flex-1 px-6 py-3 bg-ge-gold text-white font-bold rounded-lg hover:bg-yellow-600 transition"
            >
              {editAlert ? 'Save' : 'Create'}
            </button>
            <button
              type="button"
              onClick={onCancel}
              className="px-6 py-3 bg-gray-200 text-gray-700 font-semibold rounded-lg hover:bg-gray-300 transition"
            >
              Cancel
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default AlertForm;
