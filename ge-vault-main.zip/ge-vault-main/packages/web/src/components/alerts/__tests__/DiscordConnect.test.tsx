import { describe, it, expect, vi, beforeEach } from 'vitest'
import { render, screen, waitFor } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import DiscordConnect from '../DiscordConnect'
import * as supabaseModule from '../../../lib/supabase'

// Mock Supabase
vi.mock('../../../lib/supabase', () => ({
  supabase: {
    auth: {
      getUser: vi.fn(),
      getSession: vi.fn()
    },
    from: vi.fn()
  }
}))

// Mock fetch
global.fetch = vi.fn()

describe('DiscordConnect', () => {
  beforeEach(() => {
    vi.clearAllMocks()
  })

  it('should render loading state initially', () => {
    vi.spyOn(supabaseModule.supabase.auth, 'getUser').mockImplementation(() =>
      new Promise(() => {}) // Never resolves, keeps loading
    )

    render(<DiscordConnect />)

    expect(screen.getByText(/Loading Discord connection status/i)).toBeInTheDocument()
  })

  it('should render connect button when not connected', async () => {
    vi.spyOn(supabaseModule.supabase.auth, 'getUser').mockResolvedValue({
      data: { user: { id: 'user-123' } as any },
      error: null
    })

    vi.spyOn(supabaseModule.supabase, 'from').mockReturnValue({
      select: vi.fn().mockReturnValue({
        eq: vi.fn().mockResolvedValue({
          data: [],
          error: null
        })
      })
    } as any)

    render(<DiscordConnect />)

    await waitFor(() => {
      expect(screen.getByRole('button', { name: /Connect Discord/i })).toBeInTheDocument()
    })

    expect(screen.getByText(/Choose your notification method/i)).toBeInTheDocument()
    expect(screen.getByText(/One-Click Setup/i)).toBeInTheDocument()
  })

  it('should render disconnect button when connected', async () => {
    vi.spyOn(supabaseModule.supabase.auth, 'getUser').mockResolvedValue({
      data: { user: { id: 'user-123' } as any },
      error: null
    })

    const mockConnection = {
      user_id: 'user-123',
      discord_user_id: 'discord-456',
      discord_username: 'TestUser#1234',
      access_token: 'token',
      refresh_token: 'refresh',
      token_expires_at: new Date(Date.now() + 86400000).toISOString()
    }

    vi.spyOn(supabaseModule.supabase, 'from').mockReturnValue({
      select: vi.fn().mockReturnValue({
        eq: vi.fn().mockResolvedValue({
          data: [mockConnection],
          error: null
        })
      })
    } as any)

    render(<DiscordConnect />)

    await waitFor(() => {
      expect(screen.getByText(/Connected as/i)).toBeInTheDocument()
      expect(screen.getByText('TestUser#1234')).toBeInTheDocument()
      expect(screen.getByRole('button', { name: /Disconnect/i })).toBeInTheDocument()
    })
  })

  it('should display success message when connected', async () => {
    vi.spyOn(supabaseModule.supabase.auth, 'getUser').mockResolvedValue({
      data: { user: { id: 'user-123' } as any },
      error: null
    })

    const mockConnection = {
      discord_username: 'TestUser#1234'
    }

    vi.spyOn(supabaseModule.supabase, 'from').mockReturnValue({
      select: vi.fn().mockReturnValue({
        eq: vi.fn().mockResolvedValue({
          data: [mockConnection],
          error: null
        })
      })
    } as any)

    render(<DiscordConnect />)

    await waitFor(() => {
      expect(screen.getByText(/You'll receive alerts via Discord DM/i)).toBeInTheDocument()
    })
  })

  // TODO: This test has async/timing issues that cause timeouts in both local and CI.
  // The component uses setTimeout (4s delay) with window.location redirect which is
  // difficult to test with current mock setup. Needs complete rewrite with better
  // async control (e.g., using dependency injection for window.location and setTimeout)
  it.skip('should initiate OAuth flow when connect button is clicked', async () => {
    vi.useFakeTimers()

    vi.spyOn(supabaseModule.supabase.auth, 'getUser').mockResolvedValue({
      data: { user: { id: 'user-123' } as any },
      error: null
    })

    vi.spyOn(supabaseModule.supabase.auth, 'getSession').mockResolvedValue({
      data: { session: { access_token: 'test-token' } as any },
      error: null
    })

    vi.spyOn(supabaseModule.supabase, 'from').mockReturnValue({
      select: vi.fn().mockReturnValue({
        eq: vi.fn().mockResolvedValue({
          data: [],
          error: null
        })
      })
    } as any)

    // Mock window.open and window.location.href
    const windowOpenSpy = vi.spyOn(window, 'open').mockImplementation(() => null)
    delete (window as any).location
    window.location = { href: '', origin: 'http://localhost:5173' } as Location

    render(<DiscordConnect />)

    await waitFor(() => {
      expect(screen.getByRole('button', { name: /Connect Discord/i })).toBeInTheDocument()
    })

    const connectButton = screen.getByRole('button', { name: /Connect Discord/i })

    // Use userEvent with clock system for fake timers
    const user = userEvent.setup({ delay: null, advanceTimers: vi.advanceTimersByTime })
    await user.click(connectButton)

    // Should open Discord invite in new tab
    expect(windowOpenSpy).toHaveBeenCalledWith('https://discord.gg/78c5TebFfK', '_blank')

    // Fast-forward 4 seconds to trigger OAuth redirect
    await vi.advanceTimersByTimeAsync(4000)

    await waitFor(() => {
      expect(window.location.href).toContain('/api/discord/connect')
      expect(window.location.href).toContain('token=test-token')
    })

    vi.useRealTimers()
    windowOpenSpy.mockRestore()
  }, 10000)

  // TODO: Test times out waiting for component state updates. The async fetch mock
  // may not be resolving correctly or there's a race condition with React state updates.
  it.skip('should call disconnect API when disconnect button is clicked', async () => {
    vi.spyOn(supabaseModule.supabase.auth, 'getUser').mockResolvedValue({
      data: { user: { id: 'user-123' } as any },
      error: null
    })

    vi.spyOn(supabaseModule.supabase.auth, 'getSession').mockResolvedValue({
      data: { session: { access_token: 'test-token' } as any },
      error: null
    })

    const mockConnection = {
      discord_username: 'TestUser#1234'
    }

    vi.spyOn(supabaseModule.supabase, 'from').mockReturnValue({
      select: vi.fn().mockReturnValue({
        eq: vi.fn().mockResolvedValue({
          data: [mockConnection],
          error: null
        })
      })
    } as any)

    ;(global.fetch as any).mockResolvedValue({
      ok: true,
      json: async () => ({})
    })

    render(<DiscordConnect />)

    await waitFor(() => {
      expect(screen.getByRole('button', { name: /Disconnect/i })).toBeInTheDocument()
    })

    const disconnectButton = screen.getByRole('button', { name: /Disconnect/i })
    const user = userEvent.setup()
    await user.click(disconnectButton)

    await waitFor(() => {
      expect(global.fetch).toHaveBeenCalledWith(
        '/api/discord/disconnect',
        expect.objectContaining({
          method: 'DELETE',
          headers: expect.objectContaining({
            'Authorization': 'Bearer test-token'
          })
        })
      )
    })
  }, 10000)

  // TODO: Same timeout issue as the disconnect test above. Needs investigation into
  // why component state isn't updating after failed fetch.
  it.skip('should show alert when disconnect fails', async () => {
    const alertSpy = vi.spyOn(window, 'alert').mockImplementation(() => {})

    vi.spyOn(supabaseModule.supabase.auth, 'getUser').mockResolvedValue({
      data: { user: { id: 'user-123' } as any },
      error: null
    })

    vi.spyOn(supabaseModule.supabase.auth, 'getSession').mockResolvedValue({
      data: { session: { access_token: 'test-token' } as any },
      error: null
    })

    const mockConnection = {
      discord_username: 'TestUser#1234'
    }

    vi.spyOn(supabaseModule.supabase, 'from').mockReturnValue({
      select: vi.fn().mockReturnValue({
        eq: vi.fn().mockResolvedValue({
          data: [mockConnection],
          error: null
        })
      })
    } as any)

    ;(global.fetch as any).mockResolvedValue({
      ok: false
    })

    render(<DiscordConnect />)

    await waitFor(() => {
      expect(screen.getByRole('button', { name: /Disconnect/i })).toBeInTheDocument()
    })

    const disconnectButton = screen.getByRole('button', { name: /Disconnect/i })
    const user = userEvent.setup()
    await user.click(disconnectButton)

    await waitFor(() => {
      expect(alertSpy).toHaveBeenCalledWith('Failed to disconnect Discord.')
    })

    alertSpy.mockRestore()
  }, 10000)

  it.skip('should handle error when fetching connection', async () => {
    const consoleSpy = vi.spyOn(console, 'error').mockImplementation(() => {})

    vi.spyOn(supabaseModule.supabase.auth, 'getUser').mockResolvedValue({
      data: { user: { id: 'user-123' } as any },
      error: null
    })

    vi.spyOn(supabaseModule.supabase, 'from').mockReturnValue({
      select: vi.fn().mockReturnValue({
        eq: vi.fn().mockResolvedValue({
          data: null,
          error: { message: 'Database error' }
        })
      })
    } as any)

    render(<DiscordConnect />)

    await waitFor(() => {
      expect(consoleSpy).toHaveBeenCalledWith('Error fetching discord connection:', { message: 'Database error' })
    })

    consoleSpy.mockRestore()
  })
})
