/**
 * Predefined alert templates for popular OSRS items
 * Users can quickly create alerts by selecting a template
 */

export interface AlertTemplate {
  id: string;
  name: string;
  description: string;
  itemId: string;
  itemName: string;
  alertType: 'absolute' | 'percentage_change';
  priceDirection: 'up' | 'down' | 'either';
  targetPrice?: number;
  percentageThreshold?: number;
  behavior: 'one_shot' | 'recurring' | 'cooldown';
  cooldownHours?: number;
  category: 'crash' | 'spike' | 'target' | 'flip';
  icon: string;
}

export const ALERT_TEMPLATES: AlertTemplate[] = [
  // Crash alerts (price drops)
  {
    id: 'dragon-bones-crash',
    name: 'Dragon Bones Crash (-10%)',
    description: 'Alert when Dragon bones drop 10% or more from current price',
    itemId: '536',
    itemName: 'Dragon bones',
    alertType: 'percentage_change',
    priceDirection: 'down',
    percentageThreshold: 10,
    behavior: 'one_shot',
    category: 'crash',
    icon: '📉'
  },
  {
    id: 'twisted-bow-crash',
    name: 'Twisted Bow Crash (-5%)',
    description: 'Alert when Twisted bow drops 5% or more',
    itemId: '20997',
    itemName: 'Twisted bow',
    alertType: 'percentage_change',
    priceDirection: 'down',
    percentageThreshold: 5,
    behavior: 'one_shot',
    category: 'crash',
    icon: '📉'
  },
  {
    id: 'scythe-crash',
    name: 'Scythe of Vitur Crash (-5%)',
    description: 'Alert when Scythe drops 5% or more',
    itemId: '22325',
    itemName: 'Scythe of vitur',
    alertType: 'percentage_change',
    priceDirection: 'down',
    percentageThreshold: 5,
    behavior: 'one_shot',
    category: 'crash',
    icon: '📉'
  },

  // Spike alerts (price increases)
  {
    id: 'twisted-bow-spike',
    name: 'Twisted Bow Spike (+5%)',
    description: 'Alert when Twisted bow rises 5% or more',
    itemId: '20997',
    itemName: 'Twisted bow',
    alertType: 'percentage_change',
    priceDirection: 'up',
    percentageThreshold: 5,
    behavior: 'one_shot',
    category: 'spike',
    icon: '📈'
  },
  {
    id: 'tbow-spike-recurring',
    name: 'Twisted Bow Recurring Spike (+3%)',
    description: 'Recurring alert for 3%+ increases with 24h cooldown',
    itemId: '20997',
    itemName: 'Twisted bow',
    alertType: 'percentage_change',
    priceDirection: 'up',
    percentageThreshold: 3,
    behavior: 'cooldown',
    cooldownHours: 24,
    category: 'spike',
    icon: '🔄'
  },
  {
    id: 'ranarr-seed-spike',
    name: 'Ranarr Seed Spike (+15%)',
    description: 'Alert when Ranarr seeds spike 15% or more',
    itemId: '5295',
    itemName: 'Ranarr seed',
    alertType: 'percentage_change',
    priceDirection: 'up',
    percentageThreshold: 15,
    behavior: 'one_shot',
    category: 'spike',
    icon: '📈'
  },

  // Target price alerts
  {
    id: 'abyssal-whip-under-1m',
    name: 'Abyssal Whip Under 1M',
    description: 'Alert when Abyssal whip drops below 1M gp',
    itemId: '4151',
    itemName: 'Abyssal whip',
    alertType: 'absolute',
    priceDirection: 'down',
    targetPrice: 1000000,
    behavior: 'one_shot',
    category: 'target',
    icon: '🎯'
  },
  {
    id: 'dragon-claws-under-100m',
    name: 'Dragon Claws Under 100M',
    description: 'Alert when Dragon claws drop below 100M gp',
    itemId: '13652',
    itemName: 'Dragon claws',
    alertType: 'absolute',
    priceDirection: 'down',
    targetPrice: 100000000,
    behavior: 'one_shot',
    category: 'target',
    icon: '🎯'
  },
  {
    id: 'ancestral-hat-under-50m',
    name: 'Ancestral Hat Under 50M',
    description: 'Alert when Ancestral hat drops below 50M gp',
    itemId: '21018',
    itemName: 'Ancestral hat',
    alertType: 'absolute',
    priceDirection: 'down',
    targetPrice: 50000000,
    behavior: 'one_shot',
    category: 'target',
    icon: '🎯'
  },

  // Flipping alerts (high frequency monitoring)
  {
    id: 'dragon-bones-flip',
    name: 'Dragon Bones Flip Monitor',
    description: 'Recurring 5% change alert for flipping (12h cooldown)',
    itemId: '536',
    itemName: 'Dragon bones',
    alertType: 'percentage_change',
    priceDirection: 'either',
    percentageThreshold: 5,
    behavior: 'cooldown',
    cooldownHours: 12,
    category: 'flip',
    icon: '🔄'
  },
  {
    id: 'cannonball-flip',
    name: 'Cannonball Flip Monitor',
    description: 'Recurring 8% change alert for flipping (6h cooldown)',
    itemId: '2',
    itemName: 'Cannonballs',
    alertType: 'percentage_change',
    priceDirection: 'either',
    percentageThreshold: 8,
    behavior: 'cooldown',
    cooldownHours: 6,
    category: 'flip',
    icon: '🔄'
  },
  {
    id: 'zulrah-scales-flip',
    name: 'Zulrah Scales Flip Monitor',
    description: 'Recurring 10% change alert for flipping (24h cooldown)',
    itemId: '12934',
    itemName: "Zulrah's scales",
    alertType: 'percentage_change',
    priceDirection: 'either',
    percentageThreshold: 10,
    behavior: 'cooldown',
    cooldownHours: 24,
    category: 'flip',
    icon: '🔄'
  }
];

export const ALERT_CATEGORIES = [
  { id: 'crash', name: 'Crash Alerts', description: 'Get notified when prices drop', icon: '📉' },
  { id: 'spike', name: 'Spike Alerts', description: 'Get notified when prices rise', icon: '📈' },
  { id: 'target', name: 'Target Alerts', description: 'Alert at specific price points', icon: '🎯' },
  { id: 'flip', name: 'Flip Monitors', description: 'Recurring alerts for active trading', icon: '🔄' }
];

export function getTemplatesByCategory(category: string): AlertTemplate[] {
  return ALERT_TEMPLATES.filter(template => template.category === category);
}

export function getTemplateById(id: string): AlertTemplate | undefined {
  return ALERT_TEMPLATES.find(template => template.id === id);
}
