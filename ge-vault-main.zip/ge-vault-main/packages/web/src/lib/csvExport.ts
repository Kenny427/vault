/**
 * CSV Export Utilities for Portfolio Data
 * Handles client-side export of portfolio items to CSV format
 */

export interface PortfolioCSVRow {
  itemName: string
  quantity: number
  avgPurchasePrice: number
  currentPrice: number
  totalCost: number
  currentValue: number
  geTax: number
  profitLossBeforeTax: number
  netProfitLoss: number
  taxExempt: boolean
}

/**
 * Escape CSV field to handle commas, quotes, and newlines
 */
function escapeCsvField(field: string | number | boolean): string {
  const stringField = String(field)

  // If field contains comma, quote, or newline, wrap in quotes and escape existing quotes
  if (stringField.includes(',') || stringField.includes('"') || stringField.includes('\n')) {
    return `"${stringField.replace(/"/g, '""')}"`
  }

  return stringField
}

/**
 * Format a CSV row
 */
function formatCsvRow(row: (string | number | boolean)[]): string {
  return row.map(escapeCsvField).join(',')
}

/**
 * Export portfolio data to CSV and trigger browser download
 */
export function exportPortfolioToCSV(data: PortfolioCSVRow[]): void {
  // Header row
  const headers = [
    'Item Name',
    'Quantity',
    'Average Purchase Price (GP)',
    'Current Price (GP)',
    'Total Cost (GP)',
    'Current Value (GP)',
    'GE Tax (GP)',
    'Profit/Loss Before Tax (GP)',
    'Net Profit/Loss After Tax (GP)',
    'Tax Exempt'
  ]

  // Data rows
  const dataRows = data.map(row => [
    row.itemName,
    row.quantity,
    Math.round(row.avgPurchasePrice),
    Math.round(row.currentPrice),
    Math.round(row.totalCost),
    Math.round(row.currentValue),
    Math.round(row.geTax),
    Math.round(row.profitLossBeforeTax),
    Math.round(row.netProfitLoss),
    row.taxExempt ? 'Yes' : 'No'
  ])

  // Calculate totals
  const totals = data.reduce(
    (acc, row) => ({
      totalCost: acc.totalCost + row.totalCost,
      currentValue: acc.currentValue + row.currentValue,
      geTax: acc.geTax + row.geTax,
      profitLossBeforeTax: acc.profitLossBeforeTax + row.profitLossBeforeTax,
      netProfitLoss: acc.netProfitLoss + row.netProfitLoss,
    }),
    {
      totalCost: 0,
      currentValue: 0,
      geTax: 0,
      profitLossBeforeTax: 0,
      netProfitLoss: 0,
    }
  )

  // Summary row
  const summaryRow = [
    'TOTAL',
    '', // No quantity total
    '', // No avg price total
    '', // No current price total
    Math.round(totals.totalCost),
    Math.round(totals.currentValue),
    Math.round(totals.geTax),
    Math.round(totals.profitLossBeforeTax),
    Math.round(totals.netProfitLoss),
    '' // No tax exempt total
  ]

  // Combine all rows
  const csvRows = [
    formatCsvRow(headers),
    ...dataRows.map(row => formatCsvRow(row)),
    '', // Empty row before summary
    formatCsvRow(summaryRow)
  ]

  // Create CSV content
  const csvContent = csvRows.join('\n')

  // Create blob and download
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' })
  const url = URL.createObjectURL(blob)

  // Generate filename with current date
  const today = new Date()
  const dateString = today.toISOString().split('T')[0] // YYYY-MM-DD format
  const filename = `gevault-portfolio-${dateString}.csv`

  // Create temporary link and trigger download
  const link = document.createElement('a')
  link.href = url
  link.download = filename
  link.style.display = 'none'

  document.body.appendChild(link)
  link.click()

  // Cleanup
  document.body.removeChild(link)
  URL.revokeObjectURL(url)
}
