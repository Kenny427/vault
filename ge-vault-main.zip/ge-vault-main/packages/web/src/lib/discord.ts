export function isValidDiscordWebhook(url: string): boolean {
  if (!url) {
    return false;
  }
  try {
    const parsed = new URL(url);
    return (
      (parsed.hostname === 'discord.com' || parsed.hostname.endsWith('.discord.com')) &&
      parsed.pathname.startsWith('/api/webhooks/')
    );
  } catch {
    return false;
  }
}
