/**
 * Parse price input with k/m/b suffixes
 * Examples:
 *   "1000" -> 1000
 *   "1k" -> 1000
 *   "1.5k" -> 1500
 *   "1m" -> 1000000
 *   "1.5m" -> 1500000
 *   "1b" -> 1000000000
 *   "1.5b" -> 1500000000
 *   "100k" -> 100000
 */
export function parsePrice(input: string): number | null {
  if (!input) return null

  // Remove commas and spaces
  const cleaned = input.trim().toLowerCase().replace(/,/g, '')

  // Check for k (thousands), m (millions), or b (billions) suffix
  const kMatch = cleaned.match(/^(\d+(?:\.\d+)?)\s*k$/)
  const mMatch = cleaned.match(/^(\d+(?:\.\d+)?)\s*m$/)
  const bMatch = cleaned.match(/^(\d+(?:\.\d+)?)\s*b$/)

  if (kMatch) {
    return Math.floor(parseFloat(kMatch[1]) * 1000)
  }

  if (mMatch) {
    return Math.floor(parseFloat(mMatch[1]) * 1000000)
  }

  if (bMatch) {
    return Math.floor(parseFloat(bMatch[1]) * 1000000000)
  }

  // Try to parse as regular number
  const num = parseFloat(cleaned)
  if (isNaN(num)) return null

  return Math.floor(num)
}

/**
 * Format price for display
 */
export function formatPrice(price: number): string {
  if (price >= 1000000000) {
    const b = price / 1000000000
    return `${b % 1 === 0 ? b : b.toFixed(1)}B`
  }

  if (price >= 1000000) {
    const m = price / 1000000
    return `${m % 1 === 0 ? m : m.toFixed(1)}M`
  }

  if (price >= 1000) {
    const k = price / 1000
    return `${k % 1 === 0 ? k : k.toFixed(1)}K`
  }

  return price.toLocaleString()
}

/**
 * Validate price input (allows numbers, k, m, b suffixes, and decimals)
 */
export function isValidPriceInput(input: string): boolean {
  if (!input) return false

  const cleaned = input.trim().toLowerCase().replace(/,/g, '')

  // Allow numbers with optional k/m/b suffix and decimals
  return /^\d+(?:\.\d+)?\s*[kmb]?$/.test(cleaned)
}
