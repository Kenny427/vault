import { describe, it, expect } from 'vitest'
import {
  isItemTaxExempt,
  calculateGETax,
  calculateNetProceeds,
  calculateProfitAfterTax,
} from '../geTax'

describe('geTax', () => {
  describe('isItemTaxExempt', () => {
    it('should return true for exempt items', () => {
      expect(isItemTaxExempt(13190)).toBe(true) // Old school bond
      expect(isItemTaxExempt(3010)).toBe(true) // Energy potion(4)
      expect(isItemTaxExempt(882)).toBe(true) // Bronze arrow
      expect(isItemTaxExempt(363)).toBe(true) // Bass
      expect(isItemTaxExempt(8011)).toBe(true) // Ardougne teleport
      expect(isItemTaxExempt(1755)).toBe(true) // Chisel
    })

    it('should return false for non-exempt items', () => {
      expect(isItemTaxExempt(1234)).toBe(false)
      expect(isItemTaxExempt(9999)).toBe(false)
      expect(isItemTaxExempt(0)).toBe(false)
    })
  })

  describe('calculateGETax', () => {
    it('should return 0 for exempt items', () => {
      expect(calculateGETax(1000000, 1, 13190)).toBe(0) // Bond
      expect(calculateGETax(500000, 10, 3010)).toBe(0) // Energy potion
    })

    it('should return 0 for prices below 50 GP', () => {
      expect(calculateGETax(49, 1)).toBe(0)
      expect(calculateGETax(25, 100)).toBe(0)
      expect(calculateGETax(1, 1000)).toBe(0)
    })

    it('should calculate 2% tax for normal items', () => {
      expect(calculateGETax(1000, 1)).toBe(20) // 1000 * 0.02 = 20
      expect(calculateGETax(50000, 1)).toBe(1000) // 50000 * 0.02 = 1000
      expect(calculateGETax(100000, 1)).toBe(2000) // 100000 * 0.02 = 2000
    })

    it('should round down tax amounts', () => {
      expect(calculateGETax(55, 1)).toBe(1) // 55 * 0.02 = 1.1 -> 1
      expect(calculateGETax(99, 1)).toBe(1) // 99 * 0.02 = 1.98 -> 1
      expect(calculateGETax(149, 1)).toBe(2) // 149 * 0.02 = 2.98 -> 2
    })

    it('should cap tax at 5M per item', () => {
      expect(calculateGETax(300000000, 1)).toBe(5000000) // 300M * 0.02 = 6M, capped at 5M
      expect(calculateGETax(1000000000, 1)).toBe(5000000) // 1B * 0.02 = 20M, capped at 5M
      expect(calculateGETax(250000000, 1)).toBe(5000000) // 250M * 0.02 = 5M (exactly at cap)
    })

    it('should multiply tax by quantity', () => {
      expect(calculateGETax(1000, 10)).toBe(200) // 20 * 10 = 200
      expect(calculateGETax(100000, 5)).toBe(10000) // 2000 * 5 = 10000
      expect(calculateGETax(300000000, 3)).toBe(15000000) // 5M * 3 = 15M
    })

    it('should handle edge cases', () => {
      expect(calculateGETax(0, 1)).toBe(0) // Zero price
      expect(calculateGETax(1000, 0)).toBe(0) // Zero quantity
      expect(calculateGETax(0, 0)).toBe(0) // Both zero
    })

    it('should handle negative values gracefully', () => {
      // While these shouldn't happen in practice, the function should handle them
      expect(calculateGETax(-100, 1)).toBe(0)
      expect(calculateGETax(1000, -1)).toBe(-20) // Negative quantity results in negative tax
    })
  })

  describe('calculateNetProceeds', () => {
    it('should return gross proceeds for exempt items', () => {
      expect(calculateNetProceeds(1000000, 1, 13190)).toBe(1000000)
      expect(calculateNetProceeds(500000, 10, 3010)).toBe(5000000)
    })

    it('should return gross proceeds for prices below 50 GP', () => {
      expect(calculateNetProceeds(49, 1)).toBe(49)
      expect(calculateNetProceeds(25, 100)).toBe(2500)
    })

    it('should deduct tax from gross proceeds', () => {
      expect(calculateNetProceeds(1000, 1)).toBe(980) // 1000 - 20 = 980
      expect(calculateNetProceeds(100000, 1)).toBe(98000) // 100000 - 2000 = 98000
      expect(calculateNetProceeds(100000, 10)).toBe(980000) // 1000000 - 20000 = 980000
    })

    it('should handle items at tax cap', () => {
      const proceeds = calculateNetProceeds(300000000, 1)
      expect(proceeds).toBe(295000000) // 300M - 5M = 295M
    })
  })

  describe('calculateProfitAfterTax', () => {
    it('should calculate profit correctly for exempt items', () => {
      const result = calculateProfitAfterTax(900000, 1000000, 1, 13190)
      expect(result.totalCost).toBe(900000)
      expect(result.grossValue).toBe(1000000)
      expect(result.tax).toBe(0)
      expect(result.netValue).toBe(1000000)
      expect(result.profit).toBe(100000)
      expect(result.profitPercentage).toBeCloseTo(11.11, 1)
      expect(result.isTaxExempt).toBe(true)
    })

    it('should calculate profit correctly for taxed items', () => {
      const result = calculateProfitAfterTax(900000, 1000000, 1)
      expect(result.totalCost).toBe(900000)
      expect(result.grossValue).toBe(1000000)
      expect(result.tax).toBe(20000) // 1M * 0.02
      expect(result.netValue).toBe(980000) // 1M - 20K
      expect(result.profit).toBe(80000) // 980K - 900K
      expect(result.profitPercentage).toBeCloseTo(8.89, 1)
      expect(result.isTaxExempt).toBe(false)
    })

    it('should calculate loss correctly', () => {
      const result = calculateProfitAfterTax(1000000, 900000, 1)
      expect(result.totalCost).toBe(1000000)
      expect(result.grossValue).toBe(900000)
      expect(result.tax).toBe(18000) // 900K * 0.02
      expect(result.netValue).toBe(882000) // 900K - 18K
      expect(result.profit).toBe(-118000) // 882K - 1M (loss)
      expect(result.profitPercentage).toBeCloseTo(-11.8, 1)
    })

    it('should handle multiple quantity', () => {
      const result = calculateProfitAfterTax(100000, 150000, 10)
      expect(result.totalCost).toBe(1000000) // 100K * 10
      expect(result.grossValue).toBe(1500000) // 150K * 10
      expect(result.tax).toBe(30000) // 3K per item * 10
      expect(result.netValue).toBe(1470000)
      expect(result.profit).toBe(470000)
      expect(result.profitPercentage).toBe(47)
    })

    it('should handle items at tax cap', () => {
      const result = calculateProfitAfterTax(280000000, 300000000, 1)
      expect(result.totalCost).toBe(280000000)
      expect(result.grossValue).toBe(300000000)
      expect(result.tax).toBe(5000000) // Capped at 5M
      expect(result.netValue).toBe(295000000)
      expect(result.profit).toBe(15000000)
      expect(result.profitPercentage).toBeCloseTo(5.36, 1)
    })

    it('should handle zero cost edge case', () => {
      const result = calculateProfitAfterTax(0, 100000, 1)
      expect(result.totalCost).toBe(0)
      expect(result.profit).toBe(98000) // 100K - 2K tax
      expect(result.profitPercentage).toBe(0) // Avoid division by zero
    })

    it('should calculate profit percentage correctly for breakeven', () => {
      const result = calculateProfitAfterTax(100000, 102041, 1) // After tax, should be ~100K
      expect(result.profit).toBeCloseTo(0, -2) // Allow some rounding
      expect(result.profitPercentage).toBeCloseTo(0, 0)
    })
  })
})
