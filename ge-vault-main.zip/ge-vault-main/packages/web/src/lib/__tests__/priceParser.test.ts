import { describe, it, expect } from 'vitest'
import { parsePrice, formatPrice, isValidPriceInput } from '../priceParser'

describe('priceParser', () => {
  describe('parsePrice', () => {
    it('should parse basic numbers', () => {
      expect(parsePrice('1000')).toBe(1000)
      expect(parsePrice('500')).toBe(500)
      expect(parsePrice('0')).toBe(0)
      expect(parsePrice('999999')).toBe(999999)
    })

    it('should parse thousands (k)', () => {
      expect(parsePrice('1k')).toBe(1000)
      expect(parsePrice('1K')).toBe(1000)
      expect(parsePrice('1.5k')).toBe(1500)
      expect(parsePrice('100k')).toBe(100000)
      expect(parsePrice('2.5k')).toBe(2500)
      expect(parsePrice('0.5k')).toBe(500)
    })

    it('should parse millions (m)', () => {
      expect(parsePrice('1m')).toBe(1000000)
      expect(parsePrice('1M')).toBe(1000000)
      expect(parsePrice('1.5m')).toBe(1500000)
      expect(parsePrice('2m')).toBe(2000000)
      expect(parsePrice('10m')).toBe(10000000)
      expect(parsePrice('0.1m')).toBe(100000)
    })

    it('should parse billions (b)', () => {
      expect(parsePrice('1b')).toBe(1000000000)
      expect(parsePrice('1B')).toBe(1000000000)
      expect(parsePrice('1.5b')).toBe(1500000000)
      expect(parsePrice('5b')).toBe(5000000000)
      expect(parsePrice('10.5b')).toBe(10500000000)
      expect(parsePrice('0.5b')).toBe(500000000)
    })

    it('should handle numbers with commas', () => {
      expect(parsePrice('1,000')).toBe(1000)
      expect(parsePrice('1,500,000')).toBe(1500000)
      expect(parsePrice('10,000,000')).toBe(10000000)
    })

    it('should handle numbers with spaces', () => {
      expect(parsePrice('1 k')).toBe(1000)
      expect(parsePrice('1.5 m')).toBe(1500000)
      expect(parsePrice('  2b  ')).toBe(2000000000)
      expect(parsePrice(' 1000 ')).toBe(1000)
    })

    it('should floor decimal values', () => {
      expect(parsePrice('1.9k')).toBe(1900)
      expect(parsePrice('1.999k')).toBe(1999)
      expect(parsePrice('1.1m')).toBe(1100000)
      expect(parsePrice('999.9')).toBe(999)
    })

    it('should return null for invalid inputs', () => {
      expect(parsePrice('')).toBeNull()
      expect(parsePrice('abc')).toBeNull()
      expect(parsePrice('km')).toBeNull()
      expect(parsePrice('m')).toBeNull()
      expect(parsePrice('k')).toBeNull()
      expect(parsePrice('b')).toBeNull()
      expect(parsePrice('!@#')).toBeNull()
    })

    it('should handle edge cases', () => {
      expect(parsePrice('0k')).toBe(0)
      expect(parsePrice('0m')).toBe(0)
      expect(parsePrice('0.0k')).toBe(0)
    })
  })

  describe('formatPrice', () => {
    it('should format numbers below 1000 as is', () => {
      expect(formatPrice(500)).toBe('500')
      expect(formatPrice(999)).toBe('999')
      expect(formatPrice(0)).toBe('0')
      expect(formatPrice(1)).toBe('1')
    })

    it('should format thousands with K suffix', () => {
      expect(formatPrice(1000)).toBe('1K')
      expect(formatPrice(1500)).toBe('1.5K')
      expect(formatPrice(100000)).toBe('100K')
      expect(formatPrice(2500)).toBe('2.5K')
      expect(formatPrice(10000)).toBe('10K')
    })

    it('should format millions with M suffix', () => {
      expect(formatPrice(1000000)).toBe('1M')
      expect(formatPrice(1500000)).toBe('1.5M')
      expect(formatPrice(2000000)).toBe('2M')
      expect(formatPrice(10000000)).toBe('10M')
      expect(formatPrice(1100000)).toBe('1.1M')
    })

    it('should format billions with B suffix', () => {
      expect(formatPrice(1000000000)).toBe('1B')
      expect(formatPrice(1500000000)).toBe('1.5B')
      expect(formatPrice(5000000000)).toBe('5B')
      expect(formatPrice(10500000000)).toBe('10.5B')
    })

    it('should show whole numbers without decimals', () => {
      expect(formatPrice(1000)).toBe('1K')
      expect(formatPrice(2000000)).toBe('2M')
      expect(formatPrice(3000000000)).toBe('3B')
    })

    it('should show one decimal place when needed', () => {
      expect(formatPrice(1500)).toBe('1.5K')
      expect(formatPrice(1500000)).toBe('1.5M')
      expect(formatPrice(1500000000)).toBe('1.5B')
    })
  })

  describe('isValidPriceInput', () => {
    it('should accept valid numbers', () => {
      expect(isValidPriceInput('1000')).toBe(true)
      expect(isValidPriceInput('500')).toBe(true)
      expect(isValidPriceInput('0')).toBe(true)
    })

    it('should accept valid k/m/b suffixes', () => {
      expect(isValidPriceInput('1k')).toBe(true)
      expect(isValidPriceInput('1K')).toBe(true)
      expect(isValidPriceInput('1m')).toBe(true)
      expect(isValidPriceInput('1M')).toBe(true)
      expect(isValidPriceInput('1b')).toBe(true)
      expect(isValidPriceInput('1B')).toBe(true)
    })

    it('should accept decimals', () => {
      expect(isValidPriceInput('1.5k')).toBe(true)
      expect(isValidPriceInput('2.5m')).toBe(true)
      expect(isValidPriceInput('0.5b')).toBe(true)
      expect(isValidPriceInput('999.9')).toBe(true)
    })

    it('should accept numbers with spaces', () => {
      expect(isValidPriceInput('1 k')).toBe(true)
      expect(isValidPriceInput(' 1000 ')).toBe(true)
    })

    it('should accept numbers with commas', () => {
      expect(isValidPriceInput('1,000')).toBe(true)
      expect(isValidPriceInput('1,500,000')).toBe(true)
    })

    it('should reject invalid inputs', () => {
      expect(isValidPriceInput('')).toBe(false)
      expect(isValidPriceInput('abc')).toBe(false)
      expect(isValidPriceInput('km')).toBe(false)
      expect(isValidPriceInput('k')).toBe(false)
      expect(isValidPriceInput('m')).toBe(false)
      expect(isValidPriceInput('!@#')).toBe(false)
      expect(isValidPriceInput('1.2.3k')).toBe(false)
      expect(isValidPriceInput('1kk')).toBe(false)
    })
  })

  describe('parsePrice and formatPrice round trip', () => {
    it('should handle round trip conversions', () => {
      const testCases = [
        { input: '1k', formatted: '1K' },
        { input: '1.5m', formatted: '1.5M' },
        { input: '2b', formatted: '2B' },
        { input: '100k', formatted: '100K' },
      ]

      testCases.forEach(({ input, formatted }) => {
        const parsed = parsePrice(input)
        expect(parsed).not.toBeNull()
        if (parsed !== null) {
          expect(formatPrice(parsed)).toBe(formatted)
        }
      })
    })
  })
})
