/**
 * Grand Exchange Tax Calculator
 *
 * As of May 29, 2025, the GE charges a 2% convenience fee (tax) on most transactions,
 * capped at 5,000,000 GP per item. Some items are exempt from this tax.
 *
 * Tax rounds down to the nearest whole number, so items sold for below 50 coins have no tax.
 */

// Items exempt from GE tax
const TAX_EXEMPT_ITEM_IDS = new Set([
  // Old school bonds
  13190, // Old school bond

  // Energy potions
  3010, // Energy potion(4)
  3012, // Energy potion(3)
  3014, // Energy potion(2)
  3016, // Energy potion(1)

  // Low level combat consumables
  882,   // Bronze arrow
  806,   // Bronze dart
  884,   // Iron arrow
  807,   // Iron dart
  558,   // Mind rune
  886,   // Steel arrow
  808,   // Steel dart

  // Low level food
  363,   // Bass
  2309,  // Bread
  1891,  // Cake
  2140,  // Cooked chicken
  2142,  // Cooked meat
  347,   // Herring
  379,   // Lobster
  355,   // Mackerel
  2327,  // Meat pie
  351,   // Pike
  329,   // Salmon
  315,   // Shrimps
  361,   // Tuna

  // Teleport items
  8011,  // Ardougne teleport
  8010,  // Camelot teleport
  30186, // Civitas illa fortis teleport
  8009,  // Falador teleport
  3853,  // Games necklace (8)
  19619, // Kourend castle teleport
  8008,  // Lumbridge teleport
  2552,  // Ring of dueling (8)
  8013,  // Teleport to house
  8007,  // Varrock teleport

  // Tools
  1755,  // Chisel
  5325,  // Gardening trowel
  1785,  // Glassblowing pipe
  2347,  // Hammer
  1733,  // Needle
  233,   // Pestle and mortar
  5341,  // Rake
  8794,  // Saw
  5329,  // Secateurs
  5343,  // Seed dibber
  5343,  // Shears
  952,   // Spade
  5331,  // Watering can (0)
])

const TAX_RATE = 0.02 // 2%
const TAX_CAP_PER_ITEM = 5_000_000 // 5M GP max per item

/**
 * Check if an item is exempt from GE tax
 */
export function isItemTaxExempt(itemId: number): boolean {
  return TAX_EXEMPT_ITEM_IDS.has(itemId)
}

/**
 * Calculate the GE tax for selling an item
 * @param price - The price per item in GP
 * @param quantity - Number of items being sold
 * @param itemId - The item ID (to check if exempt)
 * @returns The total tax amount in GP
 */
export function calculateGETax(price: number, quantity: number, itemId?: number): number {
  // Check if item is exempt
  if (itemId && isItemTaxExempt(itemId)) {
    return 0
  }

  // Items below 50 GP have no tax (rounds down)
  if (price < 50) {
    return 0
  }

  // Calculate tax per item (2% rounded down)
  const taxPerItem = Math.min(
    Math.floor(price * TAX_RATE),
    TAX_CAP_PER_ITEM
  )

  return taxPerItem * quantity
}

/**
 * Calculate net proceeds after GE tax
 * @param price - The price per item in GP
 * @param quantity - Number of items being sold
 * @param itemId - The item ID (to check if exempt)
 * @returns The net amount received after tax
 */
export function calculateNetProceeds(price: number, quantity: number, itemId?: number): number {
  const grossProceeds = price * quantity
  const tax = calculateGETax(price, quantity, itemId)
  return grossProceeds - tax
}

/**
 * Calculate profit/loss after GE tax
 * @param buyPrice - The price paid per item
 * @param sellPrice - The current market price per item
 * @param quantity - Number of items
 * @param itemId - The item ID (to check if exempt)
 * @returns Object with profit details including tax
 */
export function calculateProfitAfterTax(
  buyPrice: number,
  sellPrice: number,
  quantity: number,
  itemId?: number
) {
  const totalCost = buyPrice * quantity
  const grossValue = sellPrice * quantity
  const tax = calculateGETax(sellPrice, quantity, itemId)
  const netValue = grossValue - tax
  const profit = netValue - totalCost
  const profitPercentage = totalCost > 0 ? (profit / totalCost) * 100 : 0

  return {
    totalCost,
    grossValue,
    tax,
    netValue,
    profit,
    profitPercentage,
    isTaxExempt: itemId ? isItemTaxExempt(itemId) : false
  }
}
