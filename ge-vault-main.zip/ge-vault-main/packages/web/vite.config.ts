import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import path from 'path'

// https://vite.dev/config/
export default defineConfig({
  plugins: [react()],
  resolve: {
    alias: {
      '@ge-vault/shared': path.resolve(__dirname, '../shared/src')
    }
  },
  server: {
    open: true, // Auto-open browser on server start
    port: 5173,
    hmr: {
      overlay: true, // Show error overlay on HMR errors
    },
  },
})
