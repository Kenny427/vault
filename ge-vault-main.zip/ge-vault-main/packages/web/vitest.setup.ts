import { expect, afterEach, vi } from 'vitest'
import { cleanup } from '@testing-library/react'
import '@testing-library/jest-dom/vitest'

// Clean up after each test to prevent test pollution
afterEach(() => {
  cleanup()
  vi.clearAllMocks()
})

// Mock window.alert and window.confirm
global.alert = vi.fn()
global.confirm = vi.fn()

// Mock fetch if not already mocked
if (!global.fetch) {
  global.fetch = vi.fn()
}

// Mock matchMedia for components that use it
Object.defineProperty(window, 'matchMedia', {
  writable: true,
  value: vi.fn().mockImplementation(query => ({
    matches: false,
    media: query,
    onchange: null,
    addListener: vi.fn(),
    removeListener: vi.fn(),
    addEventListener: vi.fn(),
    removeEventListener: vi.fn(),
    dispatchEvent: vi.fn(),
  })),
})
