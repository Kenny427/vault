# GE Vault Worker - Price Updates & Alert Processing

Cloudflare Worker that automatically updates OSRS item prices and processes Discord price alerts.

## Features

### Price Updates
- Runs automatically every 30 minutes
- Fetches latest prices from OSRS Wiki API (~4,500 items)
- Updates `wiki_latest_prices` table
- Stores historical prices in `price_history` table
- Batch processing for efficiency (1000 records at a time)

### Alert Processing (Premium Feature)
- Checks all active price alerts every 30 minutes
- Supports absolute and percentage-based alerts
- Sends Discord notifications via:
  - **Bot DM** - Direct messages to users who joined Discord server
  - **Webhook** - Posts to custom Discord channels
- Refreshes expiring Discord OAuth tokens automatically
- Logs all triggered alerts to `alert_history` table
- Handles one-shot, recurring, and cooldown alert behaviors

## Setup

### 1. Run Database Migrations

Run these SQL migrations in your Supabase SQL Editor (https://supabase.com/dashboard → SQL Editor):

1. `price_history_migration.sql` - Price tracking tables
2. `subscriptions_migration.sql` - Premium user subscriptions
3. `discord_alerts_migration.sql` - Alert system (user_alerts, discord_connections, alert_history, oauth_states)

### 2. Install Dependencies

```bash
cd worker
npm install
```

### 3. Configure Worker Secrets

Set your credentials as encrypted Worker secrets:

```bash
# Supabase credentials
echo "https://your-project.supabase.co" | npx wrangler secret put SUPABASE_URL
echo "your_service_role_key" | npx wrangler secret put SUPABASE_SERVICE_KEY

# Discord credentials (for alert notifications)
echo "your_bot_token" | npx wrangler secret put DISCORD_BOT_TOKEN
echo "your_client_id" | npx wrangler secret put DISCORD_CLIENT_ID
echo "your_client_secret" | npx wrangler secret put DISCORD_CLIENT_SECRET

# Verify all secrets are set
npx wrangler secret list
```

### 4. Deploy the Worker

```bash
npm run deploy
```

The worker will now run automatically every 30 minutes, updating prices and processing alerts!

## Usage

### View logs

```bash
npm run tail
```

### Manually trigger (for testing)

```bash
curl -X POST https://ge-vault-price-updater.YOUR_ACCOUNT.workers.dev
```

Or trigger via Cloudflare dashboard:
1. Go to https://dash.cloudflare.com → Workers & Pages
2. Click `ge-vault-price-updater`
3. Click **Triggers** → **Cron Triggers**
4. Click **Send test event**

### Local development

```bash
npm run dev
```

## Cron Schedule

**Current:** Every 30 minutes (`*/30 * * * *`)

The worker runs every 30 minutes to:
1. Update item prices from OSRS Wiki API
2. Check all active price alerts
3. Send Discord notifications for triggered alerts
4. Refresh expiring Discord OAuth tokens

To change the schedule, edit `wrangler.toml`:

```toml
[triggers]
crons = ["*/30 * * * *"]  # Every 30 minutes (current)
# crons = ["0 * * * *"]    # Every hour
# crons = ["0 0 * * *"]    # Daily at midnight
# crons = ["0 */6 * * *"]  # Every 6 hours
```

## Data Flow

### Price Updates
1. **Fetch** - OSRS Wiki API provides latest prices (~4,500 items)
2. **Transform** - Convert to database format with high/low/timestamp
3. **Update** - Upsert into `wiki_latest_prices` table
4. **Archive** - Insert snapshots into `price_history` for trend analysis
5. **Cleanup** - Delete price history older than 30 days (retention policy)

### Alert Processing
1. **Fetch Alerts** - Query all active alerts for premium users
2. **Refresh Tokens** - Auto-refresh Discord tokens expiring within 7 days
3. **Check Conditions** - Evaluate price vs target for each alert:
   - **Absolute**: Current price >= target (for "up") or <= target (for "down")
   - **Percentage**: Calculate % change from baseline price
4. **Send Notifications** - Discord bot DM or webhook POST
5. **Update Alerts** - Deactivate one-shot, update trigger count/timestamp
6. **Log History** - Record all triggers in `alert_history` table

## Database Schema

### price_history

| Column | Type | Description |
|--------|------|-------------|
| id | BIGSERIAL | Primary key |
| item_id | INT | References items(id) |
| price | BIGINT | Price in GP |
| price_type | VARCHAR(10) | 'high' or 'low' |
| timestamp | TIMESTAMPTZ | When price was recorded |

**Indexes:**
- `(item_id, timestamp DESC)` - For querying item price history
- `(timestamp DESC)` - For recent prices

## Cost

**Cloudflare Workers Free Tier:**
- 100,000 requests per day
- This worker uses ~1 request per day
- **Cost: $0**

**Upgrade to Paid ($5/mo) if:**
- Running cron more than 3 times per day
- Or if you exceed 100k total requests/day across all workers

## Monitoring

**View worker stats:**
https://dash.cloudflare.com → Workers & Pages → ge-vault-price-updater → Metrics

**Check logs:**
```bash
npm run tail
```

**Verify prices are updating:**
```sql
-- Run in Supabase SQL Editor
SELECT
    updated_at,
    COUNT(*) as items_with_prices
FROM item_prices_current
GROUP BY updated_at
ORDER BY updated_at DESC
LIMIT 10;
```

## Troubleshooting

**Worker not running:**
- Check cron triggers are enabled in Cloudflare dashboard
- Verify secrets are set: `npx wrangler secret list`
- Check logs: `npm run tail`

**Prices not updating:**
- Manually trigger to test: `curl -X POST https://...`
- Check Worker logs for errors
- Verify Supabase credentials are correct

**Historical data not saving:**
- Verify `price_history` table exists in Supabase
- Check table has correct columns and indexes
- Review Worker logs for insert errors

## Storage & Retention

### Current Retention Policy
- **30 days** of historical data retained (fits Supabase free tier)
- Automatic cleanup runs on every worker execution
- Older data is permanently deleted

### Storage Estimates (Based on Actual Usage)
- **Per hour:** ~5,400 records (estimated from actual data)
- **Per day:** ~130,000 records
- **30 days:** ~3.9M records (~390 MB - fits in free tier)
- **90 days:** ~11.7M records (~1.2 GB - requires paid tier)

### Adjust Retention Period
Edit `RETENTION_DAYS` in [src/index.ts](src/index.ts:147):
```typescript
const RETENTION_DAYS = 30 // Free tier: 30, Paid tier: 90-365
```

### Future: Premium Tier Retention
- **Free users:** 30 days of history
- **Premium users:** 90-365 days of history
- Implementation: Pass user tier to worker or query based on subscription

## Discord Bot Setup

To enable Discord notifications, you need to create a Discord bot:

1. Go to https://discord.com/developers/applications
2. Click **New Application**, name it "GE Vault"
3. Go to **Bot** tab → **Add Bot**
4. Copy the **Bot Token** (this is your DISCORD_BOT_TOKEN)
5. Go to **OAuth2** tab → **General**
6. Copy **Client ID** and **Client Secret**
7. Set required scopes: `identify` (for user OAuth)
8. Create a Discord server for your users
9. Invite your bot to the server (requires MANAGE_SERVER permission)
10. Set all three secrets in worker using commands above

## Testing Alerts

### Test Bot DM Notification
```bash
# In app directory
npx tsx scripts/test-bot-dm-alert.ts
```

### Test Webhook Notification
```bash
# In app directory
npx tsx scripts/test-webhook-alert.ts
```

### Manual Worker Trigger
```bash
# In worker directory
npm run tail  # Watch logs in one terminal

# Then trigger manually via Cloudflare dashboard:
# Workers & Pages → ge-vault-price-updater → Triggers → Send test event
```

## Future Improvements

- Add retry logic for failed API requests and Discord notifications
- Implement notification delivery tracking and failure alerts
- Add metrics dashboard (items updated, alerts processed, execution time)
- Compress historical data (daily averages after 30 days)
- Support additional notification channels (email, webhooks, Telegram)
