import { describe, it, expect } from 'vitest'

// Import the types from the main app
interface WikiLatestPrice {
  high: number | null
  highTime: number | null
  low: number | null
  lowTime: number | null
}

interface UserAlert {
  id: string
  item_id: string
  item_name: string
  alert_type: 'absolute' | 'percentage_change'
  price_direction: 'up' | 'down' | 'either'
  target_price?: number
  baseline_price?: number
  percentage_threshold?: number
  notification_type: 'bot_dm' | 'webhook'
  behavior: 'one_shot' | 'recurring' | 'cooldown'
  trigger_count: number
  discord_connections?: any
}

// This is the function we're testing - extracted from worker/src/index.ts
function checkAlertCondition(alert: UserAlert, price: WikiLatestPrice): boolean {
  const currentPrice = alert.price_direction === 'up' ? price.high : price.low

  if (currentPrice === null) return false

  if (alert.alert_type === 'absolute' && alert.target_price) {
    if (alert.price_direction === 'up') return currentPrice >= alert.target_price
    if (alert.price_direction === 'down') return currentPrice <= alert.target_price
    // 'either' doesn't make sense for absolute price alerts - would need historical data
    // to detect if price "crossed" the target. Treating as invalid for now.
    return false
  }

  if (alert.alert_type === 'percentage_change' && alert.baseline_price && alert.percentage_threshold) {
    const percentChange = ((currentPrice - alert.baseline_price) / alert.baseline_price) * 100

    if (alert.price_direction === 'up') {
      return percentChange >= alert.percentage_threshold
    }
    if (alert.price_direction === 'down') {
      return percentChange <= -Math.abs(alert.percentage_threshold)
    }
    return Math.abs(percentChange) >= Math.abs(alert.percentage_threshold)
  }

  return false
}

describe('Worker Alert Logic', () => {
  describe('checkAlertCondition - Absolute Price Alerts', () => {
    describe('Price goes UP', () => {
      it('should trigger when high price meets target', () => {
        const alert: UserAlert = {
          id: '1',
          item_id: '1234',
          item_name: 'Test Item',
          alert_type: 'absolute',
          price_direction: 'up',
          target_price: 1000000,
          notification_type: 'bot_dm',
          behavior: 'one_shot',
          trigger_count: 0
        }

        const price: WikiLatestPrice = {
          high: 1000000,
          highTime: Date.now(),
          low: 950000,
          lowTime: Date.now()
        }

        expect(checkAlertCondition(alert, price)).toBe(true)
      })

      it('should trigger when high price exceeds target', () => {
        const alert: UserAlert = {
          id: '1',
          item_id: '1234',
          item_name: 'Test Item',
          alert_type: 'absolute',
          price_direction: 'up',
          target_price: 1000000,
          notification_type: 'bot_dm',
          behavior: 'one_shot',
          trigger_count: 0
        }

        const price: WikiLatestPrice = {
          high: 1100000,
          highTime: Date.now(),
          low: 950000,
          lowTime: Date.now()
        }

        expect(checkAlertCondition(alert, price)).toBe(true)
      })

      it('should not trigger when high price is below target', () => {
        const alert: UserAlert = {
          id: '1',
          item_id: '1234',
          item_name: 'Test Item',
          alert_type: 'absolute',
          price_direction: 'up',
          target_price: 1000000,
          notification_type: 'bot_dm',
          behavior: 'one_shot',
          trigger_count: 0
        }

        const price: WikiLatestPrice = {
          high: 990000,
          highTime: Date.now(),
          low: 950000,
          lowTime: Date.now()
        }

        expect(checkAlertCondition(alert, price)).toBe(false)
      })

      it('should not trigger when high price is null', () => {
        const alert: UserAlert = {
          id: '1',
          item_id: '1234',
          item_name: 'Test Item',
          alert_type: 'absolute',
          price_direction: 'up',
          target_price: 1000000,
          notification_type: 'bot_dm',
          behavior: 'one_shot',
          trigger_count: 0
        }

        const price: WikiLatestPrice = {
          high: null,
          highTime: null,
          low: 950000,
          lowTime: Date.now()
        }

        expect(checkAlertCondition(alert, price)).toBe(false)
      })
    })

    describe('Price goes DOWN', () => {
      it('should trigger when low price meets target', () => {
        const alert: UserAlert = {
          id: '1',
          item_id: '1234',
          item_name: 'Test Item',
          alert_type: 'absolute',
          price_direction: 'down',
          target_price: 500000,
          notification_type: 'bot_dm',
          behavior: 'one_shot',
          trigger_count: 0
        }

        const price: WikiLatestPrice = {
          high: 550000,
          highTime: Date.now(),
          low: 500000,
          lowTime: Date.now()
        }

        expect(checkAlertCondition(alert, price)).toBe(true)
      })

      it('should trigger when low price falls below target', () => {
        const alert: UserAlert = {
          id: '1',
          item_id: '1234',
          item_name: 'Test Item',
          alert_type: 'absolute',
          price_direction: 'down',
          target_price: 500000,
          notification_type: 'bot_dm',
          behavior: 'one_shot',
          trigger_count: 0
        }

        const price: WikiLatestPrice = {
          high: 550000,
          highTime: Date.now(),
          low: 450000,
          lowTime: Date.now()
        }

        expect(checkAlertCondition(alert, price)).toBe(true)
      })

      it('should not trigger when low price is above target', () => {
        const alert: UserAlert = {
          id: '1',
          item_id: '1234',
          item_name: 'Test Item',
          alert_type: 'absolute',
          price_direction: 'down',
          target_price: 500000,
          notification_type: 'bot_dm',
          behavior: 'one_shot',
          trigger_count: 0
        }

        const price: WikiLatestPrice = {
          high: 550000,
          highTime: Date.now(),
          low: 510000,
          lowTime: Date.now()
        }

        expect(checkAlertCondition(alert, price)).toBe(false)
      })

      it('should not trigger when low price is null', () => {
        const alert: UserAlert = {
          id: '1',
          item_id: '1234',
          item_name: 'Test Item',
          alert_type: 'absolute',
          price_direction: 'down',
          target_price: 500000,
          notification_type: 'bot_dm',
          behavior: 'one_shot',
          trigger_count: 0
        }

        const price: WikiLatestPrice = {
          high: 550000,
          highTime: Date.now(),
          low: null,
          lowTime: null
        }

        expect(checkAlertCondition(alert, price)).toBe(false)
      })
    })

    describe('Price changes EITHER way', () => {
      it('should not trigger for absolute price alerts with either direction', () => {
        const alert: UserAlert = {
          id: '1',
          item_id: '1234',
          item_name: 'Test Item',
          alert_type: 'absolute',
          price_direction: 'either',
          target_price: 1000000,
          notification_type: 'bot_dm',
          behavior: 'one_shot',
          trigger_count: 0
        }

        const price: WikiLatestPrice = {
          high: 1100000,
          highTime: Date.now(),
          low: 900000,
          lowTime: Date.now()
        }

        // Either direction doesn't make sense for absolute alerts
        expect(checkAlertCondition(alert, price)).toBe(false)
      })
    })
  })

  describe('checkAlertCondition - Percentage Change Alerts', () => {
    describe('Price goes UP', () => {
      it('should trigger when percentage increase meets threshold', () => {
        const alert: UserAlert = {
          id: '1',
          item_id: '1234',
          item_name: 'Test Item',
          alert_type: 'percentage_change',
          price_direction: 'up',
          baseline_price: 1000000,
          percentage_threshold: 10,
          notification_type: 'bot_dm',
          behavior: 'one_shot',
          trigger_count: 0
        }

        const price: WikiLatestPrice = {
          high: 1100000, // 10% increase
          highTime: Date.now(),
          low: 1000000,
          lowTime: Date.now()
        }

        expect(checkAlertCondition(alert, price)).toBe(true)
      })

      it('should trigger when percentage increase exceeds threshold', () => {
        const alert: UserAlert = {
          id: '1',
          item_id: '1234',
          item_name: 'Test Item',
          alert_type: 'percentage_change',
          price_direction: 'up',
          baseline_price: 1000000,
          percentage_threshold: 10,
          notification_type: 'bot_dm',
          behavior: 'one_shot',
          trigger_count: 0
        }

        const price: WikiLatestPrice = {
          high: 1200000, // 20% increase
          highTime: Date.now(),
          low: 1000000,
          lowTime: Date.now()
        }

        expect(checkAlertCondition(alert, price)).toBe(true)
      })

      it('should not trigger when percentage increase is below threshold', () => {
        const alert: UserAlert = {
          id: '1',
          item_id: '1234',
          item_name: 'Test Item',
          alert_type: 'percentage_change',
          price_direction: 'up',
          baseline_price: 1000000,
          percentage_threshold: 10,
          notification_type: 'bot_dm',
          behavior: 'one_shot',
          trigger_count: 0
        }

        const price: WikiLatestPrice = {
          high: 1050000, // 5% increase
          highTime: Date.now(),
          low: 1000000,
          lowTime: Date.now()
        }

        expect(checkAlertCondition(alert, price)).toBe(false)
      })

      it('should not trigger on price decrease', () => {
        const alert: UserAlert = {
          id: '1',
          item_id: '1234',
          item_name: 'Test Item',
          alert_type: 'percentage_change',
          price_direction: 'up',
          baseline_price: 1000000,
          percentage_threshold: 10,
          notification_type: 'bot_dm',
          behavior: 'one_shot',
          trigger_count: 0
        }

        const price: WikiLatestPrice = {
          high: 900000, // 10% decrease
          highTime: Date.now(),
          low: 850000,
          lowTime: Date.now()
        }

        expect(checkAlertCondition(alert, price)).toBe(false)
      })
    })

    describe('Price goes DOWN', () => {
      it('should trigger when percentage decrease meets threshold', () => {
        const alert: UserAlert = {
          id: '1',
          item_id: '1234',
          item_name: 'Test Item',
          alert_type: 'percentage_change',
          price_direction: 'down',
          baseline_price: 1000000,
          percentage_threshold: 10,
          notification_type: 'bot_dm',
          behavior: 'one_shot',
          trigger_count: 0
        }

        const price: WikiLatestPrice = {
          high: 950000,
          highTime: Date.now(),
          low: 900000, // 10% decrease
          lowTime: Date.now()
        }

        expect(checkAlertCondition(alert, price)).toBe(true)
      })

      it('should trigger when percentage decrease exceeds threshold', () => {
        const alert: UserAlert = {
          id: '1',
          item_id: '1234',
          item_name: 'Test Item',
          alert_type: 'percentage_change',
          price_direction: 'down',
          baseline_price: 1000000,
          percentage_threshold: 10,
          notification_type: 'bot_dm',
          behavior: 'one_shot',
          trigger_count: 0
        }

        const price: WikiLatestPrice = {
          high: 850000,
          highTime: Date.now(),
          low: 800000, // 20% decrease
          lowTime: Date.now()
        }

        expect(checkAlertCondition(alert, price)).toBe(true)
      })

      it('should not trigger when percentage decrease is below threshold', () => {
        const alert: UserAlert = {
          id: '1',
          item_id: '1234',
          item_name: 'Test Item',
          alert_type: 'percentage_change',
          price_direction: 'down',
          baseline_price: 1000000,
          percentage_threshold: 10,
          notification_type: 'bot_dm',
          behavior: 'one_shot',
          trigger_count: 0
        }

        const price: WikiLatestPrice = {
          high: 980000,
          highTime: Date.now(),
          low: 950000, // 5% decrease
          lowTime: Date.now()
        }

        expect(checkAlertCondition(alert, price)).toBe(false)
      })

      it('should not trigger on price increase', () => {
        const alert: UserAlert = {
          id: '1',
          item_id: '1234',
          item_name: 'Test Item',
          alert_type: 'percentage_change',
          price_direction: 'down',
          baseline_price: 1000000,
          percentage_threshold: 10,
          notification_type: 'bot_dm',
          behavior: 'one_shot',
          trigger_count: 0
        }

        const price: WikiLatestPrice = {
          high: 1100000, // 10% increase
          highTime: Date.now(),
          low: 1050000,
          lowTime: Date.now()
        }

        expect(checkAlertCondition(alert, price)).toBe(false)
      })
    })

    describe('Price changes EITHER way', () => {
      it('should trigger on positive percentage change meeting threshold', () => {
        const alert: UserAlert = {
          id: '1',
          item_id: '1234',
          item_name: 'Test Item',
          alert_type: 'percentage_change',
          price_direction: 'either',
          baseline_price: 1000000,
          percentage_threshold: 10,
          notification_type: 'bot_dm',
          behavior: 'one_shot',
          trigger_count: 0
        }

        const price: WikiLatestPrice = {
          high: 1150000,
          highTime: Date.now(),
          low: 1100000, // 10% increase (for 'either', uses low price)
          lowTime: Date.now()
        }

        // For 'either' direction, uses low price (not 'up')
        // 1100000 is 10% up from 1000000, meets threshold
        expect(checkAlertCondition(alert, price)).toBe(true)
      })

      it('should trigger on negative percentage change meeting threshold', () => {
        const alert: UserAlert = {
          id: '1',
          item_id: '1234',
          item_name: 'Test Item',
          alert_type: 'percentage_change',
          price_direction: 'either',
          baseline_price: 1000000,
          percentage_threshold: 10,
          notification_type: 'bot_dm',
          behavior: 'one_shot',
          trigger_count: 0
        }

        const price: WikiLatestPrice = {
          high: 950000,
          highTime: Date.now(),
          low: 900000, // 10% decrease (abs value meets threshold)
          lowTime: Date.now()
        }

        expect(checkAlertCondition(alert, price)).toBe(true)
      })

      it('should not trigger when absolute change is below threshold', () => {
        const alert: UserAlert = {
          id: '1',
          item_id: '1234',
          item_name: 'Test Item',
          alert_type: 'percentage_change',
          price_direction: 'either',
          baseline_price: 1000000,
          percentage_threshold: 10,
          notification_type: 'bot_dm',
          behavior: 'one_shot',
          trigger_count: 0
        }

        const price: WikiLatestPrice = {
          high: 1030000,
          highTime: Date.now(),
          low: 950000, // 5% decrease (below threshold)
          lowTime: Date.now()
        }

        expect(checkAlertCondition(alert, price)).toBe(false)
      })
    })

    describe('Edge cases', () => {
      it('should handle zero baseline price', () => {
        const alert: UserAlert = {
          id: '1',
          item_id: '1234',
          item_name: 'Test Item',
          alert_type: 'percentage_change',
          price_direction: 'up',
          baseline_price: 0,
          percentage_threshold: 10,
          notification_type: 'bot_dm',
          behavior: 'one_shot',
          trigger_count: 0
        }

        const price: WikiLatestPrice = {
          high: 100000,
          highTime: Date.now(),
          low: 90000,
          lowTime: Date.now()
        }

        // Division by zero -> Infinity, but comparison with NaN/Infinity is tricky
        // The actual behavior: (100000 - 0) / 0 * 100 = Infinity
        // Infinity >= 10 is true, so it should trigger
        // However, this is an edge case that probably shouldn't happen in practice
        expect(checkAlertCondition(alert, price)).toBe(false)
      })

      it('should not trigger when missing baseline_price', () => {
        const alert: UserAlert = {
          id: '1',
          item_id: '1234',
          item_name: 'Test Item',
          alert_type: 'percentage_change',
          price_direction: 'up',
          // baseline_price missing
          percentage_threshold: 10,
          notification_type: 'bot_dm',
          behavior: 'one_shot',
          trigger_count: 0
        }

        const price: WikiLatestPrice = {
          high: 1100000,
          highTime: Date.now(),
          low: 1000000,
          lowTime: Date.now()
        }

        expect(checkAlertCondition(alert, price)).toBe(false)
      })

      it('should not trigger when missing percentage_threshold', () => {
        const alert: UserAlert = {
          id: '1',
          item_id: '1234',
          item_name: 'Test Item',
          alert_type: 'percentage_change',
          price_direction: 'up',
          baseline_price: 1000000,
          // percentage_threshold missing
          notification_type: 'bot_dm',
          behavior: 'one_shot',
          trigger_count: 0
        }

        const price: WikiLatestPrice = {
          high: 1100000,
          highTime: Date.now(),
          low: 1000000,
          lowTime: Date.now()
        }

        expect(checkAlertCondition(alert, price)).toBe(false)
      })

      it('should not trigger when missing target_price for absolute alert', () => {
        const alert: UserAlert = {
          id: '1',
          item_id: '1234',
          item_name: 'Test Item',
          alert_type: 'absolute',
          price_direction: 'up',
          // target_price missing
          notification_type: 'bot_dm',
          behavior: 'one_shot',
          trigger_count: 0
        }

        const price: WikiLatestPrice = {
          high: 1100000,
          highTime: Date.now(),
          low: 1000000,
          lowTime: Date.now()
        }

        expect(checkAlertCondition(alert, price)).toBe(false)
      })
    })
  })
})
