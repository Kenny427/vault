/**
 * GE Vault Price Updater Worker
 *
 * Cloudflare Worker that runs daily to update OSRS item prices
 * - Fetches latest prices from OSRS Wiki API
 * - Updates item_prices_current table
 */

import { createClient } from '@supabase/supabase-js'
import type { UserAlert } from '@ge-vault/shared'

interface Env {
  SUPABASE_URL: string
  SUPABASE_SERVICE_KEY: string
  DISCORD_BOT_TOKEN: string
  DISCORD_CLIENT_ID: string
  DISCORD_CLIENT_SECRET: string
}

interface WikiLatestPrice {
  high: number | null
  highTime: number | null
  low: number | null
  lowTime: number | null
}

interface WikiPriceData {
  [itemId: string]: WikiLatestPrice
}

export default {
  async scheduled(event: ScheduledEvent, env: Env, ctx: ExecutionContext): Promise<void> {
    console.log('🚀 Starting price update job...')

    try {
      // Initialize Supabase client
      const supabase = createClient(env.SUPABASE_URL, env.SUPABASE_SERVICE_KEY)

      // 1. Fetch latest prices from OSRS Wiki API
      console.log('📡 Fetching prices from OSRS Wiki API...')
      const response = await fetch('https://prices.runescape.wiki/api/v1/osrs/latest', {
        headers: {
          'User-Agent': 'GE Vault - OSRS Portfolio Tracker (gevault.com, discord: Mreedon, admin@gevault.com)'
        }
      })

      if (!response.ok) {
        throw new Error(`Wiki API returned ${response.status}: ${response.statusText}`)
      }

      const priceData: { data: WikiPriceData } = await response.json()
      const prices = priceData.data

      const itemCount = Object.keys(prices).length
      console.log(`✅ Fetched prices for ${itemCount} items`)

      // 2. NEW: Check alerts
      await checkAlertsAndNotify(prices, supabase, env);

      // 3. Get valid item IDs from our database
      console.log('📋 Fetching valid item IDs from database...')
      const { data: itemsData, error: itemsError } = await supabase
        .from('items')
        .select('id')

      if (itemsError) {
        throw new Error(`Failed to fetch items: ${itemsError.message}`)
      }

      const validItemIds = new Set(itemsData.map(item => item.id))
      console.log(`✅ Found ${validItemIds.size} valid items in database`)

      // 4. Transform data for database (only for items that exist in our DB)
      const currentPrices = []
      const now = new Date().toISOString()

      for (const [itemId, priceInfo] of Object.entries(prices)) {
        const id = parseInt(itemId)

        // Skip items that don't exist in our database
        if (!validItemIds.has(id)) {
          continue
        }

        // For current prices table
        if (priceInfo.high !== null || priceInfo.low !== null) {
          currentPrices.push({
            item_id: id,
            high_price: priceInfo.high,
            low_price: priceInfo.low,
            updated_at: now
          })
        }
      }

      console.log(`📊 Prepared ${currentPrices.length} current prices`)

      // 5. Update current prices (upsert)
      console.log('💾 Updating current prices...')
      const { error: currentError } = await supabase
        .from('item_prices_current')
        .upsert(currentPrices, { onConflict: 'item_id' })

      if (currentError) {
        throw new Error(`Failed to update current prices: ${currentError.message}`)
      }

      console.log(`✅ Price update job complete!`)
      console.log(`   - ${currentPrices.length} current prices updated`)

    } catch (error) {
      console.error('❌ Price update job failed:', error)
      throw error
    }
  },

  // Handle manual HTTP triggers for testing
  async fetch(request: Request, env: Env): Promise<Response> {
    // Only allow POST requests to manually trigger the job
    if (request.method !== 'POST') {
      return new Response('Method not allowed. Use POST to manually trigger price update.', { status: 405 })
    }

    try {
      // Run the scheduled job manually
      await this.scheduled({} as ScheduledEvent, env, {} as ExecutionContext)

      return new Response('Price update completed successfully', {
        status: 200,
        headers: { 'Content-Type': 'text/plain' }
      })
    } catch (error) {
      return new Response(`Price update failed: ${error}`, {
        status: 500,
        headers: { 'Content-Type': 'text/plain' }
      })
    }
  }
}

async function checkAlertsAndNotify(prices: WikiPriceData, supabase: any, env: Env) {
  const startTime = Date.now();
  console.log('🔔 Checking for price alerts...');

  // Initialize metrics
  const metrics = {
    totalAlerts: 0,
    alertsChecked: 0,
    alertsTriggered: 0,
    notificationsSent: 0,
    notificationsFailed: 0,
    tokensRefreshed: 0,
    errors: [] as string[],
    executionTimeMs: 0
  };

  try {
    // Get all active alerts first
    const { data: alerts, error } = await supabase
      .from('user_alerts')
      .select('*, discord_connections(discord_user_id, token_expires_at, refresh_token)')
      .eq('active', true);

    if (error) {
      const errorMsg = `Failed to fetch alerts: ${error.message}`;
      console.error('❌', errorMsg);
      metrics.errors.push(errorMsg);
      return metrics;
    }

    // Filter for premium users (check subscription status separately)
    if (alerts && alerts.length > 0) {
      const userIds = [...new Set(alerts.map((a: UserAlert) => a.user_id))];
      const { data: subscriptions } = await supabase
        .from('user_subscriptions')
        .select('user_id')
        .in('user_id', userIds)
        .eq('status', 'active');

      const premiumUserIds = new Set(subscriptions?.map((s: { user_id: string }) => s.user_id) || []);

      // Filter alerts to only include premium users
      const premiumAlerts = alerts.filter((a: UserAlert) => premiumUserIds.has(a.user_id));

      if (premiumAlerts.length !== alerts.length) {
        console.log(`ℹ️  Filtered ${alerts.length - premiumAlerts.length} alerts from non-premium users`);
      }

      // Replace alerts with premium-only alerts
      alerts.splice(0, alerts.length, ...premiumAlerts);
    }

    if (!alerts?.length) {
      console.log('ℹ️  No active alerts to check.');
      logMetrics(metrics, startTime);
      return metrics;
    }

    metrics.totalAlerts = alerts.length;
    console.log(`📊 Found ${alerts.length} active alerts to process.`);

    // Check and refresh Discord tokens that are expiring soon (within 1 day)
    const oneDayFromNow = Date.now() + (24 * 60 * 60 * 1000);
    const tokensToRefresh = new Map<string, any>();

    for (const alert of alerts) {
      if (alert.notification_type === 'bot_dm' && alert.discord_connections) {
        const { token_expires_at, refresh_token } = alert.discord_connections;
        if (token_expires_at && refresh_token) {
          const expiryTime = new Date(token_expires_at).getTime();
          if (expiryTime < oneDayFromNow && !tokensToRefresh.has(alert.user_id)) {
            console.log(`🔄 Discord token for user ${alert.user_id} expires soon, refreshing...`);
            tokensToRefresh.set(alert.user_id, refresh_token);
          }
        }
      }
    }

    // Refresh tokens in parallel
    if (tokensToRefresh.size > 0) {
      const refreshResults = await Promise.allSettled(
        Array.from(tokensToRefresh.entries()).map(([userId, refreshToken]) =>
          refreshDiscordToken(userId, refreshToken, supabase, env)
        )
      );
      metrics.tokensRefreshed = refreshResults.filter(r => r.status === 'fulfilled' && r.value === true).length;
    }

    // Filter to only alerts for items we have price data for
    const alertsWithPrices = alerts.filter((alert: UserAlert) => prices[alert.item_id]);
    metrics.alertsChecked = alertsWithPrices.length;

    // Group by item for efficiency
    const alertsByItem: { [key: string]: UserAlert[] } = {};
    alertsWithPrices.forEach((alert: UserAlert) => {
      if (!alertsByItem[alert.item_id]) alertsByItem[alert.item_id] = [];
      alertsByItem[alert.item_id].push(alert);
    });

    // Rate limiting: batch notifications to avoid Discord rate limits
    const notificationQueue: { alert: UserAlert, triggerPrice: number }[] = [];

    // Check each item's alerts
    for (const [itemId, itemAlerts] of Object.entries(alertsByItem)) {
      const price = prices[itemId];

      for (const alert of itemAlerts) {
        try {
          // Check cooldown/one-shot logic
          const { data: shouldCheck, error: rpcError } = await supabase.rpc('should_check_alert', {
            p_alert_id: alert.id,
            p_behavior: alert.behavior,
            p_cooldown_hours: alert.cooldown_hours || 24
          });

          if (rpcError) {
            const errorMsg = `RPC error for alert ${alert.id}: ${rpcError.message}`;
            console.error('⚠️', errorMsg);
            metrics.errors.push(errorMsg);
            continue;
          }

          if (!shouldCheck) continue;

          // Check price condition
          const shouldTrigger = checkAlertCondition(alert, price);

          if (shouldTrigger) {
            const triggerPrice = alert.price_direction === 'up' ? price.high : price.low;
            if (triggerPrice) {
              notificationQueue.push({ alert, triggerPrice });
              metrics.alertsTriggered++;
            }
          }
        } catch (error: any) {
          const errorMsg = `Error checking alert ${alert.id}: ${error.message}`;
          console.error('❌', errorMsg);
          metrics.errors.push(errorMsg);
        }
      }
    }

    if (notificationQueue.length > 0) {
      console.log(`📬 Queueing ${notificationQueue.length} notifications to be sent.`);
    }

    // Process notification queue with rate limiting (50 per second Discord limit)
    const BATCH_SIZE = 50;
    const BATCH_DELAY_MS = 1000;

    for (let i = 0; i < notificationQueue.length; i += BATCH_SIZE) {
      const batch = notificationQueue.slice(i, i + BATCH_SIZE);

      await Promise.allSettled(
        batch.map(async ({ alert, triggerPrice }) => {
          let notificationSent = false;
          let notificationError = null;

          try {
            await sendDiscordNotification(alert, triggerPrice, env.DISCORD_BOT_TOKEN);
            notificationSent = true;
            metrics.notificationsSent++;
          } catch (error: any) {
            notificationSent = false;
            notificationError = error.message;
            metrics.notificationsFailed++;
            const errorMsg = `Notification failed for alert ${alert.id} (${alert.item_name}): ${error.message}`;
            console.error('❌', errorMsg);
            metrics.errors.push(errorMsg);
          }

          // Log history regardless of notification success
          try {
            const { error: historyError } = await supabase.from('alert_history').insert({
              alert_id: alert.id,
              user_id: alert.user_id,
              item_id: alert.item_id,
              item_name: alert.item_name,
              trigger_price: triggerPrice,
              target_price: alert.target_price || alert.baseline_price,
              alert_type: alert.alert_type,
              notification_type: alert.notification_type,
              notification_sent: notificationSent,
              notification_error: notificationError,
              alert_behavior: alert.behavior
            });

            if (historyError) {
              const errorMsg = `Failed to log history for alert ${alert.id}: ${historyError.message}`;
              console.error('⚠️', errorMsg);
              metrics.errors.push(errorMsg);
            }
          } catch (error: any) {
            const errorMsg = `Exception logging history for alert ${alert.id}: ${error.message}`;
            console.error('❌', errorMsg);
            metrics.errors.push(errorMsg);
          }

          // Only update alert if notification succeeded
          if (notificationSent) {
            try {
              const updates: { last_triggered_at: string, trigger_count: number, active?: boolean } = {
                last_triggered_at: new Date().toISOString(),
                trigger_count: alert.trigger_count + 1
              };
              if (alert.behavior === 'one_shot') updates.active = false;

              const { error: updateError } = await supabase.from('user_alerts').update(updates).eq('id', alert.id);
              if (updateError) {
                const errorMsg = `Failed to update alert ${alert.id}: ${updateError.message}`;
                console.error('⚠️', errorMsg);
                metrics.errors.push(errorMsg);
              }
            } catch (error: any) {
              const errorMsg = `Exception updating alert ${alert.id}: ${error.message}`;
              console.error('❌', errorMsg);
              metrics.errors.push(errorMsg);
            }
          }
        })
      );

      // Rate limit: wait before next batch
      if (i + BATCH_SIZE < notificationQueue.length) {
        await new Promise(resolve => setTimeout(resolve, BATCH_DELAY_MS));
      }
    }

    logMetrics(metrics, startTime);
    return metrics;
  } catch (error: any) {
    const errorMsg = `Fatal error in checkAlertsAndNotify: ${error.message}`;
    console.error('💥', errorMsg);
    metrics.errors.push(errorMsg);
    logMetrics(metrics, startTime);
    return metrics;
  }
}

function logMetrics(metrics: any, startTime: number) {
  metrics.executionTimeMs = Date.now() - startTime;

  console.log('📊 ========== ALERT METRICS ==========');
  console.log(JSON.stringify({
    timestamp: new Date().toISOString(),
    totalAlerts: metrics.totalAlerts,
    alertsChecked: metrics.alertsChecked,
    alertsTriggered: metrics.alertsTriggered,
    notificationsSent: metrics.notificationsSent,
    notificationsFailed: metrics.notificationsFailed,
    tokensRefreshed: metrics.tokensRefreshed,
    successRate: metrics.alertsTriggered > 0
      ? ((metrics.notificationsSent / metrics.alertsTriggered) * 100).toFixed(2) + '%'
      : 'N/A',
    executionTimeMs: metrics.executionTimeMs,
    errorCount: metrics.errors.length
  }, null, 2));

  if (metrics.errors.length > 0) {
    console.log('⚠️  Errors encountered:');
    metrics.errors.forEach((error: string, index: number) => {
      console.log(`  ${index + 1}. ${error}`);
    });
  }

  console.log('=====================================');
}

async function refreshDiscordToken(userId: string, refreshToken: string, supabase: any, env: Env): Promise<boolean> {
  try {
    const refreshResponse = await fetch('https://discord.com/api/oauth2/token', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: new URLSearchParams({
        client_id: env.DISCORD_CLIENT_ID,
        client_secret: env.DISCORD_CLIENT_SECRET,
        grant_type: 'refresh_token',
        refresh_token: refreshToken,
      }),
    });

    if (!refreshResponse.ok) {
      const errorText = await refreshResponse.text();
      console.error(`Token refresh failed for user ${userId}:`, errorText);
      return false;
    }

    const tokenData = await refreshResponse.json() as { expires_in?: number; access_token: string; refresh_token?: string };
    const expiresIn = tokenData.expires_in || 604800; // Default to 7 days
    const tokenExpiresAt = new Date(Date.now() + expiresIn * 1000).toISOString();

    // Update connection with new tokens
    await supabase.from('discord_connections').update({
      access_token: tokenData.access_token,
      refresh_token: tokenData.refresh_token || refreshToken,
      token_expires_at: tokenExpiresAt,
    }).eq('user_id', userId);

    console.log(`✅ Successfully refreshed Discord token for user ${userId}`);
    return true;
  } catch (error) {
    console.error(`❌ Error refreshing Discord token for user ${userId}:`, error);
    return false;
  }
}

/**
 * SECURITY: Sanitizes user notes before sending to Discord
 * Prevents @everyone/@here mentions and Discord markdown injection
 */
function sanitizeNotesForDiscord(text: string): string {
  if (!text) return ''

  const maxLength = 500
  const truncated = text.substring(0, maxLength)

  return truncated
    .replace(/@everyone/gi, '@\u200beveryone')
    .replace(/@here/gi, '@\u200bhere')
    .replace(/<@&/g, '<@\u200b&')
    .replace(/<@!/g, '<@\u200b!')
    .replace(/<@/g, '<@\u200b')
    .trim()
}

function checkAlertCondition(alert: UserAlert, price: WikiLatestPrice): boolean {
  const currentPrice = alert.price_direction === 'up' ? price.high : price.low;

  if (currentPrice === null) return false;

  if (alert.alert_type === 'absolute' && alert.target_price) {
    if (alert.price_direction === 'up') return currentPrice >= alert.target_price;
    if (alert.price_direction === 'down') return currentPrice <= alert.target_price;
    // 'either' doesn't make sense for absolute price alerts - would need historical data
    // to detect if price "crossed" the target. Treating as invalid for now.
    return false;
  }

  if (alert.alert_type === 'percentage_change' && alert.baseline_price && alert.percentage_threshold) {
    const percentChange = ((currentPrice - alert.baseline_price) / alert.baseline_price) * 100;

    if (alert.price_direction === 'up') {
      return percentChange >= alert.percentage_threshold;
    }
    if (alert.price_direction === 'down') {
      return percentChange <= -Math.abs(alert.percentage_threshold);
    }
    return Math.abs(percentChange) >= Math.abs(alert.percentage_threshold);
  }

  return false;
}

async function sendDiscordNotification(alert: any, triggerPrice: number, botToken: string) {
  // SECURITY: Sanitize notes to prevent XSS and Discord injection attacks
  const sanitizedNotes = alert.notes ? sanitizeNotesForDiscord(alert.notes) : ''
  const message = `🔔 **Price Alert!**\n\n**${alert.item_name}** is now **${triggerPrice.toLocaleString()}** gp!\n` +
    (sanitizedNotes ? `\nNote: ${sanitizedNotes}` : '');

  // Extract discord_user_id from joined discord_connections
  const discordUserId = alert.discord_connections?.discord_user_id;

  if (alert.notification_type === 'bot_dm' && discordUserId) {
    // Create DM channel
    const dmRes = await fetch('https://discord.com/api/v10/users/@me/channels', {
      method: 'POST',
      headers: { 'Authorization': `Bot ${botToken}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ recipient_id: discordUserId })
    });

    if (!dmRes.ok) {
      const error = await dmRes.text();
      throw new Error(`Failed to create DM channel: ${dmRes.status} - ${error}`);
    }

    const dmChannel = await dmRes.json() as { id: string };

    // Send message
    const msgRes = await fetch(`https://discord.com/api/v10/channels/${dmChannel.id}/messages`, {
      method: 'POST',
      headers: { 'Authorization': `Bot ${botToken}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ content: message })
    });

    if (!msgRes.ok) {
      const error = await msgRes.text();
      throw new Error(`Failed to send DM: ${msgRes.status} - ${error}`);
    }
  } else if (alert.notification_type === 'webhook' && alert.discord_webhook_url) {
    // Webhook
    const webhookRes = await fetch(alert.discord_webhook_url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ content: message })
    });

    if (!webhookRes.ok) {
      const error = await webhookRes.text();
      throw new Error(`Webhook failed: ${webhookRes.status} - ${error}`);
    }
  } else {
    throw new Error(`Invalid notification type or missing data for alert ${alert.id}`);
  }
}
