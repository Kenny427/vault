/**
 * Minimal test endpoint to verify Functions are working
 */

export const onRequestGet: PagesFunction = async () => {
  console.log('TEST: Function was called')

  return new Response(JSON.stringify({
    message: 'Test endpoint working!',
    timestamp: new Date().toISOString()
  }), {
    status: 200,
    headers: { 'Content-Type': 'application/json' }
  })
}
