// Alert CRUD endpoints - Cloudflare Pages Function
import { createClient } from '@supabase/supabase-js'
import { createAlertSchema, updateAlertSchema, validateWebhookUrl, sanitizeForDiscord, checkRateLimit } from '@ge-vault/shared'

interface Env {
  SUPABASE_URL: string
  SUPABASE_SERVICE_KEY: string
  ENVIRONMENT?: string
}

const corsHeaders = {
  'Access-Control-Allow-Origin': '*', // TODO: Restrict to specific domains in production
  'Access-Control-Allow-Methods': 'GET, POST, PATCH, DELETE, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization',
}

export const onRequest: PagesFunction<Env> = async (context) => {
  // Handle CORS preflight
  if (context.request.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders })
  }

  const url = new URL(context.request.url)
  const path = url.pathname.replace('/api/alerts', '')

  // Get auth token from header
  const authHeader = context.request.headers.get('Authorization')
  if (!authHeader?.startsWith('Bearer ')) {
    return new Response('Unauthorized', { status: 401, headers: corsHeaders })
  }

  const token = authHeader.substring(7)
  const supabase = createClient(context.env.SUPABASE_URL, context.env.SUPABASE_SERVICE_KEY, {
    global: {
      headers: { Authorization: `Bearer ${token}` }
    }
  })

  // Verify user is authenticated
  const { data: { user }, error: authError } = await supabase.auth.getUser(token)
  if (authError || !user) {
    return new Response('Unauthorized', { status: 401, headers: corsHeaders })
  }

  try {
    // Route to specific handlers
    if (path === '/create' && context.request.method === 'POST') {
      return await handleCreate(context, supabase, user.id)
    } else if (path === '/list' && context.request.method === 'GET') {
      return await handleList(context, supabase, user.id)
    } else if (path === '/update' && context.request.method === 'PATCH') {
      return await handleUpdate(context, supabase, user.id)
    } else if (path === '/delete' && context.request.method === 'DELETE') {
      return await handleDelete(context, supabase, user.id)
    }

    return new Response('Not Found', { status: 404, headers: corsHeaders })
  } catch (error: any) {
    return new Response(error.message, { status: 500, headers: corsHeaders })
  }
}

async function handleCreate(context: any, supabase: any, userId: string) {
  try {
    // SECURITY: Rate limiting - prevent alert spam
    const rateLimitKey = `alert_create:${userId}`
    const rateLimit = checkRateLimit(rateLimitKey, 10, 60000) // 10 alerts per minute
    if (!rateLimit.allowed) {
      return new Response(JSON.stringify({
        error: 'Rate limit exceeded',
        details: [`Too many requests. Please try again in ${rateLimit.retryAfter} seconds.`]
      }), {
        status: 429,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json',
          'Retry-After': rateLimit.retryAfter?.toString() || '60'
        }
      });
    }

    const body = await context.request.json()

    // SECURITY: Validate input with Zod schema
    const validation = createAlertSchema.safeParse(body)
    if (!validation.success) {
      const errors = validation.error.errors.map(err =>
        `${err.path.join('.')}: ${err.message}`
      )
      return new Response(JSON.stringify({
        error: 'Validation failed',
        details: errors
      }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    const validatedData = validation.data

    // SECURITY: Additional SSRF protection for webhook URLs
    if (validatedData.notification_type === 'webhook' && validatedData.discord_webhook_url) {
      const webhookValidation = validateWebhookUrl(validatedData.discord_webhook_url)
      if (!webhookValidation.valid) {
        return new Response(JSON.stringify({
          error: 'Invalid webhook URL',
          details: [webhookValidation.error || 'Webhook URL failed security validation']
        }), {
          status: 400,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
      }
    }

    // If notification_type is 'bot_dm', get the user's discord_user_id
    if (validatedData.notification_type === 'bot_dm') {
      const { data: discordConnection } = await supabase
        .from('discord_connections')
        .select('discord_user_id')
        .eq('user_id', userId)
        .single()

      if (!discordConnection) {
        return new Response(JSON.stringify({
          error: 'Discord account not connected',
          details: ['Please connect your Discord account before creating bot DM alerts.']
        }), {
          status: 400,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
      }

      validatedData.discord_user_id = discordConnection.discord_user_id
    }

    // SECURITY: Sanitize notes field to prevent XSS in Discord messages
    const alertData = {
      ...validatedData,
      notes: validatedData.notes ? sanitizeForDiscord(validatedData.notes) : null,
      user_id: userId
    }

    // Create alert
    const { data, error } = await supabase
      .from('user_alerts')
      .insert(alertData)
      .select()
      .single()

    if (error) {
      console.error('Alert creation error:', error)
      return new Response(JSON.stringify({
        error: 'Failed to create alert',
        details: [error.message]
      }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    return new Response(JSON.stringify(data), { headers: { ...corsHeaders, 'Content-Type': 'application/json' } })
  } catch (error: any) {
    console.error('Unexpected error in handleCreate:', error);
    return new Response(JSON.stringify({
      error: 'Internal server error',
      details: ['An unexpected error occurred. Please try again.']
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
  }
}

async function handleList(context: any, supabase: any, userId: string) {
  const { data, error } = await supabase
    .from('user_alerts')
    .select('*')
    .eq('user_id', userId)
    .order('created_at', { ascending: false })

  if (error) {
    return new Response(error.message, { status: 400, headers: corsHeaders })
  }

  return new Response(JSON.stringify(data), { headers: { ...corsHeaders, 'Content-Type': 'application/json' } })
}

async function handleUpdate(context: any, supabase: any, userId: string) {
  try {
    const body = await context.request.json()

    // SECURITY: Validate with strict schema to prevent mass assignment
    const validation = updateAlertSchema.safeParse(body)
    if (!validation.success) {
      const errors = validation.error.errors.map(err =>
        `${err.path.join('.')}: ${err.message}`
      )
      return new Response(JSON.stringify({
        error: 'Validation failed',
        details: errors
      }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    const { id, ...updates } = validation.data

    // SECURITY: Sanitize notes if present
    if (updates.notes) {
      updates.notes = sanitizeForDiscord(updates.notes)
    }

    const { data, error } = await supabase
      .from('user_alerts')
      .update(updates)
      .eq('id', id)
      .eq('user_id', userId) // SECURITY: Ensure user owns this alert
      .select()
      .single()

    if (error) {
      return new Response(JSON.stringify({
        error: 'Failed to update alert',
        details: [error.message]
      }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      })
    }

    if (!data) {
      return new Response(JSON.stringify({
        error: 'Alert not found',
        details: ['Alert does not exist or you do not have permission to update it']
      }), {
        status: 404,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      })
    }

    return new Response(JSON.stringify(data), { headers: { ...corsHeaders, 'Content-Type': 'application/json' } })
  } catch (error: any) {
    console.error('Unexpected error in handleUpdate:', error);
    return new Response(JSON.stringify({
      error: 'Internal server error',
      details: ['An unexpected error occurred. Please try again.']
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
  }
}

async function handleDelete(context: any, supabase: any, userId: string) {
  const body = await context.request.json()
  const { id } = body

  const { error } = await supabase
    .from('user_alerts')
    .delete()
    .eq('id', id)
    .eq('user_id', userId)

  if (error) {
    return new Response(error.message, { status: 400, headers: corsHeaders })
  }

  return new Response(JSON.stringify({ success: true }), { headers: { ...corsHeaders, 'Content-Type': 'application/json' } })
}
