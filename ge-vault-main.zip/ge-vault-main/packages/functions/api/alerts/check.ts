// Endpoint to check alerts after manual price refresh
import { createClient } from '@supabase/supabase-js'
import type { UserAlert } from '@ge-vault/shared'

interface Env {
  SUPABASE_URL: string
  SUPABASE_SERVICE_KEY: string
  DISCORD_BOT_TOKEN: string
}

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization',
}

export const onRequest: PagesFunction<Env> = async (context) => {
  if (context.request.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders })
  }

  if (context.request.method !== 'POST') {
    return new Response('Method not allowed', { status: 405, headers: corsHeaders })
  }

  // Get auth token
  const authHeader = context.request.headers.get('Authorization')
  if (!authHeader?.startsWith('Bearer ')) {
    return new Response('Unauthorized', { status: 401, headers: corsHeaders })
  }

  const token = authHeader.substring(7)
  const supabase = createClient(context.env.SUPABASE_URL, context.env.SUPABASE_SERVICE_KEY)

  // Verify user
  const { data: { user }, error: authError } = await supabase.auth.getUser(token)
  if (authError || !user) {
    return new Response('Unauthorized', { status: 401, headers: corsHeaders })
  }

  try {
    // Get all active alerts
    const { data: alerts, error: alertsError } = await supabase
      .from('user_alerts')
      .select('*, discord_connections(discord_user_id)')
      .eq('active', true)

    if (alertsError) {
      console.error('Failed to fetch alerts:', alertsError)
      return new Response(JSON.stringify({ error: alertsError.message }), {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      })
    }

    if (!alerts?.length) {
      return new Response(JSON.stringify({ checked: 0, triggered: 0 }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      })
    }

    // Get current prices for alerted items
    const itemIds = [...new Set(alerts.map(a => a.item_id))]
    const { data: prices } = await supabase
      .from('item_prices_current')
      .select('item_id, high_price, low_price')
      .in('item_id', itemIds)

    const priceMap = new Map(prices?.map(p => [String(p.item_id), p]) || [])

    let triggered = 0
    let checked = 0

    for (const alert of alerts) {
      const price = priceMap.get(alert.item_id)
      if (!price) continue

      checked++

      // Check cooldown
      const { data: shouldCheck } = await supabase.rpc('should_check_alert', {
        p_alert_id: alert.id,
        p_behavior: alert.behavior,
        p_cooldown_hours: alert.cooldown_hours || 24
      })

      if (!shouldCheck) continue

      // Check condition
      const shouldTrigger = checkAlertCondition(alert, price.high_price, price.low_price)

      if (shouldTrigger) {
        const triggerPrice = alert.price_direction === 'up' ? price.high_price : price.low_price
        if (triggerPrice) {
          triggered++

          // Send notification
          let notificationSent = false
          let notificationError = null

          try {
            await sendDiscordNotification(alert, triggerPrice, context.env.DISCORD_BOT_TOKEN)
            notificationSent = true
          } catch (error: any) {
            notificationError = error.message
            console.error(`Notification failed for alert ${alert.id}:`, error.message)
          }

          // Log history
          await supabase.from('alert_history').insert({
            alert_id: alert.id,
            user_id: alert.user_id,
            item_id: alert.item_id,
            item_name: alert.item_name,
            trigger_price: triggerPrice,
            target_price: alert.target_price || alert.baseline_price,
            alert_type: alert.alert_type,
            notification_type: alert.notification_type,
            notification_sent: notificationSent,
            notification_error: notificationError,
            alert_behavior: alert.behavior
          })

          // Update alert
          if (notificationSent) {
            const updates: any = {
              last_triggered_at: new Date().toISOString(),
              trigger_count: alert.trigger_count + 1
            }
            if (alert.behavior === 'one_shot') updates.active = false

            await supabase.from('user_alerts').update(updates).eq('id', alert.id)
          }
        }
      }
    }

    return new Response(JSON.stringify({ checked, triggered }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    })
  } catch (error: any) {
    console.error('Alert check error:', error)
    return new Response(JSON.stringify({ error: error.message }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    })
  }
}

function checkAlertCondition(alert: UserAlert, highPrice: number | null, lowPrice: number | null): boolean {
  if (alert.alert_type === 'absolute') {
    if (!alert.target_price) return false

    if (alert.price_direction === 'up') {
      return highPrice !== null && highPrice >= alert.target_price
    } else if (alert.price_direction === 'down') {
      return lowPrice !== null && lowPrice <= alert.target_price
    } else {
      return (highPrice !== null && highPrice >= alert.target_price) ||
             (lowPrice !== null && lowPrice <= alert.target_price)
    }
  } else if (alert.alert_type === 'percentage_change') {
    if (!alert.baseline_price || !alert.percentage_threshold) return false

    const currentPrice = alert.price_direction === 'up' ? highPrice : lowPrice
    if (!currentPrice) return false

    const percentChange = ((currentPrice - alert.baseline_price) / alert.baseline_price) * 100

    if (alert.price_direction === 'up') {
      return percentChange >= alert.percentage_threshold
    } else if (alert.price_direction === 'down') {
      return percentChange <= -alert.percentage_threshold
    } else {
      return Math.abs(percentChange) >= alert.percentage_threshold
    }
  }

  return false
}

async function sendDiscordNotification(alert: UserAlert, triggerPrice: number, botToken: string) {
  const embed = {
    title: `🔔 Price Alert: ${alert.item_name}`,
    description: alert.price_direction === 'up'
      ? `Price has risen to **${triggerPrice.toLocaleString()} gp**`
      : `Price has dropped to **${triggerPrice.toLocaleString()} gp**`,
    color: alert.price_direction === 'up' ? 0x00ff00 : 0xff0000,
    fields: [
      {
        name: 'Target Price',
        value: `${alert.target_price?.toLocaleString() || 'N/A'} gp`,
        inline: true
      },
      {
        name: 'Current Price',
        value: `${triggerPrice.toLocaleString()} gp`,
        inline: true
      }
    ],
    timestamp: new Date().toISOString(),
    footer: { text: 'GE Vault Price Alerts' }
  }

  if (alert.notification_type === 'webhook' && alert.discord_webhook_url) {
    const response = await fetch(alert.discord_webhook_url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ embeds: [embed] })
    })

    if (!response.ok) {
      throw new Error(`Webhook failed: ${response.status}`)
    }
  } else if (alert.notification_type === 'bot_dm' && alert.discord_user_id) {
    // Create DM channel
    const dmResponse = await fetch('https://discord.com/api/v10/users/@me/channels', {
      method: 'POST',
      headers: {
        'Authorization': `Bot ${botToken}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ recipient_id: alert.discord_user_id })
    })

    if (!dmResponse.ok) {
      throw new Error(`Failed to create DM: ${dmResponse.status}`)
    }

    const dmChannel = await dmResponse.json()

    // Send message
    const msgResponse = await fetch(`https://discord.com/api/v10/channels/${dmChannel.id}/messages`, {
      method: 'POST',
      headers: {
        'Authorization': `Bot ${botToken}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ embeds: [embed] })
    })

    if (!msgResponse.ok) {
      throw new Error(`Failed to send DM: ${msgResponse.status}`)
    }
  }
}
