// Discord OAuth endpoints - Cloudflare Pages Function
import { createClient } from '@supabase/supabase-js'

interface Env {
  SUPABASE_URL: string
  SUPABASE_SERVICE_KEY: string
  DISCORD_CLIENT_ID: string
  DISCORD_CLIENT_SECRET: string
  DISCORD_REDIRECT_URI: string
}



const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, DELETE, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization',
}

export const onRequest: PagesFunction<Env> = async (context) => {
  // Handle CORS preflight
  if (context.request.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders })
  }

  const url = new URL(context.request.url)
  const path = url.pathname.replace('/api/discord', '')

  const supabase = createClient(context.env.SUPABASE_URL, context.env.SUPABASE_SERVICE_KEY)

  try {
    if (path === '/connect' && context.request.method === 'GET') {
      return await handleConnect(context, supabase)
    } else if (path === '/callback' && context.request.method === 'GET') {
      return await handleCallback(context, supabase)
    } else if (path === '/disconnect' && context.request.method === 'DELETE') {
      return await handleDisconnect(context, supabase)
    } else if (path === '/refresh' && context.request.method === 'POST') {
      return await handleRefresh(context, supabase)
    }

    return new Response('Not Found', { status: 404, headers: corsHeaders })
  } catch (error: any) {
    console.error('Discord API error:', error)
    return new Response(error.message, { status: 500, headers: corsHeaders })
  }
}

async function handleConnect(context: any, supabase: any) {
  // Get access token from query parameter
  const url = new URL(context.request.url)
  const accessToken = url.searchParams.get('token')

  if (!accessToken) {
    return new Response('Please log in first', { status: 401, headers: corsHeaders })
  }

  const { data: { user }, error: authError } = await supabase.auth.getUser(accessToken)
  if (authError || !user) {
    console.error('Auth error:', authError)
    return new Response('Unauthorized', { status: 401, headers: corsHeaders })
  }

  // Create OAuth state
  const state = crypto.randomUUID()
  const expiresAt = new Date(Date.now() + 10 * 60 * 1000).toISOString()

  await supabase.from('oauth_states').insert({
    state,
    user_id: user.id,
    expires_at: expiresAt
  })

  // Redirect to Discord OAuth
  // Note: This only gets user identity for associating webhooks
  // For bot DMs, users would need to share a server with the bot
  // Primary notification method: Discord webhooks (user-provided)
  const discordAuthUrl = `https://discord.com/api/oauth2/authorize?client_id=${context.env.DISCORD_CLIENT_ID}&redirect_uri=${encodeURIComponent(context.env.DISCORD_REDIRECT_URI)}&response_type=code&scope=identify&state=${state}`

  return Response.redirect(discordAuthUrl, 302)
}

async function handleCallback(context: any, supabase: any) {
  const url = new URL(context.request.url)
  const error = url.searchParams.get('error')
  const code = url.searchParams.get('code')
  const state = url.searchParams.get('state')

  // Handle user cancellation or OAuth errors
  if (error) {
    console.log(`Discord OAuth error: ${error}`)
    const redirectUrl = context.env.REDIRECT_DOMAIN
      ? `${context.env.REDIRECT_DOMAIN}/alerts?discord_error=cancelled`
      : 'https://gevault.com/alerts?discord_error=cancelled'
    return Response.redirect(redirectUrl, 302)
  }

  if (!code || !state) {
    const redirectUrl = context.env.REDIRECT_DOMAIN
      ? `${context.env.REDIRECT_DOMAIN}/alerts?discord_error=invalid`
      : 'https://gevault.com/alerts?discord_error=invalid'
    return Response.redirect(redirectUrl, 302)
  }

  // Verify state
  const { data: stateData, error: stateError } = await supabase
    .from('oauth_states')
    .select('*')
    .eq('state', state)
    .eq('used', false)
    .single()

  if (stateError || !stateData) {
    return new Response('Invalid state', { status: 400, headers: corsHeaders })
  }

  // Mark state as used
  await supabase.from('oauth_states').update({ used: true }).eq('state', state)

  // Exchange code for token
  const tokenResponse = await fetch('https://discord.com/api/oauth2/token', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded',
    },
    body: new URLSearchParams({
      client_id: context.env.DISCORD_CLIENT_ID,
      client_secret: context.env.DISCORD_CLIENT_SECRET,
      grant_type: 'authorization_code',
      code: code,
      redirect_uri: context.env.DISCORD_REDIRECT_URI,
    }),
  })

  const tokenData: any = await tokenResponse.json();

  if (!tokenData.access_token) {
    console.error('Token exchange failed:', tokenData)
    return new Response(`Failed to get access token: ${JSON.stringify(tokenData)}`, { status: 400, headers: corsHeaders })
  }

  // Get Discord user info
  const userResponse = await fetch('https://discord.com/api/users/@me', {
    headers: {
      Authorization: `Bearer ${tokenData.access_token}`,
    },
  })

  if (!userResponse.ok) {
    const errorText = await userResponse.text()
    console.error('Failed to get Discord user info:', errorText)
    return new Response(`Failed to get user info: ${errorText}`, { status: 400, headers: corsHeaders })
  }

  const discordUser: any = await userResponse.json();

  // Calculate token expiry (Discord tokens expire in 7 days = 604800 seconds)
  const expiresIn = tokenData.expires_in || 604800 // Default to 7 days if not provided
  const tokenExpiresAt = new Date(Date.now() + expiresIn * 1000).toISOString()

  // Store connection in database
  const { error: upsertError } = await supabase.from('discord_connections').upsert({
    user_id: stateData.user_id,
    discord_user_id: discordUser.id,
    discord_username: discordUser.global_name || discordUser.username,
    access_token: tokenData.access_token,
    refresh_token: tokenData.refresh_token,
    token_expires_at: tokenExpiresAt,
  }, { onConflict: 'user_id' })

  if (upsertError) {
    console.error('Failed to save Discord connection:', upsertError)
    return new Response(`Failed to save connection: ${upsertError.message}`, { status: 500, headers: corsHeaders })
  }

  // Redirect back to app - use custom domain
  const redirectUrl = context.env.REDIRECT_DOMAIN
    ? `${context.env.REDIRECT_DOMAIN}/alerts`
    : 'https://gevault.com/alerts'
  return Response.redirect(redirectUrl, 302)
}

async function handleDisconnect(context: any, supabase: any) {
  // Get current user
  const authHeader = context.request.headers.get('Authorization')
  if (!authHeader?.startsWith('Bearer ')) {
    return new Response('Unauthorized', { status: 401, headers: corsHeaders })
  }

  const token = authHeader.substring(7)
  const { data: { user }, error: authError } = await supabase.auth.getUser(token)
  if (authError || !user) {
    return new Response('Unauthorized', { status: 401, headers: corsHeaders })
  }

  // Delete connection
  await supabase.from('discord_connections').delete().eq('user_id', user.id)

  return new Response(JSON.stringify({ success: true }), { headers: { ...corsHeaders, 'Content-Type': 'application/json' } })
}

async function handleRefresh(context: any, supabase: any) {
  // Get current user
  const authHeader = context.request.headers.get('Authorization')
  if (!authHeader?.startsWith('Bearer ')) {
    return new Response('Unauthorized', { status: 401, headers: corsHeaders })
  }

  const token = authHeader.substring(7)
  const { data: { user }, error: authError } = await supabase.auth.getUser(token)
  if (authError || !user) {
    return new Response('Unauthorized', { status: 401, headers: corsHeaders })
  }

  // Get current Discord connection
  const { data: connection, error: connError } = await supabase
    .from('discord_connections')
    .select('*')
    .eq('user_id', user.id)
    .single()

  if (connError || !connection) {
    return new Response('Discord connection not found', { status: 404, headers: corsHeaders })
  }

  if (!connection.refresh_token) {
    return new Response('No refresh token available', { status: 400, headers: corsHeaders })
  }

  // Refresh the token
  const refreshResponse = await fetch('https://discord.com/api/oauth2/token', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded',
    },
    body: new URLSearchParams({
      client_id: context.env.DISCORD_CLIENT_ID,
      client_secret: context.env.DISCORD_CLIENT_SECRET,
      grant_type: 'refresh_token',
      refresh_token: connection.refresh_token,
    }),
  })

  if (!refreshResponse.ok) {
    const errorText = await refreshResponse.text()
    console.error('Token refresh failed:', errorText)
    return new Response('Token refresh failed', { status: 400, headers: corsHeaders })
  }

  const tokenData: any = await refreshResponse.json();

  // Calculate new token expiry
  const expiresIn = tokenData.expires_in || 604800 // Default to 7 days
  const tokenExpiresAt = new Date(Date.now() + expiresIn * 1000).toISOString()

  // Update connection with new tokens
  await supabase.from('discord_connections').update({
    access_token: tokenData.access_token,
    refresh_token: tokenData.refresh_token || connection.refresh_token, // Keep old refresh token if new one not provided
    token_expires_at: tokenExpiresAt,
  }).eq('user_id', user.id)

  return new Response(JSON.stringify({
    success: true,
    expires_at: tokenExpiresAt
  }), {
    headers: { ...corsHeaders, 'Content-Type': 'application/json' }
  })
}