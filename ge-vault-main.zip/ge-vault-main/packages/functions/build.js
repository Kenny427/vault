const esbuild = require('esbuild')
const path = require('path')
const fs = require('fs')
const glob = require('glob')

const functionsDir = path.join(__dirname, 'api')
// Output to web/functions/api (sibling of dist, not inside it)
const outDir = path.join(__dirname, '..', 'web', 'functions', 'api')

// Find all .ts files
const entryPoints = glob.sync('**/*.ts', { cwd: functionsDir })

// Build each file
for (const entry of entryPoints) {
  const outfile = path.join(outDir, entry.replace('.ts', '.js'))

  esbuild.buildSync({
    entryPoints: [path.join(functionsDir, entry)],
    outfile,
    bundle: true,
    platform: 'browser',
    conditions: ['worker', 'browser'],
    format: 'esm',
    target: 'es2020',
    alias: {
      '@ge-vault/shared': path.join(__dirname, '..', 'shared', 'src', 'index.ts')
    }
  })
}

console.log(`Built ${entryPoints.length} functions`)
