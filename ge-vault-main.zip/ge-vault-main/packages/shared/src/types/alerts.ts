export type AlertType = 'absolute' | 'percentage_change';
export type PriceDirection = 'up' | 'down' | 'either';
export type NotificationType = 'bot_dm' | 'webhook';
export type AlertBehavior = 'one_shot' | 'recurring' | 'cooldown';

export interface UserAlert {
  id: number;
  user_id: string;
  item_id: string;
  item_name: string;
  alert_type: AlertType;
  target_price?: number;
  percentage_threshold?: number;
  baseline_price?: number;
  price_direction: PriceDirection;
  notification_type: NotificationType;
  discord_user_id?: string;
  discord_webhook_url?: string;
  behavior: AlertBehavior;
  cooldown_hours?: number;
  notes?: string;
  active: boolean;
  created_at: string;
  last_triggered_at?: string;
  trigger_count: number;
}

export interface AlertHistory {
  id: number;
  alert_id: number;
  user_id: string;
  triggered_at: string;
  item_id: string;
  item_name: string;
  trigger_price: number;
  target_price: number;
  alert_type: AlertType;
  notification_type: NotificationType;
  notification_sent: boolean;
  notification_error?: string;
  alert_behavior: AlertBehavior;
}

export interface DiscordConnection {
  id: number;
  user_id: string;
  discord_user_id: string;
  discord_username: string;
  access_token: string;
  refresh_token?: string;
  token_expires_at?: string;
  connected_at: string;
}

export interface OauthState {
  id: number;
  state: string;
  user_id: string;
  created_at: string;
  expires_at: string;
  used: boolean;
}