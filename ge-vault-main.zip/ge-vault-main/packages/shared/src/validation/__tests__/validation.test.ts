import { describe, it, expect } from 'vitest'
import { validateWebhookUrl, validateStripeCustomerId } from '../index'

describe('validation', () => {
  describe('validateWebhookUrl', () => {
    it('should return true for valid discord webhook urls', () => {
      expect(validateWebhookUrl('https://discord.com/api/webhooks/123/abc').valid).toBe(true)
      expect(validateWebhookUrl('https://discordapp.com/api/webhooks/123/abc').valid).toBe(true)
    })

    it('should return false for invalid discord webhook urls', () => {
      expect(validateWebhookUrl('http://discord.com/api/webhooks/123/abc').valid).toBe(false)
      expect(validateWebhookUrl('https://discord.com/not-webhooks/123/abc').valid).toBe(false)
      expect(validateWebhookUrl('https://google.com/api/webhooks/123/abc').valid).toBe(false)
      expect(validateWebhookUrl('https://127.0.0.1/api/webhooks/123/abc').valid).toBe(false)
    })
  })

  describe('validateStripeCustomerId', () => {
    it('should return true for valid stripe customer ids', () => {
      expect(validateStripeCustomerId('cus_12345678901234')).toBe(true)
    })

    it('should return false for invalid stripe customer ids', () => {
      expect(validateStripeCustomerId('cus_1234567890123')).toBe(false) // Too short
      expect(validateStripeCustomerId('sub_12345678901234')).toBe(false) // Not a customer id
      expect(validateStripeCustomerId('cus_1234567890123456789012345')).toBe(false) // Too long
    })
  })
})
