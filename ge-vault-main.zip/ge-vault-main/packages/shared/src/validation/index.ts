/**
 * Security validation utilities for GE Vault
 * Implements input validation, SSRF protection, and sanitization
 */

import { z } from 'zod'

/**
 * SSRF Protection: Validates Discord webhook URLs
 * Prevents attacks targeting internal networks, localhost, and private IPs
 *
 * Attack vectors prevented:
 * - Private IP ranges (10.x, 172.16-31.x, 192.168.x, 127.x)
 * - Localhost variations (localhost, 0.0.0.0, [::]
 * - Link-local addresses (169.254.x.x)
 * - Cloud metadata endpoints (169.254.169.254)
 */
export function validateWebhookUrl(url: string): { valid: boolean; error?: string } {
  try {
    const parsed = new URL(url)

    // Must be HTTPS
    if (parsed.protocol !== 'https:') {
      return { valid: false, error: 'Webhook URL must use HTTPS protocol' }
    }

    // Must be Discord domain (prevent redirect attacks)
    if (!parsed.hostname.endsWith('discord.com') && !parsed.hostname.endsWith('discordapp.com')) {
      return { valid: false, error: 'Webhook URL must be a Discord webhook (discord.com or discordapp.com)' }
    }

    // Must match Discord webhook path pattern
    if (!parsed.pathname.startsWith('/api/webhooks/')) {
      return { valid: false, error: 'Invalid Discord webhook URL format' }
    }

    // Prevent numeric IP addresses (even if they resolve to discord.com)
    const ipv4Pattern = /^(\d{1,3}\.){3}\d{1,3}$/
    const ipv6Pattern = /^\[?[0-9a-f:]+\]?$/i
    if (ipv4Pattern.test(parsed.hostname) || ipv6Pattern.test(parsed.hostname)) {
      return { valid: false, error: 'Webhook URL cannot use IP addresses' }
    }

    // Prevent localhost variations
    const localhostPatterns = [
      'localhost',
      '0.0.0.0',
      '127.0.0.1',
      '::1',
      '[::]',
    ]
    if (localhostPatterns.some(pattern => parsed.hostname.toLowerCase().includes(pattern))) {
      return { valid: false, error: 'Webhook URL cannot target localhost' }
    }

    return { valid: true }
  } catch (error) {
    return { valid: false, error: 'Invalid URL format' }
  }
}

/**
 * XSS Protection: Sanitizes user input before including in Discord messages
 * Escapes Discord markdown and prevents injection attacks
 */
export function sanitizeForDiscord(text: string): string {
  if (!text) return ''

  // Limit length to prevent DoS
  const maxLength = 1000
  const truncated = text.substring(0, maxLength)

  // Escape Discord markdown special characters
  // This prevents users from injecting @everyone, @here, or role mentions
  return truncated
    .replace(/@everyone/gi, '@\u200beveryone') // Zero-width space
    .replace(/@here/gi, '@\u200bhere')
    .replace(/<@&/g, '<@\u200b&') // Role mentions
    .replace(/<@!/g, '<@\u200b!') // User mentions
    .replace(/<@/g, '<@\u200b')
    .replace(/```/g, '`\u200b``') // Code blocks
    .trim()
}

/**
 * Zod schema for alert creation with comprehensive validation
 */
export const createAlertSchema = z.object({
  item_id: z.string().min(1, 'Item ID is required'),
  item_name: z.string().min(1, 'Item name is required').max(200, 'Item name too long'),
  alert_type: z.enum(['absolute', 'percentage_change'], {
    errorMap: () => ({ message: 'Alert type must be "absolute" or "percentage_change"' })
  }),
  target_price: z.number().int().positive().optional(),
  percentage_threshold: z.number().positive().max(1000).optional(),
  baseline_price: z.number().int().positive().optional(),
  price_direction: z.enum(['up', 'down', 'either'], {
    errorMap: () => ({ message: 'Price direction must be "up", "down", or "either"' })
  }),
  notification_type: z.enum(['bot_dm', 'webhook'], {
    errorMap: () => ({ message: 'Notification type must be "bot_dm" or "webhook"' })
  }),
  discord_webhook_url: z.string().url().optional(),
  discord_user_id: z.string().optional(),
  behavior: z.enum(['one_shot', 'recurring', 'cooldown'], {
    errorMap: () => ({ message: 'Behavior must be "one_shot", "recurring", or "cooldown"' })
  }),
  cooldown_hours: z.number().int().min(1).max(168).optional(),
  notes: z.string().max(1000, 'Notes cannot exceed 1000 characters').optional(),
}).refine(
  (data) => {
    // Validate alert type specific requirements
    if (data.alert_type === 'absolute') {
      return data.target_price !== undefined && data.target_price > 0
    }
    if (data.alert_type === 'percentage_change') {
      return data.percentage_threshold !== undefined &&
             data.baseline_price !== undefined &&
             data.percentage_threshold > 0 &&
             data.baseline_price > 0
    }
    return true
  },
  {
    message: 'Invalid alert configuration for selected alert type',
    path: ['alert_type']
  }
).refine(
  (data) => {
    // Validate notification type requirements
    if (data.notification_type === 'webhook') {
      return data.discord_webhook_url !== undefined
    }
    return true
  },
  {
    message: 'Webhook URL is required for webhook notifications',
    path: ['discord_webhook_url']
  }
).refine(
  (data) => {
    // Validate webhook URL format and security
    if (data.notification_type === 'webhook' && data.discord_webhook_url) {
      const validation = validateWebhookUrl(data.discord_webhook_url)
      return validation.valid
    }
    return true
  },
  {
    message: 'Invalid or insecure webhook URL',
    path: ['discord_webhook_url']
  }
).refine(
  (data) => {
    // Validate cooldown behavior requirements
    if (data.behavior === 'cooldown') {
      return data.cooldown_hours !== undefined &&
             data.cooldown_hours >= 1 &&
             data.cooldown_hours <= 168
    }
    return true
  },
  {
    message: 'Cooldown hours must be between 1 and 168 hours',
    path: ['cooldown_hours']
  }
)

/**
 * Zod schema for alert updates
 * Only allows updating safe fields, prevents mass assignment
 */
export const updateAlertSchema = z.object({
  id: z.number().int().positive(),
  active: z.boolean().optional(),
  notes: z.string().max(1000).optional(),
  // Explicitly DO NOT allow updating:
  // - user_id (security)
  // - item_id (data integrity)
  // - notification_type (security)
  // - discord_webhook_url (security - should delete and recreate)
  // - target_price, thresholds (data integrity - should delete and recreate)
}).strict() // Reject any additional fields

/**
 * Rate limiting helper (simple in-memory implementation)
 * For production, use Redis or Cloudflare Rate Limiting API
 */
interface RateLimitEntry {
  count: number
  resetAt: number
}

const rateLimitStore = new Map<string, RateLimitEntry>()

export function checkRateLimit(
  identifier: string,
  maxRequests: number,
  windowMs: number
): { allowed: boolean; retryAfter?: number } {
  const now = Date.now()
  const entry = rateLimitStore.get(identifier)

  // Clean up expired entries periodically
  if (Math.random() < 0.01) { // 1% chance
    for (const [key, value] of rateLimitStore.entries()) {
      if (value.resetAt < now) {
        rateLimitStore.delete(key)
      }
    }
  }

  if (!entry || entry.resetAt < now) {
    // New window
    rateLimitStore.set(identifier, {
      count: 1,
      resetAt: now + windowMs
    })
    return { allowed: true }
  }

  if (entry.count >= maxRequests) {
    // Rate limit exceeded
    const retryAfter = Math.ceil((entry.resetAt - now) / 1000)
    return { allowed: false, retryAfter }
  }

  // Increment count
  entry.count++
  return { allowed: true }
}

/**
 * Validates Stripe Customer ID format
 * Prevents injection attacks via customer ID parameter
 */
export function validateStripeCustomerId(customerId: string): boolean {
  // Stripe customer IDs start with 'cus_' followed by 14-24 alphanumeric chars
  const stripeCustomerPattern = /^cus_[A-Za-z0-9]{14,24}$/
  return stripeCustomerPattern.test(customerId)
}

/**
 * Generic error response for production
 * Prevents information disclosure via detailed error messages
 */
export function createSafeErrorResponse(
  isDevelopment: boolean,
  errorMessage: string,
  statusCode: number = 500
): Response {
  const corsHeaders = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, PATCH, DELETE, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    'Content-Type': 'application/json'
  }

  const responseBody = isDevelopment
    ? { error: errorMessage }
    : { error: 'An error occurred. Please try again later.' }

  return new Response(
    JSON.stringify(responseBody),
    { status: statusCode, headers: corsHeaders }
  )
}
