# GE Vault

[![Build Status](https://github.com/GEVault/ge-vault/actions/workflows/deploy.yml/badge.svg)](https://github.com/GEVault/ge-vault/actions)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![TypeScript](https://img.shields.io/badge/TypeScript-5.9-blue.svg)](https://www.typescriptlang.org/)
[![React](https://img.shields.io/badge/React-18.3-61dafb.svg)](https://reactjs.org/)

**Track your Old School RuneScape Grand Exchange investments with real-time price updates and smart alerts.**

**Live Site:** https://gevault.com

---

## Features

### Core Features (Free)
- 📊 **Portfolio Tracking** - Track unlimited OSRS item investments
- 💰 **Real-Time Prices** - Hourly price updates from OSRS Wiki API
- 🧮 **Profit/Loss Calculator** - Automatic calculations with GE tax consideration
- 📱 **Responsive Design** - Works on desktop, tablet, and mobile

### Premium Features
- 🔔 **Price Alerts** - Get notified when prices hit your targets
- 💬 **Discord Notifications** - DM or webhook alerts via Discord
- ⚡ **Multiple Alert Types** - Absolute price or percentage change alerts
- ⏰ **Smart Behaviors** - One-shot, recurring, or cooldown alert modes
- 📝 **Alert Templates** - Pre-configured alerts for popular items
- 📊 **Alert History** - Track all past alert triggers

---

## Quick Start

### For Users

1. **Visit** [gevault.com](https://gevault.com)
2. **Sign Up** with your email
3. **Add Items** to your portfolio
4. **Track Profits** in real-time
5. **Upgrade to Premium** for price alerts

### For Developers

```bash
# Clone repository
git clone https://github.com/GEVault/ge-vault.git
cd ge-vault

# Install dependencies
npm install

# Set up environment
cp .env.example .env
# Edit .env with your credentials

# Start development server
npm run dev
```

Visit `http://localhost:5173`

**Full setup guide:** [Development Guide](docs/DEVELOPMENT.md)

## Project Structure

```
ge-vault/
├── packages/
│   ├── web/          # React frontend
│   ├── functions/    # Cloudflare Pages Functions
│   ├── worker/       # Cloudflare Worker (scheduled jobs)
│   └── shared/       # Shared types and utilities
├── scripts/          # Development/maintenance scripts
├── migrations/       # Database migrations
├── docs/             # Documentation
├── .github/          # CI/CD workflows
├── package.json      # Root package.json (workspace config)
└── README.md
```

## Quick Commands

```bash
# Install all dependencies from the root
npm install

# Run frontend development server
npm run dev

# Build all packages
npm run build

# Run tests for all packages
npm test
```

## Documentation

### User Documentation
- 📖 [User Guide](docs/USER_GUIDE.md) - Complete guide for end users
- ❓ [FAQ](docs/USER_GUIDE.md#faq) - Frequently asked questions

### Developer Documentation
- 🚀 [Development Guide](docs/DEVELOPMENT.md) - Local setup and coding standards
- 🏗️ [Architecture](docs/ARCHITECTURE.md) - System design and tech stack
- 🔌 [API Reference](docs/API.md) - Complete API endpoint documentation
- 🚢 [Deployment Guide](docs/DEPLOYMENT.md) - Production deployment procedures
- 🔧 [Troubleshooting](docs/TROUBLESHOOTING.md) - Common issues and solutions

### Planning & Design
- [Quick Start Guide](docs/ge-vault-quick-start.md)
- [Infrastructure Decisions](docs/ge-vault-infrastructure-decision.md)
- [Planning Doc](docs/osrs-portfolio-tracker-plan.md)

## Tech Stack

### Frontend
- **React** 18.3 - UI framework
- **TypeScript** 5.9 - Type safety
- **Vite** 7.1 - Build tool
- **Tailwind CSS** 3.4 - Styling
- **React Router** 7.9 - Client-side routing

### Backend & Infrastructure
- **Supabase** - PostgreSQL database + authentication
- **Cloudflare Pages** - Static hosting + API functions
- **Cloudflare Workers** - Serverless cron jobs (hourly price updates)
- **Stripe** - Payment processing
- **Discord API** - OAuth + bot notifications

### Development & Testing
- **Vitest** 4.0 - Unit and component testing
- **Testing Library** - React testing utilities
- **MSW** 2.12 - API mocking
- **ESLint** - Code quality
- **GitHub Actions** - CI/CD pipeline

**Detailed architecture:** [Architecture Documentation](docs/ARCHITECTURE.md)

## Testing

The project uses Vitest for unit and component testing. Test coverage goals:

- **Utilities:** 80%+ coverage (geTax, priceParser, etc.)
- **Components:** 60%+ coverage (ErrorBoundary, AlertForm, etc.)
- **Worker Logic:** 80%+ coverage (alert condition checking)

### Running Tests

```bash
# Run tests for all packages from the root
npm test
```

### Test Organization

```
packages/
├── shared/
│   ├── src/
│   │   └── validation/
│   │       └── __tests__/
│   │           └── validation.test.ts
├── web/
│   ├── src/
│   │   ├── components/
│   │   │   └── __tests__/
│   │   │       └── ErrorBoundary.test.tsx
└── worker/
    └── src/
        └── __tests__/
            └── alertLogic.test.ts
```

### Writing Tests

Tests use the AAA pattern (Arrange, Act, Assert):

```typescript
import { describe, it, expect } from 'vitest'
import { calculateGETax } from '@ge-vault/shared' // Example from shared package

describe('calculateGETax', () => {
  it('should calculate 2% tax for normal items', () => {
    // Arrange
    const price = 1000
    const quantity = 1

    // Act
    const tax = calculateGETax(price, quantity)

    // Assert
    expect(tax).toBe(20) // 1000 * 0.02 = 20
  })
})
```

## CI/CD

The project uses GitHub Actions for continuous integration and deployment:

1. **Test Job** - Runs all tests and generates coverage reports
2. **Deploy Job** - Deploys to Cloudflare Pages and Workers (only if tests pass)

Tests must pass before code can be deployed to production.

**View workflow:** [.github/workflows/deploy.yml](.github/workflows/deploy.yml)

---

## Contributing

We welcome contributions! Here's how to get started:

### Development Workflow

1. **Fork the repository**
2. **Create a feature branch**
   ```bash
   git checkout -b feature/your-feature-name
   ```
3. **Make your changes**
   - Write tests for new features
   - Follow TypeScript and React best practices
   - Run linter: `npm run lint`
4. **Test your changes**
   ```bash
   npm test
   npm run build
   ```
5. **Commit with clear message**
   ```bash
   git commit -m "feat: add your feature description"
   ```
6. **Push and create Pull Request**
   ```bash
   git push origin feature/your-feature-name
   ```

### Coding Standards

- **TypeScript** strict mode enabled
- **ESLint** for code quality
- **Tests required** for new features
- **80% coverage** for utilities, 60% for components
- **AAA pattern** (Arrange, Act, Assert) for tests

**Full guidelines:** [Development Guide](docs/DEVELOPMENT.md)

---

## License

This project is licensed under the MIT License.

**MIT License** - Free to use, modify, and distribute with attribution.

See [LICENSE](LICENSE) file for details.

---

## Support & Contact

### Getting Help

- **User Guide:** [docs/USER_GUIDE.md](docs/USER_GUIDE.md)
- **Troubleshooting:** [docs/TROUBLESHOOTING.md](docs/TROUBLESHOOTING.md)
- **GitHub Issues:** [github.com/GEVault/ge-vault/issues](https://github.com/GEVault/ge-vault/issues)

### Reporting Bugs

Found a bug? [Create an issue](https://github.com/GEVault/ge-vault/issues/new) with:
- Clear description
- Steps to reproduce
- Expected vs actual behavior
- Screenshots (if applicable)

### Feature Requests

Have an idea? [Open a discussion](https://github.com/GEVault/ge-vault/discussions) or create an issue with the `enhancement` label.

---

## Acknowledgments

- **OSRS Wiki** - Price data API
- **Jagex** - Old School RuneScape
- **Open Source Community** - Amazing libraries and tools

---

**Built with ❤️ for the OSRS community**

**Not affiliated with Jagex or Old School RuneScape**
