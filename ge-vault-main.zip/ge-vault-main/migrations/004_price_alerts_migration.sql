-- Price Alerts Table
-- Premium feature: Allows users to set price alerts for OSRS items
-- Users get notified when items reach target prices

CREATE TABLE IF NOT EXISTS price_alerts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    item_id INT NOT NULL REFERENCES items(id) ON DELETE CASCADE,

    -- Alert configuration
    alert_type VARCHAR(50) NOT NULL CHECK (alert_type IN ('above', 'below', 'change_percent')),
    target_price BIGINT, -- For above/below alerts (in GP)
    change_percent DECIMAL(5,2), -- For percentage change alerts (e.g., 5.00 for 5%)

    -- Alert status
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    triggered_at TIMESTAMPTZ, -- When the alert was last triggered
    last_notified_at TIMESTAMPTZ, -- When user was last notified (for rate limiting)

    -- Notification preferences
    notify_email BOOLEAN DEFAULT TRUE,
    notify_in_app BOOLEAN DEFAULT TRUE,

    -- Timestamps
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Index for fast user lookups
CREATE INDEX IF NOT EXISTS idx_price_alerts_user_id ON price_alerts(user_id);

-- Index for item lookups
CREATE INDEX IF NOT EXISTS idx_price_alerts_item_id ON price_alerts(item_id);

-- Index for active alerts (for background checking)
CREATE INDEX IF NOT EXISTS idx_price_alerts_active ON price_alerts(is_active) WHERE is_active = TRUE;

-- Composite index for checking specific user's item alerts
CREATE INDEX IF NOT EXISTS idx_price_alerts_user_item ON price_alerts(user_id, item_id);

-- Enable Row Level Security
ALTER TABLE price_alerts ENABLE ROW LEVEL SECURITY;

-- Policy: Users can view their own alerts
CREATE POLICY "Users can view own alerts"
    ON price_alerts
    FOR SELECT
    USING (auth.uid() = user_id);

-- Policy: Users can create alerts (premium check will be in application code)
CREATE POLICY "Users can create alerts"
    ON price_alerts
    FOR INSERT
    WITH CHECK (auth.uid() = user_id);

-- Policy: Users can update their own alerts
CREATE POLICY "Users can update own alerts"
    ON price_alerts
    FOR UPDATE
    USING (auth.uid() = user_id);

-- Policy: Users can delete their own alerts
CREATE POLICY "Users can delete own alerts"
    ON price_alerts
    FOR DELETE
    USING (auth.uid() = user_id);

-- Policy: Service role can manage all alerts (for background checking)
CREATE POLICY "Service role can manage alerts"
    ON price_alerts
    FOR ALL
    USING (auth.role() = 'service_role');

-- Function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_price_alerts_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SET search_path = public;

-- Trigger to automatically update updated_at
CREATE TRIGGER update_price_alerts_updated_at
    BEFORE UPDATE ON price_alerts
    FOR EACH ROW
    EXECUTE FUNCTION update_price_alerts_updated_at();

-- Function to get active alert count for a user
CREATE OR REPLACE FUNCTION get_user_active_alerts_count(check_user_id UUID)
RETURNS INTEGER AS $$
BEGIN
    RETURN (
        SELECT COUNT(*)
        FROM price_alerts
        WHERE user_id = check_user_id
        AND is_active = TRUE
    );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

-- Function to check if user can create more alerts
-- Free users: 0 alerts
-- Premium users: unlimited alerts (enforced in application)
CREATE OR REPLACE FUNCTION can_user_create_alert(check_user_id UUID)
RETURNS BOOLEAN AS $$
BEGIN
    -- Check if user is premium
    RETURN is_user_premium(check_user_id);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;
