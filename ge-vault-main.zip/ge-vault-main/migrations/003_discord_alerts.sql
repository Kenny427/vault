-- Discord Connections
CREATE TABLE discord_connections (
  id BIGSERIAL PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE UNIQUE,
  discord_user_id TEXT NOT NULL UNIQUE,
  discord_username TEXT NOT NULL,
  access_token TEXT NOT NULL,
  refresh_token TEXT,
  token_expires_at TIMESTAMPTZ,
  connected_at TIMESTAMPTZ DEFAULT NOW()
);

-- Add token_expires_at column if upgrading existing table
-- ALTER TABLE discord_connections ADD COLUMN IF NOT EXISTS token_expires_at TIMESTAMPTZ;

-- User Alerts
CREATE TABLE user_alerts (
  id BIGSERIAL PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  
  -- Item
  item_id TEXT NOT NULL,
  item_name TEXT NOT NULL,
  
  -- Alert config
  alert_type TEXT NOT NULL CHECK (alert_type IN ('absolute', 'percentage_change')),
  target_price INTEGER,
  percentage_threshold DECIMAL,
  baseline_price INTEGER,
  price_direction TEXT NOT NULL DEFAULT 'either' CHECK (price_direction IN ('up', 'down', 'either')),
  
  -- Notification
  notification_type TEXT NOT NULL CHECK (notification_type IN ('bot_dm', 'webhook')),
  discord_user_id TEXT REFERENCES discord_connections(discord_user_id),
  discord_webhook_url TEXT,
  
  -- Behavior
  behavior TEXT NOT NULL DEFAULT 'one_shot' CHECK (behavior IN ('one_shot', 'recurring', 'cooldown')),
  cooldown_hours INTEGER DEFAULT 24,
  notes TEXT,
  
  -- Status
  active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  last_triggered_at TIMESTAMPTZ,
  trigger_count INTEGER DEFAULT 0,
  
  CHECK (
    (notification_type = 'bot_dm' AND discord_user_id IS NOT NULL) OR
    (notification_type = 'webhook' AND discord_webhook_url IS NOT NULL)
  ),
  CHECK (
    (alert_type = 'absolute' AND target_price IS NOT NULL) OR
    (alert_type = 'percentage_change' AND percentage_threshold IS NOT NULL AND baseline_price IS NOT NULL)
  )
);

-- Alert History
CREATE TABLE alert_history (
  id BIGSERIAL PRIMARY KEY,
  alert_id BIGINT NOT NULL REFERENCES user_alerts(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  triggered_at TIMESTAMPTZ DEFAULT NOW(),
  item_id TEXT NOT NULL,
  item_name TEXT NOT NULL,
  trigger_price INTEGER NOT NULL,
  target_price INTEGER NOT NULL,
  alert_type TEXT NOT NULL,
  notification_type TEXT NOT NULL,
  notification_sent BOOLEAN DEFAULT FALSE,
  notification_error TEXT,
  alert_behavior TEXT NOT NULL
);

-- OAuth States (for security)
CREATE TABLE oauth_states (
  id BIGSERIAL PRIMARY KEY,
  state TEXT NOT NULL UNIQUE,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  expires_at TIMESTAMPTZ NOT NULL,
  used BOOLEAN DEFAULT FALSE
);

-- Indexes
CREATE INDEX idx_user_alerts_active ON user_alerts(active, item_id) WHERE active = TRUE;
CREATE INDEX idx_alert_history_alert ON alert_history(alert_id, triggered_at DESC);

-- RLS Policies
ALTER TABLE discord_connections ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_alerts ENABLE ROW LEVEL SECURITY;
ALTER TABLE alert_history ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users manage own discord connection" ON discord_connections FOR ALL USING (auth.uid() = user_id);
CREATE POLICY "Users view own alerts" ON user_alerts FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Premium users create alerts" ON user_alerts FOR INSERT WITH CHECK (
  auth.uid() = user_id AND
  EXISTS (SELECT 1 FROM user_subscriptions WHERE user_id = auth.uid() AND status = 'active')
);
CREATE POLICY "Users update own alerts" ON user_alerts FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "Users delete own alerts" ON user_alerts FOR DELETE USING (auth.uid() = user_id);
CREATE POLICY "Users view own history" ON alert_history FOR SELECT USING (auth.uid() = user_id);

-- Helper function for cooldown logic
CREATE OR REPLACE FUNCTION should_check_alert(
  p_alert_id BIGINT,
  p_behavior TEXT,
  p_cooldown_hours INTEGER
) RETURNS BOOLEAN AS $$
BEGIN
  IF p_behavior = 'one_shot' THEN
    RETURN NOT EXISTS (SELECT 1 FROM alert_history WHERE alert_id = p_alert_id AND notification_sent = TRUE);
  END IF;
  IF p_behavior = 'recurring' THEN
    RETURN TRUE;
  END IF;
  IF p_behavior = 'cooldown' THEN
    RETURN NOT EXISTS (
      SELECT 1 FROM alert_history 
      WHERE alert_id = p_alert_id 
      AND notification_sent = TRUE 
      AND triggered_at > NOW() - (p_cooldown_hours || ' hours')::INTERVAL
    );
  END IF;
  RETURN FALSE;
END;
$$ LANGUAGE plpgsql;
