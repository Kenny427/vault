-- Create price_history table for storing historical price data
-- Run this in your Supabase SQL Editor before deploying the worker

CREATE TABLE IF NOT EXISTS price_history (
    id BIGSERIAL PRIMARY KEY,
    item_id INT NOT NULL REFERENCES items(id) ON DELETE CASCADE,
    price BIGINT NOT NULL,
    price_type VARCHAR(10) NOT NULL CHECK (price_type IN ('high', 'low')),
    timestamp TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Create indexes for efficient queries by item and time
CREATE INDEX IF NOT EXISTS idx_price_history_item_time ON price_history (item_id, timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_price_history_timestamp ON price_history (timestamp DESC);

-- Enable Row Level Security (optional, for security)
ALTER TABLE price_history ENABLE ROW LEVEL SECURITY;

-- Allow all users to read price history
CREATE POLICY "Anyone can view price history"
    ON price_history
    FOR SELECT
    USING (true);

-- Add comment
COMMENT ON TABLE price_history IS 'Stores historical price data for all items, updated daily by Cloudflare Worker cron job';

-- Verify table was created
SELECT
    table_name,
    column_name,
    data_type
FROM information_schema.columns
WHERE table_name = 'price_history'
ORDER BY ordinal_position;
