-- Drop the unused item_prices_history table
-- This table was from the original plan but never used
-- We're using price_history instead (which already has 385k+ records)

-- Drop the index first
DROP INDEX IF EXISTS idx_history_item_date;

-- Drop the table
DROP TABLE IF EXISTS item_prices_history;

-- Verify it's gone
SELECT table_name
FROM information_schema.tables
WHERE table_schema = 'public'
  AND table_name LIKE '%price%'
ORDER BY table_name;
