-- Create a function to allow authenticated users to refresh prices
-- This function runs with SECURITY DEFINER to bypass RLS
-- Run this in your Supabase SQL Editor

-- First, ensure RLS is enabled on item_prices_current
ALTER TABLE item_prices_current ENABLE ROW LEVEL SECURITY;

-- Drop existing policy if it exists, then create it
DROP POLICY IF EXISTS "Anyone can view current prices" ON item_prices_current;

-- Allow everyone to read prices
CREATE POLICY "Anyone can view current prices"
    ON item_prices_current
    FOR SELECT
    USING (true);

-- Allow service role to insert/update prices (needed for the function)
DROP POLICY IF EXISTS "Service role can manage prices" ON item_prices_current;
CREATE POLICY "Service role can manage prices"
    ON item_prices_current
    FOR ALL
    USING (true)
    WITH CHECK (true);

-- Create a function that authenticated users can call to refresh prices
CREATE OR REPLACE FUNCTION refresh_item_prices(price_updates JSONB)
RETURNS INTEGER
LANGUAGE plpgsql
SECURITY DEFINER -- This allows the function to bypass RLS
SET search_path = public
AS $$
DECLARE
    updated_count INTEGER;
BEGIN
    -- Only allow authenticated users to call this function
    IF auth.uid() IS NULL THEN
        RAISE EXCEPTION 'Must be authenticated to refresh prices';
    END IF;

    -- Insert or update prices from the provided JSON array
    -- Expected format: [{"item_id": 123, "high_price": 1000, "low_price": 900, "updated_at": "2024-01-01T00:00:00Z"}, ...]
    WITH price_data AS (
        SELECT
            (item->>'item_id')::INTEGER AS item_id,
            (item->>'high_price')::BIGINT AS high_price,
            (item->>'low_price')::BIGINT AS low_price,
            (item->>'updated_at')::TIMESTAMPTZ AS updated_at
        FROM jsonb_array_elements(price_updates) AS item
    )
    INSERT INTO item_prices_current (item_id, high_price, low_price, updated_at)
    SELECT item_id, high_price, low_price, updated_at
    FROM price_data
    ON CONFLICT (item_id)
    DO UPDATE SET
        high_price = EXCLUDED.high_price,
        low_price = EXCLUDED.low_price,
        updated_at = EXCLUDED.updated_at;

    GET DIAGNOSTICS updated_count = ROW_COUNT;
    RETURN updated_count;
END;
$$;

-- Grant execute permission to authenticated users
GRANT EXECUTE ON FUNCTION refresh_item_prices(JSONB) TO authenticated;

-- Add helpful comment
COMMENT ON FUNCTION refresh_item_prices IS 'Allows authenticated users to refresh item prices from OSRS Wiki API';
