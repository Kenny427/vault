-- Drop price_history table to free up storage space
-- Historical price data was consuming 460 MB of 500 MB free tier limit
-- Other sites already provide better price history features

DROP TABLE IF EXISTS price_history;
